<?php $__env->startSection('title', 'Laporan Pembelian'); ?>

<?php $__env->startSection('content'); ?>
    
            
    <div class="card">
        <div class="card-header d-flex align-items-center justify-content-between">
            <h2 class="h6 mb-0 font-weight-bold card-title">Laporan Pembelian</h2>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isAdmin')): ?>
                <form action="<?php echo e(route('report.buy.print')); ?>" target="_blank">
                    <input type="hidden" name="dari" value="<?php echo e(request()->dari); ?>">
                    <input type="hidden" name="sampai" value="<?php echo e(request()->sampai); ?>">
                    <input type="hidden" name="distributor" value="<?php echo e(request()->distributor); ?>">
                    <button class="btn btn-sm btn-danger">Print</button>
                </form>
            <?php endif; ?>
        </div>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isAdmin')): ?>
            <div class="card-body border-bottom">
               <form action="<?php echo e(route('report.buy')); ?>">
                    <div class="form-row form-group">
                        <div class="col-sm-3">
                            <label>Dari Tanggal</label>
                            <input type="date" name="dari" class="form-control" value="<?php echo e(request()->dari); ?>">
                        </div>
                        <div class="col-sm-3">
                            <label>Sampai Tanggal</label>
                            <input type="date" name="sampai" class="form-control" value="<?php echo e(request()->sampai); ?>">
                        </div>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isAdmin')): ?>
                            <div class="col-sm-3">
                                <label>Distributor</label>
                                <select class="form-control" name="distributor">
                                    <option selected disabled>Distributor</option>
                                    <?php $__currentLoopData = $distributor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->namaDist); ?>" <?php echo e(request()->distributor === $item->namaDist ? 'selected' : ''); ?>><?php echo e($item->namaDist); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        <?php endif; ?>
                    </div>
                    <button class="btn btn-primary">Tampilkan</button>
                </form>
            </div>
        <?php endif; ?>
        <?php if($reports): ?>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered table-striped" width="100%">
                        <thead align="center">
                            <tr>
                                <th>#</th>
                                <th>Tanggal</th>
                                <th>Distributor</th>
                                <th>Total Pembelian</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $total = 0
                            ?>
                            <?php $__empty_1 = true; $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr align="center">
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e(localDate($report->tanggal)); ?></td>
                                    <td><?php echo e($report->namaDist); ?></td>
                                    <td>Rp <?php echo e(number_format($report->total)); ?></td>
                                </tr>

                                <?php
                                    $total += $report->total
                                ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="4" align="center">Kosong</td>
                                </tr>
                            <?php endif; ?>
                            <tr>
                                <td align="right" colspan="3"><b>Total Pembelian</b></td>
                                <td align="center">Rp <?php echo e(number_format($total)); ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        <?php endif; ?>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('_layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /usr/local/var/www/pointofsale/resources/views/report/buy.blade.php ENDPATH**/ ?>