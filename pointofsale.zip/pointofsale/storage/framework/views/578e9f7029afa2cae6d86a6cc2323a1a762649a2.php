<?php $__env->startSection('title', 'Barcode Generator'); ?>

<?php $__env->startSection('content'); ?>
    
    <div class="card">
        <div class="card-header">
            <h2 class="h6 font-weight-bold mb-0 card-title">Barcode Generator</h2>
        </div>
        <div class="card-body">
            <img src="data:image/png;base64,<?php echo e($img); ?>" alt="">
            <div class="mt-2">
                <?php echo e($barcode); ?>

            </div>
        </div>
        <div class="card-footer">
            <a href="<?php echo e(route('stuff.barcode.print', $barcode)); ?>" class="btn btn-success">Print</a>
            <a href="<?php echo e(route('stuff.index')); ?>" class="btn btn-secondary">Kembali</a>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('_layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ibrahimalanshor/Documents/freelance/tokobukuv2/resources/views/stuff/barcode.blade.php ENDPATH**/ ?>