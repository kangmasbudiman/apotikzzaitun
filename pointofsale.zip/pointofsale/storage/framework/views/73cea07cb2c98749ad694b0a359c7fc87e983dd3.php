<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
	
	<?php if(session('success')): ?>
		<div class="alert alert-success alert-dismissible">
			<?php echo e(session('success')); ?>

			<button class="close" data-dismiss="alert">&times;</button>
		</div>
	<?php endif; ?>

		<div class="col-sm-6 col-lg-3">
	        <div class="card text-white bg-flat-color-1">
	            <div class="card-body pb-0">
	                <div class="float-right">
                        <i class="fa fa-archive"></i>
	                </div>
	                <h4 class="mb-0">
	                    <span class="count"><?php echo e($totalStuff); ?></span>
	                </h4>
	                <p class="text-light">Total Barang</p>

	            </div>

	        </div>
	    </div>

		<div class="col-sm-6 col-lg-3">
	        <div class="card text-white bg-flat-color-5">
	            <div class="card-body pb-0">
	                <div class="float-right">
                        <i class="fa fa-money"></i>
	                </div>
	                <h4 class="mb-0">
	                    <span class="count"><?php echo e($totalTransaction); ?></span>
	                </h4>
	                <p class="text-light">Total Transaksi</p>

	            </div>

	        </div>
	    </div>

		<div class="col-sm-6 col-lg-3">
	        <div class="card text-white bg-flat-color-3">
	            <div class="card-body pb-0">
	                <div class="float-right">
                        <i class="fa fa-calendar"></i>
	                </div>
	                <h4 class="mb-0">
	                    <span class="count"><?php echo e($transactionToday); ?></span>
	                </h4>
	                <p class="text-light">Transaksi Hari Ini</p>

	            </div>

	        </div>
	    </div>

		<div class="col-sm-6 col-lg-3">
	        <div class="card text-white bg-flat-color-4">
	            <div class="card-body pb-0">
	                <div class="float-right">
                        <i class="fa fa-users"></i>
	                </div>
	                <h4 class="mb-0">
	                    <span class="count"><?php echo e($totalUser); ?></span>
	                </h4>
	                <p class="text-light">Total Pengguna</p>

	            </div>

	        </div>
	    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('_layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tokobukuv2\resources\views/home.blade.php ENDPATH**/ ?>