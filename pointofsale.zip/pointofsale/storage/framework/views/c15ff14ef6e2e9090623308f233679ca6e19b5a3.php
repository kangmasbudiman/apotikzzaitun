<?php $__env->startSection('title', 'Edit Stok Opname'); ?>

<?php $__env->startSection('content'); ?>

  <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('opname.edit', ['id' => ''.e($id).''])->html();
} elseif ($_instance->childHasBeenRendered('7ZZYykG')) {
    $componentId = $_instance->getRenderedChildComponentId('7ZZYykG');
    $componentTag = $_instance->getRenderedChildComponentTagName('7ZZYykG');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('7ZZYykG');
} else {
    $response = \Livewire\Livewire::mount('opname.edit', ['id' => ''.e($id).'']);
    $html = $response->html();
    $_instance->logRenderedChild('7ZZYykG', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('_layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tokobuku\resources\views/opname/edit.blade.php ENDPATH**/ ?>