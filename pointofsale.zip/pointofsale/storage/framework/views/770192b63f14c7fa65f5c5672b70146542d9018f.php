<?php $__env->startSection('title', 'Barcode Generator'); ?>

<?php $__env->startSection('content'); ?>
    
    <div class="card">
        <div class="card-header">
            <h2 class="h6 font-weight-bold mb-0 card-title">Barcode Generator</h2>
        </div>
        <div class="card-body">
            <img src="data:image/png;base64,<?php echo e($img); ?>" alt="">
            <div class="text-center" style="width: 190px;">
                <div class="d-flex justify-content-between">
                    <?php $__currentLoopData = str_split($stuff->barcode); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barcode): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="font-weight-bold" style="font-size: 14px;">
                            <?php echo e($barcode); ?>

                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="bg-dark text-white py-1">
                    Rp <?php echo e(number_format($stuff->hargaJual)); ?>

                </div>
            </div>
        </div>
        <div class="card-footer">
            <a href="<?php echo e(route('stuff.barcode.print', $stuff->idBuku)); ?>" class="btn btn-success">Print</a>
            <a href="<?php echo e(route('stuff.index')); ?>" class="btn btn-secondary">Kembali</a>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('_layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ibrahimalanshor/Documents/freelance/Penyesuaian/tokobuku/resources/views/stuff/barcode.blade.php ENDPATH**/ ?>