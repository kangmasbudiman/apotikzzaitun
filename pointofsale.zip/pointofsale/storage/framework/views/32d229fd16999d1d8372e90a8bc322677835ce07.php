<?php $__env->startSection('title', 'Detail Transaksi'); ?>

<?php $__env->startSection('content'); ?>
	<div class="card">
		<div class="card-body">
			<div class="row">
				<div class="col-sm-8">
					<h1 class="h3">Toko Buku Kita</h1>
					<p>JL. Cihideung No 25 Tasikmalaya</p>
				</div>
				<div class="col-sm-4">
					<dl class="row mx-0">
						<dt class="col-3 px-0">Tanggal</dt>
						<dd class="col-9 row px-0 mx-0 text-right">
							<?php
								date_default_timezone_set('Asia/Jakarta');
							?>
							<span class="col-2 px-0">:</span>
							<span class="col-10 px-0"><?php echo e(date('d/m/y', strtotime($transactions[0]->tanggal))); ?> <?php echo e(date('h:i')); ?></span>
						</dd>
						<dt class="col-3 px-0">No Faktur</dt>
						<dd class="col-9 row px-0 mx-0 text-right">
							<span class="col-2 px-0">:</span>
							<span class="col-10 px-0"><?php echo e($transactions[0]->idPenjualan); ?></span>
						</dd>
						<dt class="col-3 px-0">Kasir</dt>
						<dd class="col-9 row px-0 mx-0 text-right">
							<span class="col-2 px-0">:</span>
							<span class="col-10 px-0"><?php echo e($transactions[0]->user->nama); ?></span>
						</dd>
					</dl>
				</div>
			</div>
			<div class="table-responsive">
				<table class="table table-striped" width="100%">
					<thead>
						<tr>
							<th>No</th>
							<th>Barang</th>
							<th>Harga</th>
							<th>Jumlah</th>
							<th>Total</th>
						</tr>
					</thead>
					<tbody>
						<?php
							$subtotal = 0;
						?>
						<?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td><?php echo e($loop->iteration); ?></td>
								<td><?php echo e($transaction->stuff->judul); ?></td>
								<td>Rp <?php echo e(number_format($transaction->stuff->hargaJual)); ?></td>
								<td><?php echo e($transaction->jumlah); ?></td>
								<?php
									$disc = $transaction->stuff->hargaJual * $transaction->stuff->disc / 100;
									$total = $transaction->total - ($disc);

									$subtotal += $total;
								?>
								<td>Rp <?php echo e(number_format($total)); ?></td>
							</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
					<tfoot>
						<tr>
							<td colspan="4" align="right"><strong>Subtotal</strong></td>
							<td>Rp <?php echo e(number_format($subtotal)); ?></td>
						</tr>
						<tr>
							<td colspan="4" align="right"><strong>Total Bayar</strong></td>
							<td>Rp <?php echo e(number_format(request()->bayar)); ?></td>
						</tr>
						<tr>
							<td colspan="4" align="right"><strong>Kembali</strong></td>
							<td>Rp <?php echo e(number_format(max(request()->bayar - $subtotal, 0))); ?></td>
						</tr>
					</tfoot>
				</table>
			</div>
		</div>
		<div class="card-footer">
			<a href="<?php echo e(route('transaction.print', ['transaction' => request()->transaction, 'bayar' => request()->bayar])); ?>" class="btn btn-primary">Print</a>
			<a href="<?php echo e(route('report')); ?>" class="btn btn-secondary">Kembali</a>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('_layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tokobukuv2\resources\views/transaction/detail.blade.php ENDPATH**/ ?>