<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Print</title>
	<style>
		@font-face {
	    font-family: 'Roboto';
	    src: url(<?php echo e(storage_path('fonts/Roboto/Roboto-Bold.ttf')); ?>) format("truetype");
	    font-weight: 700; // use the matching font-weight here ( 100, 200, 300, 400, etc).
	    font-style: bold; // use the matching font-style here
		}

		body {
			color: #333;
		}
		.heading {
			text-align: center;
			margin-bottom: 20px;
		}
		.title {
			font-size: 36px;
			color: #111;
		}
		.sub {
			font-size: 32px;
			color: #111;
		}
		hr {
			border: 0;
			border-top: 2px solid #000;
		}
		p {
			margin: 0;
		}
	</style>
</head>
<body>
	
	<div class="heading">
		<p class="title">Toko Buku Kita</p>
		<p>JL. Clhideung No. 25 Tasikmalaya</p>
		<p>(0265) 9107713</p>
	</div>
	<hr>

	<div class="heading" style="margin-bottom: 20px">
		<p class="sub">List Pasok Buku</p>
		<p style="color: blue">
			Periode <?php echo e(request()->dari ?? $transactions[count($transactions) - 1]->tanggal); ?> - <?php echo e(request()->sampai ?? date('Y-m-d')); ?>

		</p>
	</div>

	<table width="100%" style="border-collapse: collapse;">
		<thead style="background-color: #111; color: #fff">
			<tr>
				<td style="font-weight: bold; border: 1px solid #111; padding: 10px 20px">No</td>
				<td style="font-weight: bold; border: 1px solid #111; padding: 10px 20px">ID Penjualan</td>
				<td style="font-weight: bold; border: 1px solid #111; padding: 10px 20px">Judul</td>
				<td style="font-weight: bold; border: 1px solid #111; padding: 10px 20px">Harga</td>
				<td style="font-weight: bold; border: 1px solid #111; padding: 10px 20px">Qty</td>
				<td style="font-weight: bold; border: 1px solid #111; padding: 10px 20px">Total</td>
				<td style="font-weight: bold; border: 1px solid #111; padding: 10px 20px">Kasir</td>
			</tr>
		</thead>
		<tbody>
			<?php
				$total = 0;
				$qty = 0;
			?>
				<?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<?php
						$total += $transaction->total;
						$qty += $transaction->jumlah;
					?>
					<td style="border: 1px solid #111; padding: 10px 20px">
						<?php echo e($loop->iteration); ?>

					</td>
					<td style="border: 1px solid #111; padding: 10px 20px">
						<?php echo e($transaction->idPenjualan); ?>

					</td>
					<td style="border: 1px solid #111; padding: 10px 20px">
						<?php echo e($transaction->stuff->judul); ?>

					</td>
					<td style="border: 1px solid #111; padding: 10px 20px">
						<?php echo e(number_format($transaction->stuff->hargaJual)); ?>

					</td>
					<td style="border: 1px solid #111; padding: 10px 20px">
						<?php echo e($transaction->jumlah); ?>

					</td>
					<td style="border: 1px solid #111; padding: 10px 20px">
						<?php echo e(number_format($transaction->total)); ?>

					</td>
					<td style="border: 1px solid #111; padding: 10px 20px">
						<?php echo e($transaction->user->nama); ?>

					</td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td style="border: 1px solid #111; padding: 10px 20px" align="right" colspan="4">Jumlah</td>
					<td style="border: 1px solid #111; padding: 10px 20px"><?php echo e($qty); ?></td>
					<td style="border: 1px solid #111; padding: 10px 20px"><?php echo e(number_format($total)); ?></td>
					<td style="border: 1px solid #111; padding: 10px 20px"></td>
				</tr>
		</tbody>
	</table>

</body>
</html><?php /**PATH /home/ibrahimalanshor/Documents/freelance/kasir_change_db/laravel-8-kasir/resources/views/transaction/printall.blade.php ENDPATH**/ ?>