<div class="card">
	<div class="card-header d-flex justify-content-between align-items-center py-2">
		<h2 class="card-title h6 mb-0 font-weight-bold">Data Transaksi</h2>
		<button class="btn btn-danger btn-sm" wire:click="$emit('clearTransaction')">Reset</button>
	</div>
	<div class="card-body">
		<?php if(session()->has('stock-error')): ?>
			<div class="alert alert-danger alert-dismissible">
				<?php echo e(session('stock-error')); ?>

				<button class="close" data-dismiss="alert">&times;</button>
			</div>
		<?php endif; ?>

		<div class="table-responsive">
			<table class="table table-bordered" width="100%">
				<thead>
					<tr>
						<th>No</th>
						<th>Barcode</th>
						<th>Produk</th>
						<th>Harga</th>
						<th width="150px">Qty</th>
						<th>Disc</th>
						<th>Total</th>
						<th>Action</th>
					</tr>
				</thead>
				<tbody class="transaction-table">
				<?php $__empty_1 = true; $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
					<?php
						$disc = $transaction->total * ($transaction->harga * $transaction->disc / 100);
						$total = $transaction->total * $transaction->harga - $disc;
					?>
					<tr>
						<td><?php echo e($loop->iteration); ?></td>
						<td><?php echo e($transaction->stuff->barcode); ?></td>
						<td><?php echo e($transaction->stuff->judul); ?></td>
						<td>Rp <?php echo e(number_format($transaction->harga)); ?></td>
						<td>
							<div class="input-group">
								<div class="input-group-prepend">
									<button class="btn btn-outline-secondary" wire:click="$emit('decrementTransaction', <?php echo e($loop->index); ?>)">-</button>
								</div>
								<input type="text" class="form-control qty" data-action="update" data-id="<?php echo e($loop->index); ?>" data-total="<?php echo e($transaction->total); ?>" data-stock="<?php echo e($transaction->stuff->stock); ?>" value="<?php echo e($transaction->total); ?>">
								<div class="input-group-append">
									<button class="btn btn-outline-secondary" wire:click="$emit('incrementTransaction', <?php echo e($loop->index); ?>)">+</button>
								</div>

								<span class="invalid-feedback"></span>
							</div>
						</td>
						<td align="right">Rp <?php echo e(number_format($disc)); ?></td>
						<td align="right">Rp <?php echo e(number_format($total)); ?></td>
						<td><button class="btn btn-sm btn-danger" wire:click="$emit('deleteTransaction', <?php echo e($loop->index); ?>)"><i class="fa fa-trash"></i></button></td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
					<tr>
						<td colspan="8" align="center">Kosong</td>
					</tr>
				<?php endif; ?>
				</tbody>
				<?php if($transactions): ?>
					<tfoot>
						<tr>
							<td colspan="6" align="right"><strong>Subtotal</strong></td>
							<td align="right">Rp <?php echo e(number_format($subtotal)); ?></td>
							<td></td>
						</tr>
					</tfoot>
				<?php endif; ?>
			</table>
		</div>
	</div>
</div>

<?php $__env->startPush('js'); ?>
<script>
	$(function () {
		$('.transaction-table').on('keyup', '.qty', function () {
			const number = this.value.replace(/\D/gi, '')
			const { stock, id } = $(this).data()

			if (number) {
				if (number > stock) {
					$(this).addClass('is-invalid')
					$(this).siblings('.invalid-feedback').html('Stok melampau batas')
				} else if (number <= 0) {
					$(this).addClass('is-invalid')
					$(this).siblings('.invalid-feedback').html('Stok terlalu sedikit')
				} else {
					Livewire.emit('updateTransaction', id, number)

					this.value = number
				}
			}

		})

		$('.transaction-table').on('focusout', '.qty', function () {
			if ($(this).hasClass('is-invalid')) {
				this.value = $(this).data('total')
			}

			if (!this.value) {
				this.value = $(this).data('total')
			}

			$(this).removeClass('is-invalid')
		})
	})
</script>
<?php $__env->stopPush(); ?><?php /**PATH /home/ibrahimalanshor/Documents/freelance/tokobukuv2/resources/views/livewire/transaction/data.blade.php ENDPATH**/ ?>