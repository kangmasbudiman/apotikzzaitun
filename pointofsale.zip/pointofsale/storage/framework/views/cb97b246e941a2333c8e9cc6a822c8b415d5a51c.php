<?php $__env->startSection('title', 'Laporan Pengeluaran'); ?>

<?php $__env->startSection('content'); ?>
    
            
    <div class="card">
        <div class="card-header d-flex align-items-center justify-content-between">
            <h2 class="h6 mb-0 font-weight-bold card-title">Laporan Pengeluaran</h2>
            <form action="<?php echo e(route('report.expend.print')); ?>">
                <input type="hidden" name="dari" value="<?php echo e(request()->dari); ?>">
                <input type="hidden" name="sampai" value="<?php echo e(request()->sampai); ?>">
                <button class="btn btn-sm btn-danger">Print</button>
            </form>
        </div>
        <div class="card-body border-bottom">
           <form action="<?php echo e(route('report.expend')); ?>">
                <div class="form-row form-group">
                    <div class="col-sm-3">
                        <label>Dari Tanggal</label>
                        <input type="date" name="dari" class="form-control" value="<?php echo e(request()->dari); ?>">
                    </div>
                    <div class="col-sm-3">
                        <label>Sampai Tanggal</label>
                        <input type="date" name="sampai" class="form-control" value="<?php echo e(request()->sampai); ?>">
                    </div>
                </div>
                <button class="btn btn-primary">Tampilkan</button>
            </form>
        </div>
        <?php if($reports): ?>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered table-striped" width="100%">
                        <thead align="center">
                            <tr>
                                <th>#</th>
                                <th>Tanggal</th>
                                <th>Total Pengeluaran</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $total = 0
                            ?>
                            <?php $__empty_1 = true; $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr align="center">
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e(localDate($report->tanggal)); ?></td>
                                    <td>Rp <?php echo e(number_format($report->total)); ?></td>
                                </tr>

                                <?php
                                    $total += $report->total
                                ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="3" align="center">Kosong</td>
                                </tr>
                            <?php endif; ?>
                            <?php if($reports): ?>
                                <tr align="center">
                                    <th colspan="2" align="center"><center>Total Seluruh Pengeluaran</center></th>
                                    <th>Rp <?php echo e(number_format($total)); ?></th>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        <?php endif; ?>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('_layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tokobukuv4\resources\views/report/expend.blade.php ENDPATH**/ ?>