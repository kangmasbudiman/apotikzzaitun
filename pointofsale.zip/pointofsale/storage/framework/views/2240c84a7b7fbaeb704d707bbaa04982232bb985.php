<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Print</title>
    <style>
        @font-face {
        font-family: 'Roboto';
        src: url(<?php echo e(storage_path('fonts/Roboto/Roboto-Bold.ttf')); ?>) format("truetype");
        font-weight: 700; // use the matching font-weight here ( 100, 200, 300, 400, etc).
        font-style: bold; // use the matching font-style here
        }

        body {
            color: #333;
        }
        .heading {
            text-align: center;
            margin-bottom: 20px;
        }
        .title {
            font-size: 36px;
            color: #111;
        }
        .sub {
            font-size: 32px;
            color: #111;
        }
        hr {
            border: 0;
            border-top: 2px solid #000;
        }
        p {
            margin: 0;
        }
    </style>
</head>
<body>
    
    <div class="heading">
        <p class="title"><?php echo e(site('nama_toko')); ?></p>
        <p><?php echo e(site('alamat_toko')); ?></p>
        <p><?php echo e(site('telepon_toko')); ?></p>
    </div>
    <hr>

    <div class="heading" style="margin-bottom: 20px">
        <p class="sub">List Pasok Buku</p>
        <p style="color: blue">
            Periode <?php echo e(request()->dari ?? $stocks[count($stocks) - 1] ? $stocks[count($stocks) - 1]->stock->tanggal : date('Y-m-d')); ?> - <?php echo e(request()->sampai ?? date('Y-m-d')); ?>

        </p>
    </div>

    <table width="100%" style="border-collapse: collapse;">
        <thead style="background-color: #111; color: #fff">
            <tr>
                <td style="font-weight: bold; border: 1px solid #111; padding: 10px 20px">No</td>
                <td style="font-weight: bold; border: 1px solid #111; padding: 10px 20px">ID Pasok</td>
                <td style="font-weight: bold; border: 1px solid #111; padding: 10px 20px">Tanggal</td>
                <td style="font-weight: bold; border: 1px solid #111; padding: 10px 20px">Nama Dist</td>
                <td style="font-weight: bold; border: 1px solid #111; padding: 10px 20px">Judul Buku</td>
                <td style="font-weight: bold; border: 1px solid #111; padding: 10px 20px">Harga</td>
                <td style="font-weight: bold; border: 1px solid #111; padding: 10px 20px">Jumlah</td>
                <td style="font-weight: bold; border: 1px solid #111; padding: 10px 20px">Total</td>
            </tr>
        </thead>
        <tbody>
            <?php
                $total = 0;
                $harga = 0;
                $jumlah = 0;
            ?>
                <?php $__currentLoopData = $stocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stock): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <?php
                        $subtotal = $stock->harga * $stock->jumlah;
                        $harga += $stock->harga;
                        $jumlah += $stock->jumlah;
                        $total += $subtotal;
                    ?>
                    <td style="border: 1px solid #111; padding: 10px 20px">
                        <?php echo e($loop->iteration); ?>

                    </td>
                    <td style="border: 1px solid #111; padding: 10px 20px">
                        <?php echo e($stock->id); ?>

                    </td>
                    <td style="border: 1px solid #111; padding: 10px 20px">
                        <?php echo e(date('Y M d', strtotime($stock->stock->tanggal))); ?>

                    </td>
                    <td style="border: 1px solid #111; padding: 10px 20px">
                        <?php echo e($stock->stock->distributor->namaDist); ?>

                    </td>
                    <td style="border: 1px solid #111; padding: 10px 20px">
                        <?php echo e($stock->stuff->judul); ?>

                    </td>
                    <td style="border: 1px solid #111; padding: 10px 20px">
                        <?php echo e(number_format($stock->harga)); ?>

                    </td>
                    <td style="border: 1px solid #111; padding: 10px 20px">
                        <?php echo e($stock->jumlah); ?>

                    </td>
                    <td style="border: 1px solid #111; padding: 10px 20px">
                        <?php echo e(number_format($subtotal)); ?>

                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td style="border: 1px solid #111; padding: 10px 20px" align="center" colspan="5">Jumlah</td>
                    <td style="border: 1px solid #111; padding: 10px 20px"><?php echo e(number_format($harga)); ?></td>
                    <td style="border: 1px solid #111; padding: 10px 20px"><?php echo e(number_format($jumlah)); ?></td>
                    <td style="border: 1px solid #111; padding: 10px 20px"><?php echo e(number_format($total)); ?></td>
                </tr>
        </tbody>
    </table>

</body>
</html><?php /**PATH /home/ibrahimalanshor/Documents/freelance/tokobukuv2/resources/views/stock/detail_stock_printall.blade.php ENDPATH**/ ?>