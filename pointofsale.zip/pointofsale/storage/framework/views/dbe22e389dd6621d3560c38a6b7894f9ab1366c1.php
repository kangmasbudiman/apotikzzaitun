<div class="modal fade" tabindex="1" role="dialog" id="print" wire:ignore.self>
<div class="modal-dialog">
<div class="modal-content">
    <?php if($transaction): ?>
    <div class="modal-header">
        <center class="w-100">
            <h5><?php echo e(site('nama_toko')); ?></h5>
            <p class="mb-0"><?php echo e(site('alamat_toko')); ?></p>
            <p class="mb-0"><?php echo e(site('telepon_toko')); ?></p>
        </center>
    </div>
    <div class="modal-body pb-0 border-bottom">
        <ul class="list-unstyled row">
            <li class="col-sm-6">
                <b>No Faktur</b><br><?php echo e($transaction->idPenjualan); ?>

            </li>
            <li class="col-sm-6 text-right">
                <b>Kasir</b><br><?php echo e($transaction->namaUser); ?>

            </li>
            <li class="col-sm-6">
                <b>Tanggal</b><br><?php echo e(date('d/m/y H:i A', strtotime($transaction->tanggal))); ?>

            </li>
        </ul>
    </div>
    <div class="modal-body pb-0">
        <table class="table table-striped" width="100%">
            <tr>
                <th>Nama Obat</th>
                <th>Qty</th>
                <th>Disc</th>
                <th align="right">Total</th>
            </tr>
            <?php
                $total = 0;
                $disc = 0
            ?>

            <?php $__currentLoopData = $transaction->detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $total += $detail->jumlah * $detail->hargaJual - $detail->disc;
                    $disc += $detail->disc
                ?>

                <tr>
                    <td><?php echo e($detail->obat); ?></td>
                    <td><?php echo e($detail->jumlah); ?> x <?php echo e(number_format($detail->hargaJual)); ?></td>
                    <td><?php echo e(number_format($detail->disc)); ?></td>
                    <td align="right"><?php echo e(number_format($detail->jumlah * $detail->hargaJual - $detail->disc)); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td colspan="3" align="right">Total</td>
                <td align="right"><?php echo e(number_format($total)); ?></td>
            </tr>
            <tr>
                <td colspan="3" align="right">Diskon</td>
                <td align="right"><?php echo e(number_format($diskon)); ?></td>
            </tr>
            <tr>
                <td colspan="3" align="right">Grand Total</td>
                <td align="right"><?php echo e(number_format($transaction->total)); ?></td>
            </tr>
            <tr>
                <td colspan="3" align="right">Bayar</td>
                <td align="right"><?php echo e(number_format(is_int($bayar) ? $bayar : 0)); ?></td>
            </tr>
            <tr>
                <td colspan="3" align="right">Kembali</td>
                <td align="right"><?php echo e(number_format($kembali)); ?></td>
            </tr>
        </table>
    </div>
    <div class="modal-footer">
        <a href="<?php echo e(route('transaction.print', ['id' => $transaction->idPenjualan,  'bayar' => $bayar])); ?>" type="button" class="btn btn-primary" target="_blank">Print</a>
        <button type="button" data-dismiss="modal" class="btn btn-secondary">Kembali</button>
    </div>
    <?php endif; ?>
</div>
</div>
</div>

<?php $__env->startPush('js'); ?>

    <script>
        window.addEventListener('open-print', function (e) {
            $('#print').modal('show')
        })
    </script>

<?php $__env->stopPush(); ?><?php /**PATH /usr/local/var/www/pointofsale/resources/views/livewire/transaction/cetak.blade.php ENDPATH**/ ?>