<?php $__env->startSection('title', 'Kategori'); ?>

<?php $__env->startSection('content'); ?>
    
    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible">
            <?php echo e(session('success')); ?>

            <button class="close" data-dismiss="alert">&times;</button>
        </div>
    <?php endif; ?>

    <div id="alert"></div>
    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h2 class="h6 font-weight-bold mb-0 card-title">Data Kategori</h2>
            <button class="btn btn-primary btn-sm" data-toggle="modal" data-target="#create">Tambah Data</button>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" width="100%">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama Kategori</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                </table>
            </div>
        </div>
    </div>

    <div class="modal" id="create">
    <div class="modal-dialog">
    <div class="modal-content">
    <form action="<?php echo e(route('category.store')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="modal-header">
            <h5 class="modal-title">Tambah Kategori</h5>
            <button class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body">
            <div class="form-group">
                <label>Nama Kategori</label>
                <input type="text" class="form-control" name="nama_kategori" placeholder="Nama Kategori" autofocus>

                <span class="invalid-feedback"></span>
            </div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-primary" type="submit">Simpan</button>
            <button class="btn btn-secondary" data-dismiss="modal">Batal</button>
        </div>
    </form>
    </div>
    </div>
    </div>

    <div class="modal" id="edit">
    <div class="modal-dialog">
    <div class="modal-content">
    <form action="" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="modal-header">
            <h5 class="modal-title">Edit Data</h5>
            <button class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body">
            <div class="form-group">
                <label>Nama Kategori</label>
                <input type="text" class="form-control" name="nama_kategori" placeholder="Nama Kategori" autofocus>

                <span class="invalid-feedback"></span>
            </div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-primary" type="submit">Simpan</button>
            <button class="btn btn-secondary" data-dismiss="modal">Batal</button>
        </div>
    </form>
    </div>
    </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('css'); ?>
    
    <link rel="stylesheet" href="<?php echo e(asset('sufee-admin/vendors/datatables.net-bs4/css/dataTables.bootstrap4.min.css')); ?>">

    <style>
        table img{
            width: 100%;
            max-height: 100px;
            object-fit: cover;
        }
    </style>

<?php $__env->stopPush(); ?>

<?php $__env->startPush('js'); ?>
    
    <script src="<?php echo e(asset('sufee-admin/vendors/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('sufee-admin/vendors/datatables.net-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>
    
    <script>

        const ajaxUrl = '<?php echo e(route('category.datatables')); ?>'
        const updateUrl = '<?php echo e(route('category.update', ':id')); ?>'
        const deleteUrl = '<?php echo e(route('category.destroy', ':id')); ?>'
        const csrf = '<?php echo e(csrf_token()); ?>'
    </script>

    <script src="<?php echo e(asset('js/category.js')); ?>"></script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('_layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ibrahimalanshor/Documents/freelance/tokobukuv2/resources/views/category/index.blade.php ENDPATH**/ ?>