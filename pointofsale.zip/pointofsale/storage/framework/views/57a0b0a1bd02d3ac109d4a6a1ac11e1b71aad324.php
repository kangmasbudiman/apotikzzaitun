<div class="row">
	<div class="col-sm-6">
		<div class="card">
		<form wire:submit.prevent="store">
			<div class="card-header">
				<h2 class="card-title h6 mb-0 font-weight-bold">Input Transaksi</h2>
			</div>
			<div class="card-body">
				<?php if(session('error')): ?>
			    <div class="alert alert-danger alert-dismissible">
			        <?php echo e(session('error')); ?>

			        <button class="close" data-dismiss="alert">&times;</button>
			    </div>
				<?php endif; ?>
				<div class="form-group" wire:ignore>
					<label>Judul Buku</label>
					<select class="form-control custom-select"></select>

					<span class="invalid-feedback"></span>
				</div>
				<hr>
				<div class="form-group">
					<label>Jumlah</label>
					<input type="number" class="form-control <?php $__errorArgs = ['total'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Jumlah" wire:model="total">

					<?php $__errorArgs = ['total'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
						<span class="invalid-feedback"><?php echo e($message); ?></span>
					<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				</div>
			</div>
			<div class="card-footer">
				<button class="btn btn-primary submit" wire:loading.attr="disabled" wire:target="store" <?php echo e($this->filled ? 'disabled' : ''); ?>>Tambah</button>
			</div>
		</form>
		</div>
	</div>
	<div class="col-sm-6">
		<div class="card">
			<div class="card-header">
				<h2 class="card-title h6 mb-0 font-weight-bold">Data Barang <?php echo e($idBuku); ?></h2>
			</div>
			<div class="card-body">
				<div class="form-group">
					<label>Judul Buku</label>
					<input type="text" class="form-control" name="name" value="<?php echo e($stuff->judul ?? 'Judul'); ?>" disabled>
				</div>
				<div class="form-group">
					<label>Harga</label>
					<input type="text" class="form-control" name="price" value="<?php echo e(isset($stuff->hargaJual) ? 'Rp '.number_format($stuff->hargaJual) : 'Harga'); ?>" disabled>
				</div>
				<div class="form-group">
					<label>Stok</label>
					<input type="text" class="form-control" name="stock" value="<?php echo e($stuff->stock ?? 'Stok'); ?>" placeholder="Stok Barang" disabled>
				</div>
			</div>
		</div>
	</div>
</div>

<?php $__env->startPush('css'); ?>
	<link rel="stylesheet" href="<?php echo e(asset('sufee-admin/vendors/select2/css/select2.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('js'); ?>
	<script src="<?php echo e(asset('sufee-admin/vendors/select2/js/select2.min.js')); ?>"></script>

	<script>
		const $ = jQuery

		window.addEventListener('reset', function () {
			$('select').empty()
		})

		$(document).ready(function () {

			$('select').select2({
				placeholder: 'Barang',
				ajax: {
					url: '<?php echo e(route('stuff.select')); ?>',
					type: 'post',
					data: params => ({
						name: params.term,
						_token: '<?php echo e(csrf_token()); ?>'
					}),
					processResults: res => {
						res.map(stuff => stuff.text = `${stuff.text} - ${stuff.id}`);
						return {
							results: res
						}
					},
					cache: true
				}
			})

			$('select').on('select2:select', e => {
				window.livewire.find('<?php echo e($_instance->id); ?>').set('idBuku', e.params.data.id)
				window.livewire.find('<?php echo e($_instance->id); ?>').search()
			})

		})
	</script>
<?php $__env->stopPush(); ?><?php /**PATH C:\xampp\htdocs\kasitokobuku\resources\views/livewire/transaction/create.blade.php ENDPATH**/ ?>