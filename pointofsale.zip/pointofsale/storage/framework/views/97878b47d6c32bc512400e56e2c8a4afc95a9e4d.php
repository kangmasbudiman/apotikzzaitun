<div class="card">
    <div class="card-header">
        <h2 class="h6 font-weight-bold mb-0 card-title">Data Barcode</h2>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered" width="100%" id="items-table">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Barcode</th>
                        <th>Judul</th>
                        <th colspan="2">Jumlah</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($item['barcode']); ?></td>
                            <td><?php echo e($item['judul']); ?></td>
                            <td>
                                <input type="text" class="form-control item-qty" data-barcode="<?php echo e($item['barcode']); ?>" value="<?php echo e($item['jumlah']); ?>">
                            </td>
                            <td>
                                <button class="btn btn-sm btn-danger" wire:click="remove(<?php echo e($loop->index); ?>)">
                                    <i class="fa fa-trash"></i>
                                </button>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="4" align="center">Kosong</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
    <div class="card-footer" id="action-button">
        <button class="btn btn-primary" wire:click="print" <?php echo e(count($items) ? '' : 'disabled'); ?>>Print</button>
        <button class="btn btn-danger" wire:click="clear" <?php echo e(count($items) ? '' : 'disabled'); ?>>Reset</button>
        <a href="<?php echo e(route('stuff.index')); ?>" class="btn btn-secondary">Kembali</a>
    </div>
</div>

<?php $__env->startPush('js'); ?>
    <script>
        jQuery(function ($) {
            $('#items-table').on('keyup', '.item-qty', function () {
                const input = $(this)
                const val = input.val().replace(/\D/gi, '')

                input.val(val)
            })

            $('#items-table').on('focusout', '.item-qty', function () {
                const input = $(this)
                let val = +input.val().replace(/\D/gi, '')

                val = val < 1 ? 1 : val

                console.log(input.data('barcode'))

                window.livewire.find('<?php echo e($_instance->id); ?>').update(input.data('barcode'), val)

                input.val(val)
            })

            $('#action-button button').attr('disabled', 'disabled')
        })
    </script>
<?php $__env->stopPush(); ?><?php /**PATH /home/ibrahimalanshor/Documents/freelance/Penyesuaian/Source Code/tokobukuv4/resources/views/livewire/barcode/item.blade.php ENDPATH**/ ?>