<?php $__env->startSection('title', 'Tambah Stok Opname'); ?>

<?php $__env->startSection('content'); ?>

  <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('opname.create', [])->html();
} elseif ($_instance->childHasBeenRendered('wqEjo6N')) {
    $componentId = $_instance->getRenderedChildComponentId('wqEjo6N');
    $componentTag = $_instance->getRenderedChildComponentTagName('wqEjo6N');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('wqEjo6N');
} else {
    $response = \Livewire\Livewire::mount('opname.create', []);
    $html = $response->html();
    $_instance->logRenderedChild('wqEjo6N', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('_layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tokobuku\resources\views/opname/create.blade.php ENDPATH**/ ?>