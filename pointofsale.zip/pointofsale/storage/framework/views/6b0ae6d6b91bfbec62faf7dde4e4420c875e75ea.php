<div class="modal fade" id="payment" wire:ignore.self>
<div class="modal-dialog">
<div class="modal-content">
	<form wire:submit.prevent="store">
		<div class="modal-header">
			<h2 class="h5 modal-title">Pembayaran</h2>
			<button class="close" data-dismiss="modal">&times;</button>
		</div>
		<div class="modal-body">
			<div class="form-group">
				<label>Kasir</label>
				<div class="input-group">
					<input type="text" class="form-control" value="<?php echo e($user->nama); ?>" disabled>
				</div>
			</div>
			<div class="form-row">
				<div class="col">
					<div class="form-group">
						<label>Total</label>
						<div class="input-group">
							<input type="text" class="form-control" value="Rp <?php echo e(number_format($total)); ?>" disabled>
						</div>
					</div>
				</div>
				<div class="col">
					<div class="form-group">
						<label>PPN (<?php echo e(site('ppn')); ?>%)</label>
						<div class="input-group">
							<input type="text" class="form-control" value="Rp <?php echo e(number_format($ppn)); ?>" disabled>
						</div>
					</div>
				</div>
			</div>
			<div class="form-group">
				<label>Subtotal</label>
				<div class="input-group">
					<input type="text" class="form-control" value="Rp <?php echo e(number_format($subtotal)); ?>" disabled>
				</div>
			</div>
			<div class="form-group">
				<label>Bayar</label>
				<div class="input-group">
					<div class="input-group-prepend">
						<span class="input-group-text">Rp</span>
					</div>
					<input type="text" name="money" class="form-control <?php $__errorArgs = ['money'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model="money" placeholder="0">
					
					<?php $__errorArgs = ['money'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
						<span class="invalid-feedback"><?php echo e($message); ?></span>
					<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				</div>
			</div>
			<div class="form-group">
				<label>Kembali</label>
				<div class="input-group">
					<input type="text" class="form-control" value="Rp <?php echo e(number_format($return)); ?>" disabled>
				</div>
			</div>
		</div>
		<div class="modal-footer">
			<button class="btn btn-primary" type="submit" <?php echo e($total < 1 ? 'disabled' : ''); ?>>Bayar</button>
			<button type="button" data-dismiss="modal" class="btn btn-secondary">Kembali</a>
		</div>
	</form>

</div>
</div>
</div>

<?php $__env->startPush('js'); ?>

	<script>
		window.addEventListener('open-payment', function (e) {
			$('#payment').modal('show')

			$('#payment').find('form')[0].reset()
		})

		window.addEventListener('close-payment', function (e) {
			$('#payment').modal('hide')
		})
	</script>

<?php $__env->stopPush(); ?><?php /**PATH C:\xampp\htdocs\tokobuku\resources\views/livewire/transaction/payment.blade.php ENDPATH**/ ?>