<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>

	<style>
		body {
			font-family: "Roboto";
			color: #333;
			font-size: 20px;
		}
		.heading {
			text-align: center;
			margin-bottom: 20px;
		}
		.title {
			font-size: 28px;
			color: #111;
		}
		hr {
			border: 0;
			border-top: 2px solid #000;
		}
		p {
			margin: 0;
		}
	</style>
</head>
<body>

<div class="heading">
	<p class="title">Toko Buku Kita</p>
	<p>JL. Clhideung No. 25 Tasikmalaya</p>
	<p>(0265) 9107713</p>
</div>
<hr>

<p class="title" style="text-align: center; margin: 20px 0;">Faktur Pembelian Buku</p>

<table width="100%" style="margin-bottom: 20px">
	<tr>
		<td width="50%">
			Kode Distributor : <?php echo e($stocks[0]->distributor->idDist); ?> <br>
			Nama Distributor : <?php echo e($stocks[0]->distributor->namaDist); ?>

		</td>
		<td width="50%" style="text-align: right;">
			Tanggal : <?php echo e(localDate($stocks[0]->tanggal)); ?> <br>
			No Faktur : <?php echo e($stocks[0]->idPasok); ?>

		</td>
	</tr>
</table>

<?php
	$total = 0;
?>
<table style="margin-bottom: 20px; border-collapse: collapse;" width="100%">
	<tr style="background-color: #111; color: white">
		<td style="border: 1px solid #111;padding: 5px 10px;">No</td>
		<td style="border: 1px solid #111;padding: 5px 10px;">ID Buku</td>
		<td style="border: 1px solid #111;padding: 5px 10px;">Judul</td>
		<td style="border: 1px solid #111;padding: 5px 10px;">Harga</td>
		<td style="border: 1px solid #111;padding: 5px 10px;">Qty</td>
		<td style="border: 1px solid #111;padding: 5px 10px;">Total</td>
	</tr>
	<?php
		$jumlah = 0;
	?>
	<?php $__currentLoopData = $stocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<?php
			$total += $transaction->stuff->hargaPokok * $transaction->jumlah;
			$jumlah += $transaction->jumlah;
		?>
		<tr>
			<td style="border: 1px solid #111;padding: 5px 10px;" width="5%" valign="top">
				<?php echo e($loop->iteration); ?>.
			</td>
			<td style="border: 1px solid #111;padding: 5px 10px;" valign="top">
				<?php echo e($transaction->stuff->idBuku); ?><br>
			</td>
			<td style="border: 1px solid #111;padding: 5px 10px;" width="50%">
				<?php echo e($transaction->stuff->judul); ?><br>
			</td>
			<td style="border: 1px solid #111;padding: 5px 10px;">
				<?php echo e(number_format($transaction->stuff->hargaPokok)); ?>

			</td>
			<td style="border: 1px solid #111;padding: 5px 10px;">
				<?php echo e($transaction->jumlah); ?>

			</td>
			<td style="border: 1px solid #111;padding: 5px 10px;" align="right">
				<?php echo e(number_format($transaction->stuff->hargaPokok * $transaction->jumlah)); ?>

			</td>
		</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<tr>
		<td style="border: 1px solid #111;padding: 5px 10px;" colspan="4" align="right">
			Jumlah
		</td>
		<td style="border: 1px solid #111;padding: 5px 10px;">
			<?php echo e($jumlah); ?>

		</td>
		<td style="border: 1px solid #111;padding: 5px 10px;" align="right">
			<?php echo e(number_format($total)); ?>

		</td>
	</tr>
	<tr>
		<td style="border: 1px solid #111;padding: 5px 10px;" colspan="4" align="right">Total Bayar</td>
		<td style="border: 1px solid #111;padding: 5px 10px;" colspan="2" align="right"><?php echo e(number_format(request()->bayar)); ?></td>
	</tr>
	<tr>
		<td style="border: 1px solid #111;padding: 5px 10px;" colspan="4" align="right">Kembali</td>
		<td style="border: 1px solid #111;padding: 5px 10px;" colspan="2" align="right"><?php echo e(number_format(max(request()->bayar - $total, 0))); ?></td>
	</tr>
</table>

</body>
</html><?php /**PATH /home/ibrahimalanshor/Documents/freelance/kasir_change_db/laravel-8-kasir/resources/views/stock/print.blade.php ENDPATH**/ ?>