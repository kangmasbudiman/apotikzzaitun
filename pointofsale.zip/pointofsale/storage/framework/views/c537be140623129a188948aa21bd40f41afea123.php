<?php $__env->startSection('title', 'Pengeluaran'); ?>

<?php $__env->startSection('content'); ?>
    
    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible">
            <?php echo e(session('success')); ?>

            <button class="close" data-dismiss="alert">&times;</button>
        </div>
    <?php endif; ?>

    <div id="alert"></div>
    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h2 class="h6 font-weight-bold mb-0 card-title">Data Pengeluaran</h2>
            <div>
                <button class="btn btn-sm btn-warning" data-toggle="collapse" data-target="#filter">Filter</button>
                <button class="btn btn-sm btn-warning print">Print</button>
                <button class="btn btn-success btn-sm" data-toggle="modal" data-target="#import">Import Excel</button>
                <a class="btn btn-success btn-sm" href="<?php echo e(route('finance.export')); ?>">Export Excel</a>
                <button class="btn btn-primary btn-sm" data-toggle="modal" data-target="#create">Tambah Data</button>
            </div>
        </div>
        <div class="card-body border-bottom collapse form-row pb-4" id="filter">
            <div class="col-sm-3">
                <label>Dari</label>
                <input type="date" name="dari" placeholder="Tanggal" class="form-control">
            </div>
            <div class="col-sm-3">
                <label>Sampai</label>
                <input type="date" name="sampai" placeholder="Tanggal" class="form-control">
            </div>
            <div class="col-sm-3">
                <label>Kategori</label>
                <select class="form-control" style="width: 100%;" name="category">
                    <option value="" selected="">Kategori</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->namaKategori); ?>"><?php echo e($item->namaKategori); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-sm-3 d-flex align-items-end">
                <button class="btn btn-primary rounded filter">Filter</button>
            </div>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" width="100%">
                    <thead>
                        <tr>
                            <th>ID Pengeluaran</th>
                            <th>Tanggal</th>
                            <th>Pengeluaran</th>
                            <th>Kategori</th>
                            <th>User</th>
                            <th>Keterangan</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                </table>
            </div>
        </div>
    </div>

    <div class="modal" id="create">
    <div class="modal-dialog">
    <div class="modal-content">
    <form action="<?php echo e(route('finance.store')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <div class="modal-header">
            <h5 class="modal-title">Tambah Pengeluaran</h5>
            <button class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body">
            <div class="form-group">
            <input type="hidden" class="form-control" name="namaUser" autofocus>
                <label>Pengeluaran</label>
                <input type="text" class="form-control nominal" name="pengeluaran" placeholder="Pengeluaran" autofocus>

                <span class="invalid-feedback"></span>
            </div>
            <div class="form-group">
                <label>Kategori Pengeluaran</label>
                <select style="width: 100%;" class="form-control custom-select" name="idKategoriPengeluaran" placeholder="Kategori Pengeluaran"></select>

                <span class="invalid-feedback"></span>
            </div>
            <div class="form-group user-select">
                <label>Nama Karyawan</label>
                <select style="width: 100%;" class="form-control custom-select" name="idUser" placeholder="Nama Karyawan"></select>

                <span class="invalid-feedback"></span>
            </div>
            <div class="form-group">
                <label>Keterangan</label>
                <textarea class="form-control" name="keterangan" placeholder="Keterangan"></textarea>

                <span class="invalid-feedback"></span>
            </div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-primary" type="submit">Simpan</button>
            <button class="btn btn-secondary" data-dismiss="modal">Batal</button>
        </div>
    </form>
    </div>
    </div>
    </div>

    <div class="modal" id="edit">
    <div class="modal-dialog">
    <div class="modal-content">
    <form action="" method="post">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <input type="hidden" class="form-control" name="namaUser" autofocus>
        <div class="modal-header">
            <h5 class="modal-title">Edit Data</h5>
            <button class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body">
            <div class="form-group">
                <label>Pengeluaran</label>
                <input type="text" class="form-control nominal" name="pengeluaran" placeholder="Pengeluaran" autofocus>

                <span class="invalid-feedback"></span>
            </div>
            <div class="form-group">
                <label>Kategori Pengeluaran</label>
                <select style="width: 100%;" class="form-control custom-select" name="idKategoriPengeluaran" placeholder="Kategori Pengeluaran"></select>

                <span class="invalid-feedback"></span>
            </div>
            <div class="form-group user-select">
                <label>Nama Karyawan</label>
                <select style="width: 100%;" class="form-control custom-select" name="idUser" placeholder="Nama Karyawan"></select>

                <span class="invalid-feedback"></span>
            </div>
            <div class="form-group">
                <label>Keterangan</label>
                <textarea class="form-control" name="keterangan" placeholder="Keterangan"></textarea>

                <span class="invalid-feedback"></span>
            </div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-primary" type="submit">Simpan</button>
            <button class="btn btn-secondary" data-dismiss="modal">Batal</button>
        </div>
    </form>
    </div>
    </div>
    </div>

    <div class="modal" id="import">
    <div class="modal-dialog">
    <div class="modal-content">
    <form action="<?php echo e(route('finance.import')); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="modal-header">
            <h5 class="modal-title">Import Excel</h5>
            <button class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body">
            <div class="form-group">
                <label>File Excel</label>
                <div class="custom-file">
                    <label class="custom-file-label">Browse</label>
                    <input type="file" class="custom-file-input" name="file">
                <span class="invalid-feedback"></span>
                </div>

            </div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-primary" type="submit">Simpan</button>
            <button class="btn btn-secondary" data-dismiss="modal">Batal</button>
        </div>
    </form>
    </div>
    </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('css'); ?>
    
    <link rel="stylesheet" href="<?php echo e(asset('sufee-admin/vendors/datatables.net-bs4/css/dataTables.bootstrap4.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('sufee-admin/vendors/select2/css/select2.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('sufee-admin/vendors/select2-bootstrap4-theme/select2-bootstrap4.min.css')); ?>">

<?php $__env->stopPush(); ?>

<?php $__env->startPush('js'); ?>
    
    <script src="<?php echo e(asset('sufee-admin/vendors/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('sufee-admin/vendors/datatables.net-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('sufee-admin/vendors/select2/js/select2.full.min.js')); ?>"></script>
    <script src="<?php echo e(asset('sufee-admin/vendors/bs-custom-file-input/bs-custom-file-input.min.js')); ?>"></script>
    
    <script>

        const ajaxUrl = '<?php echo e(route('finance.datatables')); ?>'
        const updateUrl = '<?php echo e(route('finance.update', ':id')); ?>'
        const deleteUrl = '<?php echo e(route('finance.destroy', ':id')); ?>'
        const printUrl = '<?php echo e(route('finance.printall')); ?>'
        const categoryUrl = '<?php echo e(route('category_finance.select')); ?>'
        const userUrl = '<?php echo e(route('user.select')); ?>'
        const csrf = '<?php echo e(csrf_token()); ?>'
    </script>

    <script src="<?php echo e(asset('js/expend.js')); ?>"></script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('_layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ibrahimalanshor/Documents/freelance/Penyesuaian/tokobuku/resources/views/expend/index.blade.php ENDPATH**/ ?>