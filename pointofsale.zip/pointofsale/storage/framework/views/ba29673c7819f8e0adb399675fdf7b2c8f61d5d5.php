<table>
    <thead>
        <tr>
            <th>ID Penjualan</th>
            <th>ID Buku</th>
            <th>Tanggal</th>
            <th>Nama Obat</th>
            <th>Status</th>
            <th>Harga</th>
            <th>Jumlah</th>
            <th>Disc</th>
            <th>PPN</th>
            <th>Total</th>
            <th>Kasir</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $success; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($transaction->idPenjualan); ?></td>
                <td><?php echo e($transaction->idBuku); ?></td>
                <td><?php echo e($transaction->transaction->tanggal); ?></td>
                <td><?php echo e($transaction->obat); ?></td>
                <td><?php echo e($transaction->transaction->status ? 'berhasil' : 'batal'); ?></td>
                <td><?php echo e($transaction->hargaJual); ?></td>
                <td><?php echo e($transaction->jumlah); ?></td>
                <td><?php echo e(round($transaction->disc)); ?></td>
                <td><?php echo e($transaction->ppn); ?></td>
                <td><?php echo e($transaction->jumlah * $transaction->hargaJual - round($transaction->disc) + $transaction->ppn); ?></td>
                <td><?php echo e($transaction->transaction->namaUser); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <tr></tr>
        <?php $__currentLoopData = $cancel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($transaction->idPenjualan); ?></td>
                <td><?php echo e($transaction->idBuku); ?></td>
                <td><?php echo e($transaction->transaction->tanggal); ?></td>
                <td><?php echo e($transaction->judul); ?></td>
                <td><?php echo e($transaction->transaction->status ? 'berhasil' : 'batal'); ?></td>
                <td><?php echo e($transaction->hargaJual); ?></td>
                <td><?php echo e($transaction->jumlah); ?></td>
                <td><?php echo e(round($transaction->disc)); ?></td>
                <td><?php echo e($transaction->ppn); ?></td>
                <td><?php echo e($transaction->jumlah * $transaction->hargaJual - round($transaction->disc) + $transaction->ppn); ?></td>
                <td><?php echo e($transaction->transaction->namaUser); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH /usr/local/var/www/pointofsale/resources/views/transaction/detail_transaction_export.blade.php ENDPATH**/ ?>