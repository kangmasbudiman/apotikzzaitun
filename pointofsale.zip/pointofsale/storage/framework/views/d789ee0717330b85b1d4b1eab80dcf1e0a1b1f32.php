<?php $__env->startSection('title', 'Ganti Password'); ?>

<?php $__env->startSection('content'); ?>
	
	<div class="row">
		<div class="col-sm-5 mx-auto">

			<?php if(session('success')): ?>
				<div class="alert alert-success alert-dismissible">
					<?php echo e(session('success')); ?>

					<button class="close" data-dismiss="alert">&times;</button>
				</div>
			<?php endif; ?>
			
			<div class="card">
			<form action="<?php echo e(route('change_password')); ?>" method="post">
				<?php echo method_field('PATCH'); ?>
				<?php echo csrf_field(); ?>
				<div class="card-header">
					<h2 class="h6 mb-0 font-weight-bold card-title">Ganti Password</h2>
				</div>
				<div class="card-body">
					<div class="form-group">
						<label>Password Baru</label>
						<input type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" placeholder="Password Baru" autofocus>

						<?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
							<span class="invalid-feedback"><?php echo e($message); ?></span>
						<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
					</div>
					<div class="form-group">
						<label>Konfirmasi Password</label>
						<input type="password" class="form-control" name="password_confirmation" placeholder="Konfirmasi Password">
					</div>
				</div>
				<div class="card-footer">
					<button class="btn btn-primary" type="submit">Simpan</button>
				</div>
			</div>
		</div>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('_layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tokobuku\resources\views/change_password.blade.php ENDPATH**/ ?>