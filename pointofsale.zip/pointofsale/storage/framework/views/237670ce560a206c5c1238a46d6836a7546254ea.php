<aside id="left-panel" class="left-panel">
<nav class="navbar navbar-expand-sm navbar-default">

    <div class="navbar-header">
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#main-menu" aria-controls="main-menu" aria-expanded="false" aria-label="Toggle navigation">
            <i class="fa fa-bars"></i>
        </button>
        <a class="navbar-brand" href="./">Kasir</a>
    </div>

    <div id="main-menu" class="main-menu collapse navbar-collapse">
        <ul class="nav navbar-nav">

            <li class="<?php echo e(active('/')); ?>">
                <a href="<?php echo e(route('home')); ?>"> <i class="menu-icon fa fa-dashboard"></i>Dashboard</a>
            </li>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isAdmin')): ?>
            <h3 class="menu-title">Master Data</h3>
            <li class="<?php echo e(active('stuff', 'group')); ?>">
                <a href="<?php echo e(route('stuff.index')); ?>"> <i class="menu-icon fa fa-archive"></i>Buku</a>
            </li>
            <li class="<?php echo e(active('distributor', 'group')); ?>">
                <a href="<?php echo e(route('distributor.index')); ?>"> <i class="menu-icon fa fa-truck"></i>Distributor</a>
            </li>
                <li class="<?php echo e(active('user', 'group')); ?>">
                    <a href="<?php echo e(route('user.index')); ?>"> <i class="menu-icon fa fa-user"></i>Pengguna</a>
                </li>
            <?php endif; ?>


            <h3 class="menu-title">Menu</h3>
            <li class="<?php echo e(active('stock', 'group')); ?>">
                <a href="<?php echo e(route('stock.index')); ?>"> <i class="menu-icon fa fa-truck"></i>Stok</a>
            </li>
            <li class="<?php echo e(active('transaction', 'group')); ?>">
                <a href="<?php echo e(route('transaction.index')); ?>"> <i class="menu-icon fa fa-money"></i>Transaksi</a>
            </li>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isAdmin')): ?>
                <li class="<?php echo e(active('report', 'group')); ?>">
                    <a href="<?php echo e(route('report')); ?>"> <i class="menu-icon fa fa-file"></i>Laporan</a>
                </li>
            <?php endif; ?>

            <h3 class="menu-title">Pengaturan</h3>
            <li class="<?php echo e(active('change_password')); ?>">
                <a href="<?php echo e(route('change_password')); ?>"> <i class="menu-icon fa fa-key"></i>Ganti Password</a>
            </li>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isAdmin')): ?>
                <li class="<?php echo e(active('setting')); ?>">
                    <a href="<?php echo e(route('setting.index')); ?>"> <i class="menu-icon fa fa-cog"></i>Pengaturan</a>
                </li>
            <?php endif; ?>
        </ul>
    </div><!-- /.navbar-collapse -->
</nav>
</aside><?php /**PATH /home/ibrahimalanshor/Documents/freelance/kasir_change_db/laravel-8-kasir/resources/views/_partials/sidebar.blade.php ENDPATH**/ ?>