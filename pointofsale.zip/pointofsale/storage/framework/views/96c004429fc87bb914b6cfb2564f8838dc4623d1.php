<?php $__env->startSection('title', $stuff->name); ?>

<?php $__env->startSection('content'); ?>
	
	<div class="row">
		<div class="col-sm-6 mx-auto">
			<div class="card">
				<div class="card-header">
					<h2 class="h6 font-weight-bold mb-0 card-title">Detail Barang</h2>
				</div>
				<div class="card-body">
					<dl class="row">
						<dt class="col-sm-4">No ISBN</dt>
						<dd class="col-sm-8"><?php echo e($stuff->noisbn); ?></dd>
						<dt class="col-sm-4">Judul</dt>
						<dd class="col-sm-8"><?php echo e($stuff->judul); ?></dd>
						<dt class="col-sm-4">Penulis</dt>
						<dd class="col-sm-8"><?php echo e($stuff->penulis); ?></dd>
						<dt class="col-sm-4">Penerbit</dt>
						<dd class="col-sm-8"><?php echo e($stuff->penerbit); ?></dd>
						<dt class="col-sm-4">Tahun</dt>
						<dd class="col-sm-8"><?php echo e($stuff->tahun); ?></dd>
						<dt class="col-sm-4">Stok</dt>
						<dd class="col-sm-8"><?php echo e($stuff->stock); ?></dd>
						<dt class="col-sm-4">Harga Pokok</dt>
						<dd class="col-sm-8"><?php echo e($stuff->hargaPokok); ?></dd>
						<dt class="col-sm-4">HargaJual</dt>
						<dd class="col-sm-8"><?php echo e($stuff->hargaJual); ?></dd>
						<dt class="col-sm-4">PPN</dt>
						<dd class="col-sm-8"><?php echo e($stuff->ppn); ?></dd>
						<dt class="col-sm-4">Disc</dt>
						<dd class="col-sm-8"><?php echo e($stuff->disc); ?></dd>
					</dl>
				</div>
				<div class="card-footer">
					<a href="<?php echo e(route('stuff.index')); ?>" class="btn btn-secondary">Kembali</a>
				</div>
			</div>
		</div>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('_layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kasitokobuku\resources\views/stuff/show.blade.php ENDPATH**/ ?>