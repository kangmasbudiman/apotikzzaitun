<?php $__env->startSection('title', 'Barang'); ?>

<?php $__env->startSection('content'); ?>
	
	<?php if(session('success')): ?>
		<div class="alert alert-success alert-dismissible">
			<?php echo e(session('success')); ?>

			<button class="close" data-dismiss="alert">&times;</button>
		</div>
	<?php endif; ?>

	<div id="alert"></div>
	<div class="card">
		<div class="card-header d-flex justify-content-between align-items-center">
			<h2 class="h6 font-weight-bold mb-0 card-title">Data Barang</h2>
			<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isAdminGudang')): ?>
				<div>
					<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isAdmin')): ?>
					    <button data-toggle="collapse" data-target="#filter" class="btn btn-warning btn-sm">Print</button>
					<?php endif; ?>
					<a href="<?php echo e(route('barcode.search')); ?>" class="btn btn-warning btn-sm mr-1">Print Semua Barcode</a>
	                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isAdmin')): ?>
	                	<button class="btn btn-success btn-sm" data-toggle="modal" data-target="#import">Import Excel</button>
		                <a class="btn btn-success btn-sm" href="<?php echo e(route('stuff.export')); ?>">Export Excel</a>
	                <?php endif; ?>
					<a href="<?php echo e(route('stuff.create')); ?>" class="btn btn-primary btn-sm">Tambah Data</a>
				</div>
			<?php endif; ?>
		</div>
		<div class="collapse" id="filter">
			<form action="<?php echo e(route('stuff.printall')); ?>" class="card-body border-bottom" target="_blank">
				<div class="form-row">
					<div class="col-sm-2">
						<div class="form-group">
							<label>Penerbit</label>
							<select name="penerbit" style="width: 100%;" class="form-control custom-select <?php $__errorArgs = ['penerbit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
								<option value="" selected>Penerbit</option>
								<?php $__empty_1 = true; $__currentLoopData = $penerbit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
									<option value="<?php echo e($item->penerbit); ?>"><?php echo e($item->penerbit); ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
									<option disabled selected>Kosong</option>
								<?php endif; ?>
							</select>

							<?php $__errorArgs = ['penerbit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
								<span class="invalid-feedback"><?php echo e($message); ?></span>
							<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
						</div>
					</div>
					<div class="col-sm-2">
						<div class="form-group">
							<label>Tahun</label>
							<select name="tahun" style="width: 100%;" class="form-control custom-select <?php $__errorArgs = ['tahun'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
								<option value="" selected>Tahun</option>
								<?php $__empty_1 = true; $__currentLoopData = $tahun; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
									<option value="<?php echo e($item->tahun); ?>"><?php echo e($item->tahun); ?></option>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
									<option disabled selected>Kosong</option>
								<?php endif; ?>
							</select>

							<?php $__errorArgs = ['tahun'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
								<span class="invalid-feedback"><?php echo e($message); ?></span>
							<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
						</div>
					</div>
				</div>
				<button class="btn btn-warning filter mr-1" type="button">Filter</button>
				<button class="btn btn-primary" type="submit">Print</button>
				<button class="btn btn-danger" type="button" id="remove-all">Hapus</button>
			</form>
		</div>
		
		<div class="card-body">
			<div class="table-responsive">
				<table id="data" class="table table-bordered" width="100%">
					<thead>
						<tr>
							<th><input type="checkbox" id="select-all"></th>
							<th>No</th>
							<th>ID Buku</th>
							<th>Barcode</th>
							<th>Nama Buku</th>
							<th>Penerbit</th>
							<th>Tahun</th>
							<th>Stok</th>
							<th>Harga Jual</th>
							<th>Action</th>
						</tr>
					</thead>
				</table>
			</div>
		</div>
	</div>

	<div class="modal" id="edit">
	<div class="modal-dialog modal-dialog-scrollable modal-dialog-centered">
	<div class="modal-content">
	<form class="post" action="" method="post">
		<?php echo csrf_field(); ?>
		<?php echo method_field('PUT'); ?>
		<div class="modal-header">
			<h5 class="modal-title">Edit Data</h5>
			<button class="close" data-dismiss="modal">&times;</button>
		</div>
		<div class="modal-body">
			<input type="hidden" name="id">
			<div class="form-group">
				<label>No ISBN</label>
				<input type="text" class="form-control <?php $__errorArgs = ['noisbn'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="noisbn" placeholder="No ISBN" value="<?php echo e(old('noisbn')); ?>" autofocus>

				<span class="invalid-feedback"></span>
			</div>
			<div class="form-group">
				<label>Barcode</label>
				<input type="text" class="form-control <?php $__errorArgs = ['barcode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="barcode" placeholder="Barcode" value="<?php echo e(old('barcode')); ?>">

				<span class="invalid-feedback"></span>
			</div>
			<div class="form-row">
				<div class="col">
					<div class="form-group">
						<label>Judul</label>
						<input type="text" class="form-control <?php $__errorArgs = ['judul'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="judul" placeholder="Judul" value="<?php echo e(old('judul')); ?>">

						<span class="invalid-feedback"></span>
					</div>
				</div>
				<div class="col">
					<div class="form-group">
						<label>Penulis</label>
						<input type="text" class="form-control <?php $__errorArgs = ['penulis'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="penulis" placeholder="Penulis" value="<?php echo e(old('penulis')); ?>">

						<span class="invalid-feedback"></span>
					</div>
				</div>
			</div>
			<div class="form-row">
				<div class="col">
					<div class="form-group">
						<label>Kategori</label>
						<select class="form-control custom-select" name="idKategori" style="width: 100%;"></select>

						<span class="invalid-feedback"></span>
					</div>
				</div>
				<div class="col">
					<div class="form-group">
						<label>Rak</label>
						<select class="form-control custom-select" name="idRak" style="width: 100%;"></select>

						<span class="invalid-feedback"></span>
					</div>
				</div>
			</div>
			<div class="form-row">
				<div class="col">
					<div class="form-group">
						<label>Penerbit</label>
						<input type="text" class="form-control <?php $__errorArgs = ['penerbit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="penerbit" placeholder="Penerbit" value="<?php echo e(old('penerbit')); ?>">

						<span class="invalid-feedback"></span>
					</div>
				</div>
				<div class="col">
					<div class="form-group">
						<label>Tahun</label>
						<input type="numer" class="form-control <?php $__errorArgs = ['tahun'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="tahun" placeholder="Tahun" value="<?php echo e(old('tahun')); ?>">

						<span class="invalid-feedback"></span>
					</div>
				</div>
			</div>
			<div class="form-row">
				<div class="col">
					<div class="form-group">
						<label>Harga Pokok</label>
						<div class="input-group">
							<div class="input-group-prepend">
								<span class="input-group-text">Rp</span>
							</div>
							<input type="text" class="form-control price <?php $__errorArgs = ['hargaPokok'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="hargaPokok" placeholder="Harga Pokok" value="<?php echo e(old('hargaPokok')); ?>">

							<span class="invalid-feedback"></span>
						</div>
					</div>
				</div>
				<div class="col">
					<div class="form-group">
						<label>Harga Jual</label>
						<div class="input-group">
							<div class="input-group-prepend">
								<span class="input-group-text">Rp</span>
							</div>
							<input type="text" class="form-control price <?php $__errorArgs = ['hargaJual'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="hargaJual" placeholder="Harga Jual" value="<?php echo e(old('hargaJual')); ?>">

							<span class="invalid-feedback"></span>
						</div>
					</div>
				</div>
			</div>
			<div class="form-row">
				<div class="col">
					<div class="form-group">
						<label>Disc</label>
						<input type="numer" class="form-control <?php $__errorArgs = ['disc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="disc" placeholder="Disc" value="<?php echo e(old('disc')); ?>">

						<span class="invalid-feedback"></span>
					</div>
				</div>
			</div>
		</div>
		<div class="modal-footer">
			<button class="btn btn-primary" type="submit">Simpan</button>
			<button class="btn btn-secondary" data-dismiss="modal">Batal</button>
		</div>
	</form>
	</div>
	</div>
	</div>

    <div class="modal" id="import">
    <div class="modal-dialog">
    <div class="modal-content">
    <form action="<?php echo e(route('stuff.import')); ?>" class="post" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="modal-header">
            <h5 class="modal-title">Import Excel</h5>
            <button class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body">
            <div class="form-group">
                <label>File Excel</label>
                <div class="custom-file">
                    <label class="custom-file-label">Browse</label>
                    <input type="file" class="custom-file-input" name="file">
                <span class="invalid-feedback"></span>
                </div>

            </div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-primary" type="submit">Simpan</button>
            <button class="btn btn-secondary" data-dismiss="modal">Batal</button>
        </div>
    </form>
    </div>
    </div>
    </div>

	<div class="modal" id="show">
	<div class="modal-dialog modal-dialog-scrollable modal-dialog-centered">
	<div class="modal-content">
		<div class="modal-header">
			<h5 class="modal-title">Detail Buku</h5>
			<button class="close" data-dismiss="modal">&times;</button>
		</div>
		<div class="modal-body">
			<table class="table table-bordered table-striped">
				<tr>
					<th>ID Buku</th>
					<td data-key="idBuku"></td>
				</td>
				<tr>
					<th>No ISBN</th>
					<td data-key="noisbn"></td>
				</td>
				<tr>
					<th>Barcode</th>
					<td data-key="barcode"></td>
				</td>
				<tr>
					<th>Kategori</th>
					<td data-key="category"></td>
				</td>
				<tr>
					<th>Judul</th>
					<td data-key="judul"></td>
				</td>
				<tr>
					<th>Rak</th>
					<td data-key="rack"></td>
				</td>
				<tr>
					<th>Penulis</th>
					<td data-key="penulis"></td>
				</td>
				<tr>
					<th>Penerbit</th>
					<td data-key="penerbit"></td>
				</td>
				<tr>
					<th>Tahun</th>
					<td data-key="tahun"></td>
				</td>
				<tr>
					<th>Stok</th>
					<td data-key="stock"></td>
				</td>
				<tr>
					<th>Harga Pokok</th>
					<td data-key="purchase_price"></td>
				</td>
				<tr>
					<th>HargaJual</th>
					<td data-key="price"></td>
				</td>
				<tr>
					<th>Disc</th>
					<td data-key="disc"></td>
			</td>
			</table>
		</div>
		<div class="modal-footer">
			<button class="btn btn-secondary" data-dismiss="modal">Batal</button>
		</div>
	</div>
	</div>
	</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('css'); ?>
	
	<link rel="stylesheet" href="<?php echo e(asset('sufee-admin/vendors/datatables.net-bs4/css/dataTables.bootstrap4.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('sufee-admin/vendors/select2/css/select2.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('sufee-admin/vendors/select2-bootstrap4-theme/select2-bootstrap4.min.css')); ?>">

<?php $__env->stopPush(); ?>

<?php $__env->startPush('js'); ?>
	
	<script src="<?php echo e(asset('sufee-admin/vendors/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
	<script src="<?php echo e(asset('sufee-admin/vendors/datatables.net-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>
	<script src="<?php echo e(asset('sufee-admin/vendors/select2/js/select2.full.min.js')); ?>"></script>
    <script src="<?php echo e(asset('sufee-admin/vendors/bs-custom-file-input/bs-custom-file-input.min.js')); ?>"></script>

	<script>
		const ajaxUrl = '<?php echo e(route('stuff.datatables')); ?>'
		const updateUrl = '<?php echo e(route('stuff.update', ':id')); ?>'
		const deleteUrl = '<?php echo e(route('stuff.destroy', ':id')); ?>'
		const destroyBatchUrl = '<?php echo e(route('stuff.destroy-batch')); ?>'
		const categoryUrl = '<?php echo e(route('category.select')); ?>'
		const rackUrl = '<?php echo e(route('rack.select')); ?>'
		const csrf = '<?php echo e(csrf_token()); ?>'
	</script>

	<script src="<?php echo e(asset('js/stuff.js')); ?>"></script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('_layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ibrahimalanshor/Documents/freelance/Penyesuaian/Source Code/tokobukuv4/resources/views/stuff/index.blade.php ENDPATH**/ ?>