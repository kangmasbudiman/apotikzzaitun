<?php $__env->startSection('title', 'Edit Stok Opname'); ?>

<?php $__env->startSection('content'); ?>

  <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('opname.edit', ['id' => ''.e($id).''])->html();
} elseif ($_instance->childHasBeenRendered('DmP8Y0U')) {
    $componentId = $_instance->getRenderedChildComponentId('DmP8Y0U');
    $componentTag = $_instance->getRenderedChildComponentTagName('DmP8Y0U');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('DmP8Y0U');
} else {
    $response = \Livewire\Livewire::mount('opname.edit', ['id' => ''.e($id).'']);
    $html = $response->html();
    $_instance->logRenderedChild('DmP8Y0U', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('_layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /usr/local/var/www/pointofsale/resources/views/opname/edit.blade.php ENDPATH**/ ?>