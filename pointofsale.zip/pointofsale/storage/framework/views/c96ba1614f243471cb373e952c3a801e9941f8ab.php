<?php $__env->startSection('title', 'Tambah Stok Opname'); ?>

<?php $__env->startSection('content'); ?>

  <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('opname.create', [])->html();
} elseif ($_instance->childHasBeenRendered('V0lKmjD')) {
    $componentId = $_instance->getRenderedChildComponentId('V0lKmjD');
    $componentTag = $_instance->getRenderedChildComponentTagName('V0lKmjD');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('V0lKmjD');
} else {
    $response = \Livewire\Livewire::mount('opname.create', []);
    $html = $response->html();
    $_instance->logRenderedChild('V0lKmjD', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('_layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /usr/local/var/www/pointofsale/resources/views/opname/create.blade.php ENDPATH**/ ?>