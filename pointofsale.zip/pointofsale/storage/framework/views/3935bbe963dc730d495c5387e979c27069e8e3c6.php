<?php $__env->startSection('title', 'Laporan Pendapatan Bulanan'); ?>

<?php $__env->startSection('content'); ?>
    
            
    <div class="card">
        <div class="card-header d-flex align-items-center justify-content-between">
            <h2 class="h6 mb-0 font-weight-bold card-title">Laporan Pendapatan Bulanan</h2>
            <a href="<?php echo e(route('report.transaction.print.month')); ?>" target="_blank" class="btn btn-sm btn-danger">Print</a>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-striped" width="100%">
                    <thead align="center">
                        <tr>
                            <th>No</th>
                            <th>Tanggal</th>
                            <th>Total Pendapatan</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $total = 0
                        ?>
                        <?php $__empty_1 = true; $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr align="center">
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e(date('d M', strtotime($report->tanggal))); ?></td>
                                <td>Rp <?php echo e(number_format($report->total)); ?></td>
                            </tr>

                            <?php
                                $total += $report->total
                            ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="3" align="center">Kosong</td>
                            </tr>
                        <?php endif; ?>
                        <?php if($reports): ?>
                            <tr align="center">
                                <th colspan="2" align="center"><center>Total Seluruh Pendapatan</center></th>
                                <th>Rp <?php echo e(number_format($total)); ?></th>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('_layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ibrahimalanshor/Documents/freelance/Penyesuaian/Source Code/tokobukuv4/resources/views/report/transaction-month.blade.php ENDPATH**/ ?>