<div class="col-sm-4">
    <form class="card" wire:submit.prevent="save">
        <div class="card-header">
            <h2 class="card-title h6 mb-0 font-weight-bold">Tambah Data</h2>
        </div>
        <div class="card-body">
            <div class="form-group">
                <label>Barcode</label>
                <div class="input-group">
                    <input name="barcode" class="form-control <?php $__errorArgs = ['barcode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Barcode" wire:model="barcode"></input>
                    <div class="input-group-append">
                        <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#stuff"><i class="fa fa-search"></i></button>
                    </div>

                    <?php $__errorArgs = ['barcode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="invalid-feedback"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="form-group">
                <label>Nama Buku</label>
                <input type="text" class="form-control" placeholder="Nama Buku" name="judul" disabled>
            </div>
            <div class="form-group">
                <label>Stok Sistem</label>
                <input type="text" class="form-control" placeholder="Stok" name="stock" disabled>
            </div>
            <div class="form-group">
                <label>Harga Pokok</label>
                <input type="text" class="form-control" placeholder="Harga Pokok" name="hargaPokok" disabled>
            </div>
            <div class="form-group">
                <label>Stok Nyata</label>
                <input type="number" class="form-control <?php $__errorArgs = ['stokNyata'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Stok Nyata" wire:model.defer="stokNyata">

                <?php $__errorArgs = ['stokNyata'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group">
                <label>Keterangan</label>
                <textarea class="form-control <?php $__errorArgs = ['keterangan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Keterangan" wire:model.defer="keterangan"></textarea>

                <?php $__errorArgs = ['keterangan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
        <div class="card-footer">
            <a href="<?php echo e(route('opname.index')); ?>" class="btn btn-secondary">Batal</a>
            <button class="btn btn-primary" type="submit" wire:loadint.attr="disabled" wire:target="save">Simpan</button>
        </div>
    </form>

    <div wire:ignore>
        <?php echo $__env->make('stuff.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>

<?php $__env->startPush('js'); ?>

    <script>

        const $ = jQuery
        
        const csrf = '<?php echo e(csrf_token()); ?>'
        const buku = $('[name=barcode]')

        const setStuff = data => {
            for (let [name, value] of Object.entries(data)) {
                if (name === 'ppn') {
                    $(`[name=${name}]`).val(value + ' %')
                } else {
                    $(`[name=${name}]`).val(value)
                }
            }
        }

        const table = $('#stuff table').DataTable({
            serverSide: true,
            processing: true,
            ajax: {
                url: ajaxUrl,
                type: 'post',
                data: {
                    _token: csrf
                }
            },
            columns: [
                { data: 'DT_RowIndex' },
                { data: 'idBuku' },
                { data: 'barcode' },
                { data: 'judul' },
                { data: 'purchase_price' },
                { data: 'stock' },
                {
                    data: null,
                    render: () => {
                        return `<button class="btn btn-sm btn-primary">Pilih</button>`
                    }
                }
            ],
        })

        $('#stuff tbody').on('click', 'button', function () {
            const data = table.row($(this).parents('tr')).data()

            buku.val(data.barcode)

            setStuff(data)
            window.livewire.find('<?php echo e($_instance->id); ?>').set('barcode', data.barcode)
            window.livewire.find('<?php echo e($_instance->id); ?>').set('stokSistem', data.stock)

            $('#stuff').modal('hide')
        })

        $('.form-control').val('')
    </script>

<?php $__env->stopPush(); ?><?php /**PATH C:\xampp\htdocs\tokobuku\resources\views/livewire/opname/create.blade.php ENDPATH**/ ?>