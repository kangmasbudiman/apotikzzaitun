<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>

	<style>
		body {
			font-family: "Roboto";
			color: #333;
			font-size: 20px;
		}
		.heading {
			text-align: center;
			margin-bottom: 20px;
		}
		.title {
			font-size: 28px;
			color: #111;
		}
		hr {
			border: 0;
			border-top: 2px solid #000;
		}
		p {
			margin: 0;
		}
	</style>
</head>
<body>

<div class="heading">
	<p class="title">Toko Buku Kita</p>
	<p>JL. Clhideung No. 25 Tasikmalaya</p>
	<p>(0265) 9107713</p>
</div>
<hr>

<p class="title" style="margin: 20px 0;">List Buku</p>

<?php
	$total = 0;
?>
<table style="margin-bottom: 20px; border-collapse: collapse;" width="100%">
	<tr style="background-color: #111; color: white">
		<td style="border: 1px solid #111;padding: 5px 10px;">No</td>
		<td style="border: 1px solid #111;padding: 5px 10px;">ID Buku</td>
		<td style="border: 1px solid #111;padding: 5px 10px;">Judul</td>
		<td style="border: 1px solid #111;padding: 5px 10px;">Penulis</td>
		<td style="border: 1px solid #111;padding: 5px 10px;">Tahun</td>
		<td style="border: 1px solid #111;padding: 5px 10px;">Harga Pokok</td>
		<td style="border: 1px solid #111;padding: 5px 10px;">Harga Jual</td>
		<td style="border: 1px solid #111;padding: 5px 10px;">Stok</td>
	</tr>
	<?php
		$jumlah = 0;
	?>
	<?php $__currentLoopData = $stuffs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $buku): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<?php
			$jumlah += $buku->stock;
		?>
		<tr>
			<td valign="top" style="border: 1px solid #111;padding: 5px 10px;" width="5%" valign="top">
				<?php echo e($loop->iteration); ?>.
			</td>
			<td valign="top" style="border: 1px solid #111;padding: 5px 10px;" valign="top">
				<?php echo e($buku->idBuku); ?><br>
			</td>
			<td valign="top" style="border: 1px solid #111;padding: 5px 10px;">
				<?php echo e($buku->judul); ?><br>
			</td>
			<td valign="top" style="border: 1px solid #111;padding: 5px 10px;">
				<?php echo e($buku->penulis); ?><br>
			</td>
			<td valign="top" style="border: 1px solid #111;padding: 5px 10px;">
				<?php echo e($buku->tahun); ?><br>
			</td>
			<td valign="top" style="border: 1px solid #111;padding: 5px 10px;">
				<?php echo e(number_format($buku->hargaPokok)); ?>

			</td>
			<td valign="top" style="border: 1px solid #111;padding: 5px 10px;">
				<?php echo e(number_format($buku->hargaJual)); ?>

			</td>
			<td valign="top" style="border: 1px solid #111;padding: 5px 10px;">
				<?php echo e($buku->stock); ?>

			</td>
		</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<tr>
		<td style="border: 1px solid #111;padding: 5px 10px;" colspan="7" align="right">
			Jumlah
		</td>
		<td style="border: 1px solid #111;padding: 5px 10px;">
			<?php echo e($jumlah); ?>

		</td>
	</tr>
</table>

</body>
</html><?php /**PATH /home/ibrahimalanshor/Documents/freelance/kasir_change_db/laravel-8-kasir/resources/views/stuff/printall.blade.php ENDPATH**/ ?>