<div class="row">
	<div class="col-sm-4">
		<div class="card">
			<div class="card-header">
				<h2 class="card-title h6 mb-0 font-weight-bold">Transaksi</h2>
			</div>
			<div class="card-body">
				<div class="form-group">
					<label>No Faktur</label>
					<input type="text" class="form-control" name="id" value="<?php echo e($latestId); ?>" disabled>
				</div>
				<div class="form-group">
					<label>Tanggal</label>
					<input type="text" class="form-control" name="tanggal" value="<?php echo e(date('d/m/Y')); ?>" disabled>
				</div>
				<div class="form-group">
					<label>Operator</label>
					<input type="text" class="form-control" name="operator" value="<?php echo e(auth()->user()->nama); ?>" disabled>
				</div>
			</div>
		</div>
	</div>
	<div class="col-sm-4">
		<div class="card">
		<form wire:submit.prevent="store">
			<div class="card-header">
				<h2 class="card-title h6 mb-0 font-weight-bold">Input / Scan Buku</h2>
			</div>
			<div class="card-body">
				<?php if(session('error')): ?>
				    <div class="alert alert-danger alert-dismissible">
				        <?php echo e(session('error')); ?>

				        <button class="close" data-dismiss="alert">&times;</button>
				    </div>
				<?php endif; ?>
				<div class="form-group">
					<label>Barcode</label>
					<div class="input-group">
						<input placeholder="Barcode" class="form-control <?php $__errorArgs = ['barcode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model="barcode" autofocus/>
						<div class="input-group-append">
							<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#stuff"><i class="fa fa-search"></i></button>
						</div>
						
						<?php $__errorArgs = ['barcode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
							<span class="invalid-feedback"><?php echo e($message); ?></span>
						<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
					</div>
				</div>
				<hr>
				<div class="form-group">
					<label>Jumlah</label>
					<div class="input-group">
						<input type="number" class="form-control <?php $__errorArgs = ['total'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Jumlah" wire:model="total">
						<div class="input-group-append">
							<button class="btn btn-primary submit" wire:loading.attr="disabled" wire:target="store">Tambah</button>
						</div>
						
						<?php $__errorArgs = ['total'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
							<span class="invalid-feedback"><?php echo e($message); ?></span>
						<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
					</div>					
				</div>
			</div>
			
		</form>
		</div>
	</div>
	<div class="col-sm-4">
		<div class="card">
			<div class="card-header">
				<h2 class="card-title h6 mb-0 font-weight-bold">Data Buku</h2>
			</div>
			<div class="card-body">
				<div class="form-group">
					<label>Judul Buku</label>
					<input type="text" class="form-control" name="name" value="<?php echo e($stuff->judul ?? 'Judul'); ?>" disabled>
				</div>
				<div class="form-group">
					<label>Harga</label>
					<input type="text" class="form-control" name="price" value="<?php echo e(isset($stuff->hargaJual) ? 'Rp '.number_format($stuff->hargaJual) : 'Harga'); ?>" disabled>
				</div>
				<div class="form-group">
					<label>Stok</label>
					<input type="text" class="form-control" name="stock" value="<?php echo e($stuff->stock ?? 'Stok'); ?>" placeholder="Stok Barang" disabled>
				</div>
			</div>
		</div>
	</div>

	<div wire:ignore>
		<?php echo $__env->make('stuff.modal', ['type' => 'sell'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	</div>
</div>

<?php $__env->startPush('css'); ?>
	<link rel="stylesheet" href="<?php echo e(asset('sufee-admin/vendors/select2/css/select2.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('sufee-admin/vendors/select2-bootstrap4-theme/select2-bootstrap4.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('js'); ?>
	<script src="<?php echo e(asset('sufee-admin/vendors/select2/js/select2.min.js')); ?>"></script>

	<script>
		const $ = jQuery
		const csrf = '<?php echo e(csrf_token()); ?>'

		const book = $('[name=barcode]')

		window.addEventListener('reset', function () {
			book.empty()
		})

		$(document).ready(function () {
			// book.select2({
			// 	placeholder: 'Barcode',
			// 	theme: 'bootstrap4',
			// 	ajax: {
			// 		url: '<?php echo e(route('stuff.select')); ?>',
			// 		type: 'post',
			// 		data: params => ({
			// 			name: params.term,
			// 			_token: '<?php echo e(csrf_token()); ?>'
			// 		}),
			// 		processResults: res => {
			// 			res.map(stuff => stuff.text = `${stuff.barcode} - ${stuff.text}`);
			// 			return {
			// 				results: res
			// 			}
			// 		},
			// 		cache: true
			// 	}
			// })

			// book.on('select2:select', e => {
			// 	window.livewire.find('<?php echo e($_instance->id); ?>').set('barcode', e.params.data.id)
			// 	window.livewire.find('<?php echo e($_instance->id); ?>').search()
			// })

			const table = $('#stuff table').DataTable({
			    serverSide: true,
			    processing: true,
			    ajax: {
			        url: ajaxUrl,
			        type: 'post',
			        data: {
			            _token: csrf
			        }
			    },
			    columns: [
			        { data: 'DT_RowIndex' },
			        { data: 'idBuku' },
			        { data: 'barcode' },
			        { data: 'judul' },
			        { data: 'price' },
			        { data: 'stock' },
			        {
			            data: null,
			            render: () => {
			                return `<button class="btn btn-sm btn-primary">Pilih</button>`
			            }
			        }
			    ],
			})

			$('#stuff tbody').on('click', 'button', function () {
			    const data = table.row($(this).parents('tr')).data()

			    book.val(data.barcode)

			    window.livewire.find('<?php echo e($_instance->id); ?>').set('barcode', data.barcode)
			    window.livewire.find('<?php echo e($_instance->id); ?>').search()

			    $('#stuff').modal('hide')
			})

			window.addEventListener('reset-stuff', function () {
				table.ajax.reload()
			})

		})
	</script>
<?php $__env->stopPush(); ?><?php /**PATH C:\xampp\htdocs\tokobuku\resources\views/livewire/transaction/create.blade.php ENDPATH**/ ?>