<?php $__env->startSection('title', 'Laporan'); ?>

<?php $__env->startSection('content'); ?>
	
	<?php if(session('success')): ?>
		<div class="alert alert-success alert-dismissible">
			<?php echo e(session('success')); ?>

			<button class="close" data-dismiss="alert">&times;</button>
		</div>
	<?php endif; ?>

	<div id="alert"></div>
	<div class="card">
		<div class="card-header d-flex align-items-center justify-content-between">
			<h2 class="h6 font-weight-bold mb-0 card-title">Laporan</h2>
			<div>
				<button class="btn btn-sm btn-primary" data-toggle="collapse" data-target="#filter">Filter</button>
				<button class="btn btn-sm btn-warning print">Print</button>
			</div>
		</div>
		<div class="card-body border-bottom collapse form-row pb-4" id="filter">
			<div class="col-sm-3">
				<label>Dari</label>
				<input type="date" name="dari" placeholder="Tanggal" class="form-control">
			</div>
			<div class="col-sm-3">
				<label>Sampai</label>
				<input type="date" name="sampai" placeholder="Tanggal" class="form-control">
			</div>
			<div class="col-sm-3 d-flex align-items-end">
				<button class="btn btn-primary rounded filter">Filter</button>
			</div>
		</div>
		<div class="card-body">
			<div class="table-responsive">
				<table class="table table-bordered" width="100%">
					<thead>
						<tr>
							<th>No</th>
							<th>No Faktur</th>
							<th>Judul</th>
							<th>Harga</th>
							<th>Qty</th>
							<th>Total</th>
							<th>Kasir</th>
							<th>Action</th>
						</tr>
					</thead>
				</table>
			</div>
		</div>
	</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('css'); ?>
	
	<link rel="stylesheet" href="<?php echo e(asset('sufee-admin/vendors/datatables.net-bs4/css/dataTables.bootstrap4.min.css')); ?>">

<?php $__env->stopPush(); ?>

<?php $__env->startPush('js'); ?>
	
	<script src="<?php echo e(asset('sufee-admin/vendors/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
	<script src="<?php echo e(asset('sufee-admin/vendors/datatables.net-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>

	<script>
		const ajaxUrl = '<?php echo e(route('transaction.datatables')); ?>'
		const deleteUrl = '<?php echo e(route('transaction.destroy', ':id')); ?>'
		const printUrl = '<?php echo e(route('transaction.printall')); ?>'
		const csrf = '<?php echo e(csrf_token()); ?>'
	</script>

	<script src="<?php echo e(asset('js/report.js')); ?>"></script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('_layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ibrahimalanshor/Documents/freelance/tokobukuv2/resources/views/report.blade.php ENDPATH**/ ?>