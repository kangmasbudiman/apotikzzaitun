<?php $__env->startSection('title', 'Tambah Data Transaksi'); ?>

<?php $__env->startSection('content'); ?>
    
        
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('transaction.create', [])->html();
} elseif ($_instance->childHasBeenRendered('7IwBc9u')) {
    $componentId = $_instance->getRenderedChildComponentId('7IwBc9u');
    $componentTag = $_instance->getRenderedChildComponentTagName('7IwBc9u');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('7IwBc9u');
} else {
    $response = \Livewire\Livewire::mount('transaction.create', []);
    $html = $response->html();
    $_instance->logRenderedChild('7IwBc9u', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('transaction.data', [])->html();
} elseif ($_instance->childHasBeenRendered('1TEK4W6')) {
    $componentId = $_instance->getRenderedChildComponentId('1TEK4W6');
    $componentTag = $_instance->getRenderedChildComponentTagName('1TEK4W6');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('1TEK4W6');
} else {
    $response = \Livewire\Livewire::mount('transaction.data', []);
    $html = $response->html();
    $_instance->logRenderedChild('1TEK4W6', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('transaction.payment', [])->html();
} elseif ($_instance->childHasBeenRendered('znDXd8E')) {
    $componentId = $_instance->getRenderedChildComponentId('znDXd8E');
    $componentTag = $_instance->getRenderedChildComponentTagName('znDXd8E');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('znDXd8E');
} else {
    $response = \Livewire\Livewire::mount('transaction.payment', []);
    $html = $response->html();
    $_instance->logRenderedChild('znDXd8E', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('transaction.cetak', [])->html();
} elseif ($_instance->childHasBeenRendered('m77TUuz')) {
    $componentId = $_instance->getRenderedChildComponentId('m77TUuz');
    $componentTag = $_instance->getRenderedChildComponentTagName('m77TUuz');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('m77TUuz');
} else {
    $response = \Livewire\Livewire::mount('transaction.cetak', []);
    $html = $response->html();
    $_instance->logRenderedChild('m77TUuz', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    
    <?php $__env->startPush('js'); ?>
        <script>

            jQuery(function ($) {
                $('[name=money]').on('keyup', function() {
                    const number = Number(this.value.replace(/\D/g, ''))
                    const price = new Intl.NumberFormat().format(number)
                    
                    this.value = price
                }),
             
            

            }),
         



        </script>
    <?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('_layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /usr/local/var/www/pointofsale/resources/views/transaction/create.blade.php ENDPATH**/ ?>