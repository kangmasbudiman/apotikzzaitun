<?php $__env->startSection('title', 'Distributor'); ?>

<?php $__env->startSection('content'); ?>
	
	<?php if(session('success')): ?>
		<div class="alert alert-success alert-dismissible">
			<?php echo e(session('success')); ?>

			<button class="close" data-dismiss="alert">&times;</button>
		</div>
	<?php endif; ?>

	<div id="alert"></div>
	<div class="card">
		<div class="card-header d-flex justify-content-between align-items-center">
			<h2 class="h6 font-weight-bold mb-0 card-title">Data Distributor</h2>
			<a href="<?php echo e(route('distributor.create')); ?>" class="btn btn-primary btn-sm">Tambah Data</a>
		</div>
		<div class="card-body">
			<div class="table-responsive">
				<table class="table table-bordered" width="100%">
					<thead>
						<tr>
							<th>No</th>
							<th>Nama</th>
							<th>Alamat</th>
							<th>Telepon</th>
							<th>Action</th>
						</tr>
					</thead>
				</table>
			</div>
		</div>
	</div>

	<div class="modal">
	<div class="modal-dialog">
	<div class="modal-content">
	<form action="" method="post">
		<?php echo csrf_field(); ?>
		<?php echo method_field('PUT'); ?>
		<div class="modal-header">
			<h5 class="modal-title">Edit Data</h5>
			<button class="close" data-dismiss="modal">&times;</button>
		</div>
		<div class="modal-body">
			<input type="hidden" name="id">
			<div class="form-group">
				<label>Nama</label>
				<input type="text" class="form-control <?php $__errorArgs = ['namaDist'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="namaDist" placeholder="Nama" value="<?php echo e(old('namaDist')); ?>" autofocus>

				<?php $__errorArgs = ['namaDist'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
					<span class="invalid-feedback"><?php echo e($message); ?></span>
				<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			</div>
			<div class="form-group">
				<label>Telepon</label>
				<input type="number" class="form-control <?php $__errorArgs = ['telepon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="telepon" placeholder="Telepon" value="<?php echo e(old('telepon')); ?>">

				<?php $__errorArgs = ['telepon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
					<span class="invalid-feedback"><?php echo e($message); ?></span>
				<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			</div>
			<div class="form-group">
				<label>Alamat</label>
				<textarea class="form-control <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="alamat" placeholder="Alamat" value="<?php echo e(old('alamat')); ?>"></textarea>

				<?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
					<span class="invalid-feedback"><?php echo e($message); ?></span>
				<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
			</div>
		</div>
		<div class="modal-footer">
			<button class="btn btn-primary" type="submit">Simpan</button>
			<button class="btn btn-secondary" data-dismiss="modal">Batal</button>
		</div>
	</form>
	</div>
	</div>
	</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('css'); ?>
	
	<link rel="stylesheet" href="<?php echo e(asset('sufee-admin/vendors/datatables.net-bs4/css/dataTables.bootstrap4.min.css')); ?>">

	<style>
		table img{
			width: 100%;
			max-height: 100px;
			object-fit: cover;
		}
	</style>

<?php $__env->stopPush(); ?>

<?php $__env->startPush('js'); ?>
	
	<script src="<?php echo e(asset('sufee-admin/vendors/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
	<script src="<?php echo e(asset('sufee-admin/vendors/datatables.net-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>
	
	<script>

		const ajaxUrl = '<?php echo e(route('distributor.datatables')); ?>'
		const updateUrl = '<?php echo e(route('distributor.update', ':id')); ?>'
		const deleteUrl = '<?php echo e(route('distributor.destroy', ':id')); ?>'
		const csrf = '<?php echo e(csrf_token()); ?>'
	</script>

	<script src="<?php echo e(asset('js/distributor.js')); ?>"></script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('_layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kasitokobuku\resources\views/distributor/index.blade.php ENDPATH**/ ?>