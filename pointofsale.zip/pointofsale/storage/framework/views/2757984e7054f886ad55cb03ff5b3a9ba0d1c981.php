<div class="modal fade" id="stuff">
<div class="modal-dialog modal-xl modal-lg">
<div class="modal-content">
    <div class="modal-header">
        <h5 class="modal-title">Pilih Buku</h5>

        <button class="close" data-dismiss="modal">&times;</button>
    </div>
    <div class="modal-body">
        <div class="table-responsive">
            <table class="table table-bordered table-striped" width="100%">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Barcode</th>
                        <th>No ISBN</th>
                        <th>Nama</th>
                        <th>Harga Beli</th>
                        <th>Stok</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
            </table>
        </div>
    </div>
</div>
</div>
</div>

<?php $__env->startPush('css'); ?>
    
    <link rel="stylesheet" href="<?php echo e(asset('sufee-admin/vendors/datatables.net-bs4/css/dataTables.bootstrap4.min.css')); ?>">

<?php $__env->stopPush(); ?>

<?php $__env->startPush('js'); ?>
    
    <script src="<?php echo e(asset('sufee-admin/vendors/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('sufee-admin/vendors/datatables.net-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>

    <script>
        const ajaxUrl = '<?php echo e(route('stuff.datatables')); ?>'
    </script>

<?php $__env->stopPush(); ?><?php /**PATH /home/ibrahimalanshor/Documents/freelance/tokobukuv2/resources/views/stuff/modal.blade.php ENDPATH**/ ?>