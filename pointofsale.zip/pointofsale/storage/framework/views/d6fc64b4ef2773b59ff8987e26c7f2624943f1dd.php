<table>
    <thead>
        <tr>
            <th>ID Pembelian</th>
            <th>Tanggal</th>
            <th>Total</th>
            <th>ID User</th>
            <th>Distributor</th>
            <th>User</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $stocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stock): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($stock->idPembelian); ?></td>
                <td><?php echo e($stock->tanggal); ?></td>
                <td><?php echo e($stock->total); ?></td>
                <td><?php echo e($stock->idUser); ?></td>
                <td><?php echo e($stock->namaDist); ?></td>
                <td><?php echo e($stock->namaUser); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH /home/ibrahimalanshor/Documents/freelance/Penyesuaian/Source Code/tokobukuv4/resources/views/stock/export.blade.php ENDPATH**/ ?>