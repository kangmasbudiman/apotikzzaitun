<div class="col-sm-4">
    <form class="card" wire:submit.prevent="save">
        <div class="card-header">
            <h2 class="card-title h6 mb-0 font-weight-bold">Edit Data</h2>
        </div>
        <div class="card-body">
            
            <div class="form-group">
                <label>Nama Buku</label>
                <input type="text" class="form-control" placeholder="Nama Buku" name="judul" value="<?php echo e($opname->judul); ?>" disabled>
            </div>
            <div class="form-group">
                <label>Stok Sistem</label>
                <input type="text" class="form-control" placeholder="Stok" name="stock" value="<?php echo e($opname->stokSistem); ?>" disabled>
            </div>
            <div class="form-group">
                <label>Harga Pokok</label>
                <input type="text" class="form-control" placeholder="Harga Pokok" name="hargaPokok" value="<?php echo e($opname->hargaPokok); ?>" disabled>
            </div>
            <div class="form-group">
                <label>Stok Nyata</label>
                <input type="text" class="form-control <?php $__errorArgs = ['opname.stokNyata'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Stok Nyata" wire:model.defer="opname.stokNyata">

                <?php $__errorArgs = ['opname.stokNyata'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group">
                <label>Keterangan</label>
                <textarea class="form-control <?php $__errorArgs = ['opname.keterangan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Keterangan" wire:model.defer="opname.keterangan"></textarea>

                <?php $__errorArgs = ['opname.keterangan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="invalid-feedback"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
        <div class="card-footer">
            <a href="<?php echo e(route('opname.index')); ?>" class="btn btn-secondary">Batal</a>
            <button class="btn btn-primary" type="submit" wire:loadint.attr="disabled" wire:target="save">Simpan</button>
        </div>
    </form>


</div>

<?php /**PATH /usr/local/var/www/pointofsale/resources/views/livewire/opname/edit.blade.php ENDPATH**/ ?>