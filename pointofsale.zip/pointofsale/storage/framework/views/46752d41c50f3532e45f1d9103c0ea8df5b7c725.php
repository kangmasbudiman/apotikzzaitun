<div>
	<div class="modal fade" id="payment" wire:ignore.self>
	<div class="modal-dialog">
	<div class="modal-content">
		<form wire:submit.prevent="submit">
			<div class="modal-header">
				<h2 class="h5 modal-title">Pembayaran Distributor</h2>
				<button class="close" data-dismiss="modal">&times;</button>
			</div>
			<div class="modal-body">
		
				<div class="form-group">
					<label>Faktur</label>
					<div class="input-group">
					
					<input type="text" class="form-control <?php $__errorArgs = ['faktur'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Faktur" wire:model="faktur" name="faktur">

					<?php $__errorArgs = ['faktur'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
						<span class="invalid-feedback"><?php echo e($message); ?></span>
					<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
					</div>
				</div>

				<div class="form-group">
					<label>Jatuh Tempo</label>
					<div class="input-group">
					
					<input type="date" class="form-control <?php $__errorArgs = ['jatuhtempo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Faktur" wire:model="jatuhtempo" name="jatuhtempo">

					<?php $__errorArgs = ['jatuhtempo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
						<span class="invalid-feedback"><?php echo e($message); ?></span>
					<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
					</div>
				</div>
				<div class="form-group">
					<label>Tempo (Hari)</label>
					<div class="input-group">
					
					<input type="text" class="form-control <?php $__errorArgs = ['tempo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Tempo Pembayaran (Hari)" wire:model="tempo" name="tempo">

					<?php $__errorArgs = ['tempo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
						<span class="invalid-feedback"><?php echo e($message); ?></span>
					<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
					</div>
				</div>


				<div class="form-group <?php $__errorArgs = ['distributor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
					<label>Distributor</label>
					<div wire:ignore>
						<select name="distributor" class="form-control custom-select" style="width: 100%;"></select>
					</div>

					<?php $__errorArgs = ['distributor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
						<span class="invalid-feedback"><?php echo e($message); ?></span>
					<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				</div>
				<div class="form-group">
					<label>Subtotal</label>
					<input type="text" class="form-control" placeholder="Subtotal" name="subtotal" value="Rp <?php echo e(number_format($subtotal)); ?>" disabled>
				</div>
				<div class="form-group">
					<label>Bayar</label>
					<div class="input-group">
					<div class="input-group-prepend">
						<span class="input-group-text">Rp</span>
					</div>
					<input type="text" class="form-control <?php $__errorArgs = ['bayar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Bayar" wire:model="bayar" name="bayar">

					<?php $__errorArgs = ['bayar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
						<span class="invalid-feedback"><?php echo e($message); ?></span>
					<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
					</div>
				</div>
				<div class="form-group">
					<label>Kembali</label>
					<input type="text" class="form-control" placeholder="Kembali" name="kembali" value="<?php echo e(number_format($kembali)); ?>" disabled>
				</div>

			</div>
			<div class="modal-footer">			
				<button type="button" data-dismiss="modal" class="btn btn-secondary">Batal</button>
				<button type="submit" class="btn btn-primary">Bayar</button>
			</div>
		</form>
	</div>
	</div>
	</div>
	
	
</div>

<?php $__env->startPush('css'); ?>
	
	<link rel="stylesheet" href="<?php echo e(asset('sufee-admin/vendors/select2/css/select2.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('sufee-admin/vendors/select2-bootstrap4-theme/select2-bootstrap4.min.css')); ?>">

<?php $__env->stopPush(); ?>

<?php $__env->startPush('js'); ?>
	
	<script src="<?php echo e(asset('sufee-admin/vendors/select2/js/select2.min.js')); ?>"></script>

	<script>
		const distUrl = '<?php echo e(route('distributor.select')); ?>'
		const distributor = $('[name=distributor]')

		// const setDistributor = data => {
		// 	for (let [name, value] of Object.entries(data)) {
		// 		$(`[name=${name}]`).val(value)
		// 	}
		// }

		window.addEventListener('open-payment', function (e) {
			$('#payment').modal('show')

			$('#payment').find('form')[0].reset()

			if (!e.detail.edit) {
				distributor.empty('')
			}
		})

		window.addEventListener('close-payment', function (e) {

			$('#payment').modal('hide')
		})

		document.addEventListener('livewire:load', function () {
			const distributorId = window.livewire.find('<?php echo e($_instance->id); ?>').distributor
			const distributorName = window.livewire.find('<?php echo e($_instance->id); ?>').distributorName

			if (distributorId) {
				$('[name=distributor]').append(`<option value="${distributorId}">${distributorName}</option>`)
			}
		})

		document.querySelector('[name=bayar]').onkeyup = function () {
			const number = this.value.replace(/\D/gi, '')
			const price = new Intl.NumberFormat().format(+number)

			this.value = price
		}

		distributor.select2({
			placeholder: 'Distributor',
			theme: 'bootstrap4',
			ajax: {
				url: distUrl,
				type: 'post',
				data: params => ({
					name: params.term,
					_token: csrf
				}),
				processResults: res => ({
					results: res
				}),
				cache: true
			}
		})

		distributor.on('select2:select', function (e) {
			const data = e.params.data
			
			window.livewire.find('<?php echo e($_instance->id); ?>').set('distributor', data.id)
		})
	</script>
<?php $__env->stopPush(); ?><?php /**PATH /usr/local/var/www/pointofsale/resources/views/livewire/stock/payment.blade.php ENDPATH**/ ?>