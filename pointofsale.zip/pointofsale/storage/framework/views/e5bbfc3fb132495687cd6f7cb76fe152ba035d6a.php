<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('nav'); ?>
    <div class="col-sm-8">
        <div class="page-header d-flex align-items-center justify-content-end">
            <ul class="nav nav-tabs">
                <li class="nav-item">
                    <a data-toggle="tab" href="#today" class="btn btn-sm btn-primary active" value="today">Hari Ini</a>
                </li>
                <li class="nav-item">
                    <a data-toggle="tab" href="#week" class="btn btn-sm btn-primary" value="week">7 Hari Terakhir</a>
                </li>
                <li class="nav-item">
                    <a data-toggle="tab" href="#month" class="btn btn-sm btn-primary" value="month">Bulan Ini</a>
                </li>
                <li class="nav-item">
                    <a data-toggle="tab" href="#year" class="btn btn-sm btn-primary" value="year">Tahun Ini</a>
                </li>
            </ul>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    
    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible">
            <?php echo e(session('success')); ?>

            <button class="close" data-dismiss="alert">&times;</button>
        </div>
    <?php endif; ?>

    <div class="tab-content">
     <div class="tab-pane fade show active" id="today">
          <?php if (isset($component)) { $__componentOriginal6efcdfcb9d8e650427b98631c351c857ba0b3fee = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\BoxData::class, ['type' => 'today']); ?>
<?php $component->withName('box-data'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal6efcdfcb9d8e650427b98631c351c857ba0b3fee)): ?>
<?php $component = $__componentOriginal6efcdfcb9d8e650427b98631c351c857ba0b3fee; ?>
<?php unset($__componentOriginal6efcdfcb9d8e650427b98631c351c857ba0b3fee); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
     </div>   
     <div class="tab-pane fade" id="week">
          <?php if (isset($component)) { $__componentOriginal6efcdfcb9d8e650427b98631c351c857ba0b3fee = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\BoxData::class, ['type' => 'week']); ?>
<?php $component->withName('box-data'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal6efcdfcb9d8e650427b98631c351c857ba0b3fee)): ?>
<?php $component = $__componentOriginal6efcdfcb9d8e650427b98631c351c857ba0b3fee; ?>
<?php unset($__componentOriginal6efcdfcb9d8e650427b98631c351c857ba0b3fee); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
     </div>
     <div class="tab-pane fade" id="month">
          <?php if (isset($component)) { $__componentOriginal6efcdfcb9d8e650427b98631c351c857ba0b3fee = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\BoxData::class, ['type' => 'month']); ?>
<?php $component->withName('box-data'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal6efcdfcb9d8e650427b98631c351c857ba0b3fee)): ?>
<?php $component = $__componentOriginal6efcdfcb9d8e650427b98631c351c857ba0b3fee; ?>
<?php unset($__componentOriginal6efcdfcb9d8e650427b98631c351c857ba0b3fee); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
     </div>
     <div class="tab-pane fade" id="year">
          <?php if (isset($component)) { $__componentOriginal6efcdfcb9d8e650427b98631c351c857ba0b3fee = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\BoxData::class, ['type' => 'year']); ?>
<?php $component->withName('box-data'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
<?php if (isset($__componentOriginal6efcdfcb9d8e650427b98631c351c857ba0b3fee)): ?>
<?php $component = $__componentOriginal6efcdfcb9d8e650427b98631c351c857ba0b3fee; ?>
<?php unset($__componentOriginal6efcdfcb9d8e650427b98631c351c857ba0b3fee); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?> 
     </div>   
    </div>

    <div class="col-lg-12">
        <div class="card">
            <div class="card-header">
                <h3 class="h6 font-weight-bold mb-0 card-title">Aktivitas Terbaru</h3>
            </div>
            <div class="card-body">
                <ul class="nav nav-tabs">
                    <li class="nav-item">
                        
                        <a class="nav-link active" data-toggle="tab" href="#penjualan" value="penjualan">Penjualan</a>
                    </li>
                    <li class="nav-item">
                        
                        <a class="nav-link actvity" data-toggle="tab" href="#pembelian" value="pembelian">Pembelian</a>
                    </li>
                    <li class="nav-item">
                        
                        <a class="nav-link actvity" data-toggle="tab" href="#pengeluaran" value="pengeluaran">Pengeluaran</a>
                    </li>
                    <li class="nav-item">
                        
                        <a class="nav-link actvity" data-toggle="tab" href="#cancel" value="cancel">Batal Transaksi</a>
                    </li>
                </ul>
                <div class="tab-content">
                    <div class="tab-pane fade table-responsive show active" id="penjualan">
                        <table class="table table-striped w-100" width="100%">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>No Faktur</th>
                                    <th>Tanggal</th>
                                    <th>Total</th>
                                    <th>Kasir</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $transactionActivity; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($activity->idPenjualan); ?></td>
                                        <td><?php echo e(date('d M Y H:i A', strtotime($activity->tanggal))); ?></td>
                                        <td>Rp <?php echo e(number_format($activity->total)); ?></td>
                                        <td><?php echo e($activity->user->nama); ?></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <td colspan="6" align="center">Kosong</td>
                                        </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="tab-pane fade table-responsive" id="pembelian">
                        <table class="table table-striped w-100" width="100%">
                            <thead>
                                <tr>
                                    <th>Id Pembelian</th>
                                    <th>Tanggal</th>
                                    <th>Nama Dist</th>
                                    <th>Total</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $buyActivity; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($activity->idPembelian); ?></td>
                                        <td><?php echo e(date('d M Y H:i A', strtotime($activity->tanggal))); ?></td>
                                        <td><?php echo e($activity->namaDist); ?></td>
                                        <td>Rp <?php echo e(number_format($activity->total)); ?></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <td colspan="4" align="center">Kosong</td>
                                        </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="tab-pane fade table-responsive" id="pengeluaran">
                        <table class="table table-striped w-100" width="100%">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>Tanggal</th>
                                    <th>Pengeluaran</th>
                                    <th>Kategori</th>
                                    <th>Keterangan</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $expendActivity; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e(date('d M Y H:i A', strtotime($activity->tanggal))); ?></td>
                                        <td>Rp <?php echo e(number_format($activity->pengeluaran)); ?></td>
                                        <td><?php echo e($activity->namaKategori); ?></td>
                                        <td><?php echo e($activity->keterangan ?? '-'); ?></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <td colspan="4" align="center">Kosong</td>
                                        </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="tab-pane fade table-responsive" id="cancel">
                        <table class="table table-striped w-100" width="100%">
                            <thead>
                                <tr>
                                    <th>No</th>
                                    <th>No Faktur</th>
                                    <th>Tanggal</th>
                                    <th>Total</th>
                                    <th>Kasir</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $cancelActivity; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($activity->idPenjualan); ?></td>
                                        <td><?php echo e(date('d M Y H:i A', strtotime($activity->tanggal))); ?></td>
                                        <td>Rp <?php echo e(number_format($activity->total)); ?></td>
                                        <td><?php echo e($activity->user->nama); ?></td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <tr>
                                            <td colspan="6" align="center">Kosong</td>
                                        </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('_layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tokobuku\resources\views/home.blade.php ENDPATH**/ ?>