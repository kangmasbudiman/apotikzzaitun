<div class="col-sm-4">
	<div class="card">
	<form wire:submit.prevent="store">
		<div class="card-header">
			<h2 class="card-title h6 mb-0 font-weight-bold">Input Transaksi</h2>
		</div>
		<div class="card-body">
			<div class="form-group">
				<label>Subtotal</label>
				<div class="input-group">
					<input type="text" class="form-control" value="Rp <?php echo e(number_format($total)); ?>" disabled>
				</div>
			</div>
			<div class="form-group">
				<label>Bayar</label>
				<div class="input-group">
					<div class="input-group-prepend">
						<span class="input-group-text">Rp</span>
					</div>
					<input type="text" name="money" class="form-control <?php $__errorArgs = ['money'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" wire:model="money" placeholder="Bayar">
					
					<?php $__errorArgs = ['money'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
						<span class="invalid-feedback"><?php echo e($message); ?></span>
					<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
				</div>
			</div>
			<div class="form-group">
				<label>Kembali</label>
				<div class="input-group">
					<input type="text" class="form-control" value="Rp <?php echo e(number_format($return)); ?>" disabled>
				</div>
			</div>
		</div>
		<div class="card-footer">
			<button class="btn btn-primary" type="submit" <?php echo e($total < 1 ? 'disabled' : ''); ?>>Bayar</button>
		</div>
	</form>
	</div>
</div><?php /**PATH C:\xampp\htdocs\tokobukuv2\resources\views/livewire/transaction/payment.blade.php ENDPATH**/ ?>