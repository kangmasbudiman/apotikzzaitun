<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Print</title>
    <style>
        @font-face {
        font-family: 'Roboto';
        src: url(<?php echo e(storage_path('fonts/Roboto/Roboto-Bold.ttf')); ?>) format("truetype");
        font-weight: 700; // use the matching font-weight here ( 100, 200, 300, 400, etc).
        font-style: bold; // use the matching font-style here
        }

        body {
            color: #333;
        }
        .heading {
            text-align: center;
            margin-bottom: 20px;
            position: relative;
        }
        .title {
            font-size: 28px;
            color: #111;
        }
        hr {
            border: 0;
            border-top: 2px solid #000;
        }
        p {
            margin: 0;
        }
        img {
            margin: 0;
            width: 140px;
            height: 140px;
            position: absolute;
            top: -0px;
            left: -0px;
        }
    </style>
</head>
<body>

<div class="heading">
    <?php if(site('pakaiLogo')): ?>
        <img src="<?php echo e(public_path('storage/logo/'.site('logo'))); ?>" alt="">
    <?php endif; ?>
    <p class="title"><?php echo e(site('nama_toko')); ?></p>
    <p><?php echo e(site('alamat_toko')); ?></p>
    <p><?php echo e(site('telepon_toko')); ?></p>
</div>
<hr>

    <div class="heading" style="margin-bottom: 20px">
        <p class="sub">Laporan Laba</p>
    </div>

    <p>Periode : <?php echo e(request()->dari ? date('d M Y', strtotime(request()->dari)) : date('d M Y')); ?> sd <?php echo e(request()->sampai ? date('d M Y', strtotime(request()->sampai)) : date('d M Y')); ?></p>

    <br>

    <table width="100%">
        <tbody>
            <tr>
                <td colspan="3">
                    Pendapatan
                </td>
                <td>:</td>
                <td colspan="2"></td>
                <td width="5%">Rp.</td>
                <td width="15%" align="right">
                    <?php echo e(number_format($reports->pemasukan ?? 0)); ?>

                </td>
            </tr>
            <tr>
                <td colspan="3">
                    Harga Pokok Penjualan
                </td>
                <td>:</td>
                <td colspan="2"></td>
                <td>Rp.</td>
                <td align="right" width="15%">
                    <?php echo e(number_format($reports->hargaPokok ?? 0)); ?>

                </td>
            </tr>
            <tr>
                <td colspan="6"></td>
                <td colspan="2" style="position: relative;">
                    <hr>
                    <span style="position: absolute; top: -8px; right: 0; background: white; width: 30px; text-align: right; display: block;">-</span>
                </td>
            </tr>
            <tr>
                <td colspan="3">
                    Laba Kotor
                </td>
                <td>:</td>
                <td colspan="2"></td>
                <td>Rp.</td>
                <td align="right">
                    <?php echo e(number_format($reports->labaKotorOne ?? 0)); ?>

                </td>
            </tr>
            <tr>
                <td width="5%"></td>
                <td colspan="2">
                    Pengeluaran
                </td>
                <td>:</td>
            </tr>
            <?php $__currentLoopData = $expend; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pengeluaran): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td></td>
                    <td width="10%"></td>
                    <td>
                        <?php echo e($pengeluaran->nama ?? '-'); ?>

                    </td>
                    <td>:</td>
                    <td width="2%">Rp.</td>
                    <td align="right" width="15%">
                        <?php echo e(number_format($pengeluaran->pengeluaran ?? 0)); ?>

                    </td>
                    <td></td>
                    <td width="10%"></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td colspan="4"></td>
                <td colspan="2" style="position: relative;">
                    <hr>
                    <span style="position: absolute; top: -8px; right: 0; background: white; width: 30px; text-align: right; display: block;">+</span>
                </td>
            </tr>
            <tr>
                <td colspan="1"></td>
                <td colspan="2">Total Pengeluaran</td>
                <td>:</td>
                <td colspan="2"></td>
                <td>Rp.</td>
                <td align="right"><?php echo e(number_format($reports->pengeluaranOne)); ?></td>
            </tr>
            <tr>
                <td colspan="6"></td>
                <td colspan="2" style="position: relative;">
                    <hr>
                    <span style="position: absolute; top: -8px; right: 0; background: white; width: 30px; text-align: right; display: block;">-</span>
                </td>
            </tr>
            <tr>
                <td colspan="1"></td>
                <td colspan="2">
                    Laba (Rugi)
                </td>
                <td>:</td>
                <td colspan="2"></td>
                <td>Rp.</td>
                <td align="right">
                    <?php echo e(number_format($reports->labaOne ?? 0)); ?>

                </td>
            </tr>
        </tbody>
    </table>

</body>
</html><?php /**PATH /home/ibrahimalanshor/Documents/freelance/Penyesuaian/Source Code/tokobukuv4/resources/views/report/print-accumulation.blade.php ENDPATH**/ ?>