<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Print</title>
    <style>
        @font-face {
        font-family: 'Roboto';
        src: url(<?php echo e(storage_path('fonts/Roboto/Roboto-Bold.ttf')); ?>) format("truetype");
        font-weight: 700; // use the matching font-weight here ( 100, 200, 300, 400, etc).
        font-style: bold; // use the matching font-style here
        }

        body {
            color: #333;
        }
        .heading {
            text-align: center;
            margin-bottom: 20px;
        }
        .title {
            font-size: 36px;
            color: #111;
        }
        .sub {
            font-size: 32px;
            color: #111;
        }
        hr {
            border: 0;
            border-top: 2px solid #000;
        }
        p {
            margin: 0;
        }
    </style>
</head>
<body>
    
    <div class="heading">
        <p class="title"><?php echo e(site('nama_toko')); ?></p>
        <p><?php echo e(site('alamat_toko')); ?></p>
        <p><?php echo e(site('telepon_toko')); ?></p>
    </div>
    <hr>

    <div class="heading" style="margin-bottom: 20px">
        <p class="sub">Laporan Stok</p>
        <p style="color: blue">
            Periode <?php echo e(request()->dari ? date('d M Y', strtotime(request()->dari)) : date('d M Y')); ?> sampai <?php echo e(request()->sampai ? date('d M Y', strtotime(request()->sampai)) : date('d M Y')); ?>

        </p>
    </div>

    <table width="100%" style="border-collapse: collapse;">
        <thead style="background-color: #111; color: #fff">
            <tr>
                <td style="font-weight: bold; border: 1px solid #111; padding: 10px 20px">No</td>
                <td style="font-weight: bold; border: 1px solid #111; padding: 10px 20px">Nama Buku</td>
                <td style="font-weight: bold; border: 1px solid #111; padding: 10px 20px">Qty</td>
            </tr>
        </thead>
        <tbody>
            <?php
                $total = 0;
                $qty = 0;
            ?>
                <?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <?php
                        $total += $report->total;
                    ?>
                    <td style="border: 1px solid #111; padding: 10px 20px">
                        <?php echo e($loop->iteration); ?>

                    </td>
                    <td style="border: 1px solid #111; padding: 10px 20px">
                        <?php echo e($report->judul); ?>

                    </td>
                    <td style="border: 1px solid #111; padding: 10px 20px">
                        <?php echo e($report->total); ?>

                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td style="border: 1px solid #111; padding: 10px 20px" align="right" colspan="2">Total Semua Stok</td>
                    <td style="border: 1px solid #111; padding: 10px 20px"><?php echo e($total); ?></td>
                </tr>
        </tbody>
    </table>

</body>
</phtml><?php /**PATH C:\xampp\htdocs\tokobukuv4\resources\views/report/print-stock.blade.php ENDPATH**/ ?>