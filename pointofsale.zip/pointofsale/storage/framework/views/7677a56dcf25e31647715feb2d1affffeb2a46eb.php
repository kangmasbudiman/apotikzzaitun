<div class="card">
	<div class="card-header d-flex justify-content-between align-items-center py-2">
		<h2 class="card-title h6 mb-0 font-weight-bold">Data Transaksi</h2>
		<div>
			<a href="<?php echo e(route('transaction.index')); ?>" class="btn btn-sm btn-secondary">Kembali</a>
			<button class="btn btn-danger btn-sm" <?php echo e(count($transactions) ? '' : 'disabled'); ?> wire:click="clear">Reset</button>
			<button class="btn btn-sm btn-primary" <?php echo e(count($transactions) ? '' : 'disabled'); ?> id="payment-btn" wire:click="$emit('open-payment')">Bayar</button>
		</div>
	</div>
	<div class="card-body">
		<?php if(session()->has('stock-error')): ?>
			<div class="alert alert-danger alert-dismissible">
				<?php echo e(session('stock-error')); ?>

				<button class="close" data-dismiss="alert">&times;</button>
			</div>
		<?php endif; ?>

		<div class="table-responsive">
			<table class="table table-bordered" width="100%">
				<thead>
					<tr>
						<th>No</th>
						<th>Barcode</th>
						<th>Nama Obat</th>
						<th width="105px">Harga</th>
						<th width="150px">Qty</th>
						<th width="120px"> Discount</th>
						<th width="120px">Total</th>
						<th>Action</th>
					</tr>
				</thead>
				<tbody class="transaction-table">
				<?php $__empty_1 = true; $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
					<?php
						$disc = $transaction['total'] * ($transaction['hargaJual'] * $transaction['disc'] / 100);
						$total = $transaction['total'] * $transaction['hargaJual'] - round($disc);
					?>
					<tr>
						<td><?php echo e($loop->iteration); ?></td>
						<td><?php echo e($transaction['stuff']['barcode']); ?></td>
						<td><?php echo e($transaction['obat']); ?></td>
						<td>Rp <?php echo e(number_format($transaction['hargaJual'])); ?></td>
						<td>
							<div class="input-group">
								<div class="input-group-prepend">
									<button class="btn btn-outline-secondary" wire:click="decrement('<?php echo e($transaction['id']); ?>')">-</button>
								</div>
								<input type="text" class="form-control qty" data-action="update" data-id="<?php echo e($transaction['id']); ?>" data-total="<?php echo e($transaction['total']); ?>" data-stock="<?php echo e($transaction['stuff']['stock']); ?>" value="<?php echo e($transaction['total']); ?>">
								<div class="input-group-append">
									<button class="btn btn-outline-secondary" wire:click="increment('<?php echo e($transaction['id']); ?>')">+</button>
								</div>

								<span class="invalid-feedback"></span>
							</div>
						</td>
						<td align="right">Rp <?php echo e(number_format($disc)); ?></td>
						<td align="right">Rp <?php echo e(number_format($total)); ?></td>
						<td><button class="btn btn-sm btn-danger" wire:click="delete('<?php echo e($transaction['id']); ?>')"><i class="fa fa-trash"></i></button></td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
					<tr>
						<td colspan="8" align="center">Kosong</td>
					</tr>
				<?php endif; ?>
				</tbody>
				<?php if($transactions): ?>
					<tfoot>
						<tr class="bg-success text-white">
							<td style="border: none;" align="center" colspan="6"><strong>Subtotal</strong></td>
							<td style="border: none;" align="right">Rp <?php echo e(number_format($subtotal)); ?></td>
							<td style="border: none;"></td>
						</tr>
					</tfoot>
				<?php endif; ?>
			</table>
		</div>
	</div>
</div>

<?php $__env->startPush('js'); ?>
<script>
	$(function () {
		$('.transaction-table').on('keyup', '.qty', function () {
			const number = this.value.replace(/\D/gi, '')
			const { stock, id } = $(this).data()

			if (number) {
				if (number > stock) {
					$(this).addClass('is-invalid')
					$(this).siblings('.invalid-feedback').html('Stok melampau batas')
				} else if (number <= 0) {
					$(this).addClass('is-invalid')
					$(this).siblings('.invalid-feedback').html('Stok terlalu sedikit')
				} else {
					Livewire.emit('update-stock', id, number)

					this.value = number
				}
			}

		})

		$('.transaction-table').on('focusout', '.qty', function () {
			if ($(this).hasClass('is-invalid')) {
				this.value = $(this).data('total')
			}

			if (!this.value) {
				this.value = $(this).data('total')
			}

			$(this).removeClass('is-invalid')
		})
	})
</script>
<?php $__env->stopPush(); ?><?php /**PATH /usr/local/var/www/pointofsale/resources/views/livewire/transaction/data.blade.php ENDPATH**/ ?>