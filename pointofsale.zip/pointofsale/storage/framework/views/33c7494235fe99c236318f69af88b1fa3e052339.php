<?php $__env->startSection('title', 'Tambah Data Transaksi'); ?>

<?php $__env->startSection('content'); ?>
    
        
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('transaction.create', [])->html();
} elseif ($_instance->childHasBeenRendered('iDfGBJ2')) {
    $componentId = $_instance->getRenderedChildComponentId('iDfGBJ2');
    $componentTag = $_instance->getRenderedChildComponentTagName('iDfGBJ2');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('iDfGBJ2');
} else {
    $response = \Livewire\Livewire::mount('transaction.create', []);
    $html = $response->html();
    $_instance->logRenderedChild('iDfGBJ2', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('transaction.data', [])->html();
} elseif ($_instance->childHasBeenRendered('k7dRXkZ')) {
    $componentId = $_instance->getRenderedChildComponentId('k7dRXkZ');
    $componentTag = $_instance->getRenderedChildComponentTagName('k7dRXkZ');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('k7dRXkZ');
} else {
    $response = \Livewire\Livewire::mount('transaction.data', []);
    $html = $response->html();
    $_instance->logRenderedChild('k7dRXkZ', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('transaction.payment', [])->html();
} elseif ($_instance->childHasBeenRendered('jr0dey7')) {
    $componentId = $_instance->getRenderedChildComponentId('jr0dey7');
    $componentTag = $_instance->getRenderedChildComponentTagName('jr0dey7');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('jr0dey7');
} else {
    $response = \Livewire\Livewire::mount('transaction.payment', []);
    $html = $response->html();
    $_instance->logRenderedChild('jr0dey7', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('transaction.cetak', [])->html();
} elseif ($_instance->childHasBeenRendered('utDXtYZ')) {
    $componentId = $_instance->getRenderedChildComponentId('utDXtYZ');
    $componentTag = $_instance->getRenderedChildComponentTagName('utDXtYZ');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('utDXtYZ');
} else {
    $response = \Livewire\Livewire::mount('transaction.cetak', []);
    $html = $response->html();
    $_instance->logRenderedChild('utDXtYZ', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    
    <?php $__env->startPush('js'); ?>
        <script>
            jQuery(function ($) {
                $('[name=money]').on('keyup', function() {
                    const number = Number(this.value.replace(/\D/g, ''))
                    const price = new Intl.NumberFormat().format(number)
                    
                    this.value = price
                })
            })
        </script>
    <?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('_layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tokobuku\resources\views/transaction/create.blade.php ENDPATH**/ ?>