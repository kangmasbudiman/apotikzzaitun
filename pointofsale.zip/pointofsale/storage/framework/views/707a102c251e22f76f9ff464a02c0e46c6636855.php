<?php echo \Livewire\Livewire::scripts(); ?>


<script src="<?php echo e(asset('sufee-admin/vendors/jquery/dist/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('sufee-admin/vendors/popper.js/dist/umd/popper.min.js')); ?>"></script>
<script src="<?php echo e(asset('sufee-admin/vendors/bootstrap/dist/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('sufee-admin/assets/js/main.js')); ?>"></script>
<script src="<?php echo e(asset('js/app.js')); ?>"></script>

<?php echo $__env->yieldPushContent('js'); ?><?php /**PATH /home/ibrahimalanshor/Documents/freelance/Penyesuaian/Source Code/tokobukuv4/resources/views/_includes/foot.blade.php ENDPATH**/ ?>