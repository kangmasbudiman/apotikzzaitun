<?php $__env->startSection('title', 'Stok Baru'); ?>

<?php $__env->startSection('content'); ?>
	
	<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('stock.form', [])->html();
} elseif ($_instance->childHasBeenRendered('GFag2tP')) {
    $componentId = $_instance->getRenderedChildComponentId('GFag2tP');
    $componentTag = $_instance->getRenderedChildComponentTagName('GFag2tP');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('GFag2tP');
} else {
    $response = \Livewire\Livewire::mount('stock.form', []);
    $html = $response->html();
    $_instance->logRenderedChild('GFag2tP', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
	
	<div class="row">
		<div class="col-sm-8">
			<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('stock.data', [])->html();
} elseif ($_instance->childHasBeenRendered('6iRIQJ2')) {
    $componentId = $_instance->getRenderedChildComponentId('6iRIQJ2');
    $componentTag = $_instance->getRenderedChildComponentTagName('6iRIQJ2');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('6iRIQJ2');
} else {
    $response = \Livewire\Livewire::mount('stock.data', []);
    $html = $response->html();
    $_instance->logRenderedChild('6iRIQJ2', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
		</div>
		<div class="col-sm-4">
			<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('stock.payment', [])->html();
} elseif ($_instance->childHasBeenRendered('R27SH4f')) {
    $componentId = $_instance->getRenderedChildComponentId('R27SH4f');
    $componentTag = $_instance->getRenderedChildComponentTagName('R27SH4f');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('R27SH4f');
} else {
    $response = \Livewire\Livewire::mount('stock.payment', []);
    $html = $response->html();
    $_instance->logRenderedChild('R27SH4f', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
		</div>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('_layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\kasitokobuku\resources\views/stock/create.blade.php ENDPATH**/ ?>