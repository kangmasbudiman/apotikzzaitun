<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Print</title>
    <style>
        @font-face {
        font-family: 'Roboto';
        src: url(<?php echo e(storage_path('fonts/Roboto/Roboto-Bold.ttf')); ?>) format("truetype");
        font-weight: 700; // use the matching font-weight here ( 100, 200, 300, 400, etc).
        font-style: bold; // use the matching font-style here
        }

        body {
            color: #333;
            font-size: 18px;
        }
        .heading {
            text-align: center;
            margin-bottom: 20px;
            position: relative;
        }
        .title {
            font-size: 24px;
            color: #111;
        }
        hr {
            border: 0;
            border-top: 2px solid #000;
        }
        p {
            margin: 0;
        }
        img {
            margin: 0;
            width: 120px;
            height: 120px;
            position: absolute;
            top: -0px;
            left: -0px;
        }
        tr:nth-child(even) {
            background-color: #ddd;
        }
        tr:last-child {
            background-color: #111;
            color: #fff;
        }
    </style>
</head>
<body>

<div class="heading">
    <img src="<?php echo e(public_path('storage/logo/'.site('logo'))); ?>" alt="">
    <p class="title"><?php echo e(site('nama_toko')); ?></p>
    <p><?php echo e(site('alamat_toko')); ?></p>
    <p><?php echo e(site('telepon_toko')); ?></p>
</div>
<hr>

    <div class="heading" style="margin-bottom: 20px">
        <p class="sub">Laporan Stok Harian</p>
    </div>

    <table width="100%" style="border-collapse: collapse;">
        <thead style="background-color: #111; color: #fff">
            <tr>
                <td style="font-weight: bold; border: 1px solid #111; padding: 5px 10px">No</td>
                <td style="font-weight: bold; border: 1px solid #111; padding: 5px 10px">Nama Buku</td>
                <td style="font-weight: bold; border: 1px solid #111; padding: 5px 10px">Qty</td>
            </tr>
        </thead>
        <tbody>
            <?php
                $total = 0;
                $qty = 0;
            ?>
                <?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <?php
                        $total += $report->total;
                    ?>
                    <td style="border: 1px solid #111; padding: 5px 10px">
                        <?php echo e($loop->iteration); ?>

                    </td>
                    <td style="border: 1px solid #111; padding: 5px 10px">
                        <?php echo e($report->judul); ?>

                    </td>
                    <td style="border: 1px solid #111; padding: 5px 10px">
                        <?php echo e($report->total); ?>

                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td style="border: 1px solid #111; padding: 5px 10px" align="right" colspan="2">Total Semua Stok</td>
                    <td style="border: 1px solid #111; padding: 5px 10px"><?php echo e($total); ?></td>
                </tr>
        </tbody>
    </table>

</body>
</phtml><?php /**PATH /home/ibrahimalanshor/Documents/freelance/Penyesuaian/Source Code/tokobukuv4/resources/views/report/print-stock-today.blade.php ENDPATH**/ ?>