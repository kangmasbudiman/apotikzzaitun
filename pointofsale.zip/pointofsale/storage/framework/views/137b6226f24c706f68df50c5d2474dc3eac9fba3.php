<?php $__env->startSection('title', 'Notifikasi'); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <h2 class="h6 font-weight-bold mb-0 card-title">Notifikasi</h2>
        </div>
        <div class="card-body">
            <table class="table table-bordered table-striped" width="100%">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>ID Buku</th>
                        <th>Barcode</th>
                        <th>Penerbit</th>
                        <th>Nama Buku</th>
                        <th>Stok</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $stuffs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stuff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($loop->iteration); ?></td>
                            <td><?php echo e($stuff->idBuku); ?></td>
                            <td><?php echo e($stuff->barcode); ?></td>
                            <td><?php echo e($stuff->penerbit); ?></td>
                            <td><?php echo e($stuff->judul); ?></td>
                            <td><?php echo e($stuff->stock); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="6" align="center">Kosong</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
    
            <?php echo e($stuffs->links()); ?>

        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('_layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ibrahimalanshor/Documents/freelance/Penyesuaian/tokobuku/resources/views/notification.blade.php ENDPATH**/ ?>