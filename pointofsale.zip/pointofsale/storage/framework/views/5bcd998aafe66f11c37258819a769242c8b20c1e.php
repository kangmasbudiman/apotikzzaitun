<style>
    table{
        padding: 0;
        border-collapse: collapse;
    }
    td {
        padding: 0;
    }
    .break {
        page-break-after: always;
    }
</style>

<?php $__currentLoopData = $barcodes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div style="width: 25%; float: left;">
        <div style="border: 1px solid #555; padding: 30px 0;">
            <div style="width: 190px; margin: auto; text-align: center;">
                <img src="data:image/png;base64,<?php echo e(DNS1D::getBarcodePNG($row->barcode, 'EAN13', 2, 65)); ?>" alt="">
                <br>
                <table width="100%">
                    <tr>
                        <?php $__currentLoopData = str_split($row->barcode); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barcode): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <td style="font-size: 16px;" align="center">
                                <?php echo e($barcode); ?>

                            </td>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                </table>
                <div style="background-color: #111; color: #fff; margin-top: 5px;">
                    <span style="font-size: 16px">Rp <?php echo e(number_format($row->hargaJual)); ?></span>
                </div>
            </div>
        </div>
    </div>
    <?php if($loop->iteration > 1 && $loop->iteration % 4 === 0): ?>
        <div style="clear: both;"></div>
    <?php endif; ?>
    <?php if($loop->iteration > 1 && $loop->iteration % 32 === 0): ?>
        <div class="break"></div>
    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH /usr/local/var/www/pointofsale/resources/views/stuff/allbarcode.blade.php ENDPATH**/ ?>