<div class="col-sm-6 col-lg-3">
    <div class="card text-white bg-flat-color-1">
        <div class="card-body pb-0">
            <div class="float-right">
                <i class="fa fa-archive"></i>
            </div>
            <h4 class="mb-0">
                <span class="count"><?php echo e($totalStuff); ?></span>
            </h4>
            <p class="text-light">Total Barang</p>

        </div>

    </div>
</div>

<div class="col-sm-6 col-lg-3">
    <div class="card text-white bg-flat-color-5">
        <div class="card-body pb-0">
            <div class="float-right">
                <i class="fa fa-truck"></i>
            </div>
            <h4 class="mb-0">
                <span class="count"><?php echo e($totalStock); ?></span>
            </h4>
            <p class="text-light">Total Pembelian Stock</p>

        </div>

    </div>
</div>

<div class="col-sm-6 col-lg-3">
    <div class="card text-white bg-flat-color-4">
        <div class="card-body pb-0">
            <div class="float-right">
                <i class="fa fa-archive"></i>
            </div>
            <h4 class="mb-0">
                <span class="count"><?php echo e($selledBook); ?></span>
            </h4>
            <p class="text-light">Buku Terjual</p>

        </div>

    </div>
</div>

<div class="col-sm-6 col-lg-3">
    <div class="card text-white bg-flat-color-3">
        <div class="card-body pb-0">
            <div class="float-right">
                <i class="fa fa-dollar"></i>
            </div>
            <h4 class="mb-0">
                <span class="count"><?php echo e($buyedBook); ?></span>
            </h4>
            <p class="text-light">Buku Bertambah</p>

        </div>

    </div>
</div>

<div class="col-sm-6 col-lg-3">
    <div class="card text-white bg-flat-color-1">
        <div class="card-body pb-0">
            <div class="float-right">
                <i class="fa fa-money"></i>
            </div>
            <h4 class="mb-0">
                <span class="count"><?php echo e($totalTransaction); ?></span>
            </h4>
            <p class="text-light">Total Transaksi</p>

        </div>

    </div>
</div>

<div class="col-sm-6 col-lg-3">
    <div class="card text-white bg-flat-color-5">
        <div class="card-body pb-0">
            <div class="float-right">
                <i class="fa fa-times"></i>
            </div>
            <h4 class="mb-0">
                <span class="count"><?php echo e($totalCancel); ?></span>
            </h4>
            <p class="text-light">Order Cancel</p>

        </div>

    </div>
</div>

<div class="col-sm-6 col-lg-3">
    <div class="card text-white bg-flat-color-4">
        <div class="card-body pb-0">
            <div class="float-right">
                <i class="fa fa-dollar"></i>
            </div>
            <h4 class="mb-0">
                <span class="count"><?php echo e($totalIncome); ?></span>
            </h4>
            <p class="text-light">Total Pemasukan</p>

        </div>

    </div>
</div>

<div class="col-sm-6 col-lg-3">
    <div class="card text-white bg-flat-color-3">
        <div class="card-body pb-0">
            <div class="float-right">
                <i class="fa fa-dollar"></i>
            </div>
            <h4 class="mb-0">
                <span class="count"><?php echo e($totalBuy); ?></span>
            </h4>
            <p class="text-light">Total Pembelian</p>

        </div>

    </div>
</div>

<div class="col-sm-6 col-lg-3">
    <div class="card text-white bg-flat-color-1">
        <div class="card-body pb-0">
            <div class="float-right">
                <i class="fa fa-dollar"></i>
            </div>
            <h4 class="mb-0">
                <span class="count"><?php echo e($totalExpend); ?></span>
            </h4>
            <p class="text-light">Total Pengeluaran</p>

        </div>

    </div>
</div>

<div class="col-sm-6 col-lg-3">
    <div class="card text-white bg-flat-color-5">
        <div class="card-body pb-0">
            <div class="float-right">
                <i class="fa fa-dollar"></i>
            </div>
            <h4 class="mb-0">
                <span class="count"><?php echo e($profitOne); ?></span>
            </h4>
            <p class="text-light">Laba</p>

        </div>

    </div>
</div>

<div class="col-sm-6 col-lg-3">
    <div class="card text-white bg-flat-color-4">
        <div class="card-body pb-0">
            <div class="float-right">
                <i class="fa fa-dollar"></i>
            </div>
            <h4 class="mb-0">
                <span class="count"><?php echo e($profit); ?></span>
            </h4>
            <p class="text-light">Laba</p>

        </div>

    </div>
</div>

<div class="col-sm-6 col-lg-3">
    <div class="card text-white bg-flat-color-3">
        <div class="card-body pb-0">
            <div class="float-right">
                <i class="fa fa-dollar"></i>
            </div>
            <h4 class="mb-0">
                <span class="count"><?php echo e($totalOpname); ?></span>
            </h4>
            <p class="text-light">Total Stok Opname</p>

        </div>

    </div>
</div>

<div class="col-lg-6">
   <div class="card">
       <div class="card-body">
           <?php
               $name = [
                   'today' => 'Hari ini',
                   'week' => '7 Hari Terakhir',
                   'month' => 'Bulan ini',
                   'year' => 'Tahun ini'
               ];
           ?>
           <h4 class="mb-3">Grafik Pengeluaran <?php echo e($name[$type]); ?></h4>
           <canvas id="barChartPengeluaran-<?php echo e($type); ?>"></canvas>
       </div>
   </div>
</div>

<div class="col-lg-6">
   <div class="card">
       <div class="card-body">
           <h4 class="mb-3">Grafik Penjualan <?php echo e($name[$type]); ?></h4>
           <canvas id="barChartPenjualan-<?php echo e($type); ?>"></canvas>
       </div>
   </div>
</div>

<?php $__env->startPush('js'); ?>
    <script src="<?php echo e(asset('sufee-admin/vendors/chart.js/dist/Chart.min.js')); ?>"></script>
    <script>
        const transactions<?php echo e($type); ?> = JSON.parse('<?php echo json_encode($incomeGraphic, 15, 512) ?>')
        const stocks<?php echo e($type); ?> = JSON.parse('<?php echo json_encode($stockGraphic, 15, 512) ?>')
        const type<?php echo e($type); ?> = '<?php echo e(request()->type); ?>'

        var ctx<?php echo e($type); ?> = document.getElementById("barChartPenjualan-<?php echo e($type); ?>");
        var myChart = new Chart(ctx<?php echo e($type); ?>, {
            type: 'line',
            data: {
                labels: transactions<?php echo e($type); ?>.date,
                datasets: [{
                    label: "Pemasukan",
                    data: transactions<?php echo e($type); ?>.data,
                    borderColor: "rgba(0, 123, 255, 0.9)",
                    borderWidth: "2.5",
                    backgroundColor: "transparent"
                }]
            },
            options: {
                scales: {
                    yAxes: [{
                        ticks: {
                            beginAtZero: true
                        }
                    }],
                    xAxes: [
                        {
                            scaleLabel: {
                                display: true,
                                labelString: 'Grafik Penjualan <?php echo e($name[$type]); ?>',
                                borderColor: "rgba(0, 123, 255, 0.9)",
                                borderWidth: "2.5",
                                backgroundColor: "transparent"
                            }
                        }
                    ]
                }
            }
        });

        var ctx2<?php echo e($type); ?> = document.getElementById("barChartPengeluaran-<?php echo e($type); ?>");
        var myChart2 = new Chart(ctx2<?php echo e($type); ?>, {
            type: 'line',
            data: {
                labels: stocks<?php echo e($type); ?>.date,
                datasets: [{
                    label: "Pengeluaran",
                    data: stocks<?php echo e($type); ?>.data,
                    borderColor: "rgba(255,193,7,0.9)",
                    borderWidth: "2.5",
                    backgroundColor: "transparent"
                }]
            },
            options: {
                scales: {
                    yAxes: [{
                        ticks: {
                            beginAtZero: true
                        }
                    }],
                    xAxes: [
                        {
                            scaleLabel: {
                                display: true,
                                labelString: 'Grafik Penjualan <?php echo e($name[$type]); ?>',
                                borderColor: "rgba(255,193,7,0.9)",
                                borderWidth: "2.5",
                                backgroundColor: "transparent"
                            }
                        }
                    ]
                }
            }
        });
    </script>
<?php $__env->stopPush(); ?><?php /**PATH /home/ibrahimalanshor/Documents/freelance/Penyesuaian/tokobuku/resources/views/components/box-data.blade.php ENDPATH**/ ?>