<?php $__env->startSection('title', 'Riwayat Pembelian'); ?>

<?php $__env->startSection('content'); ?>

    <div id="alert"></div>

    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible">
            <?php echo e(session('success')); ?>

            <button class="close" data-dismiss="alert">&times;</button>
        </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h2 class="h6 card-title font-weight-bold mb-0">Detail Pembelian</h2>
            <div>
                <button class="btn btn-sm btn-warning" data-toggle="collapse" data-target="#filter">Filter</button>
                <button class="btn btn-success btn-sm" data-toggle="modal" data-target="#import">Import Excel</button>
                <a class="btn btn-success btn-sm" href="<?php echo e(route('detail_stock.export')); ?>">Export Excel</a>
            </div>
        </div>
        <div class="card-body border-bottom collapse form-row pb-4" id="filter">
            <div class="col-sm-3">
                <label>Dari</label>
                <input type="date" name="dari" placeholder="Tanggal" class="form-control">
            </div>
            <div class="col-sm-3">
                <label>Sampai</label>
                <input type="date" name="sampai" placeholder="Tanggal" class="form-control">
            </div>
            <div class="col-sm-3">
                <label>Distributor</label>
                <select class="form-control" style="width: 100%;" name="distributor">
                    <option value="" selected="">Distributor</option>
                    <?php $__currentLoopData = $distributor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->namaDist); ?>"><?php echo e($item->namaDist); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-sm-3 d-flex align-items-end">
                <button class="btn btn-primary rounded filter mr-1">Filter</button>
                <button class="btn btn-success rounded print">Print</button>
            </div>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" width="100%">
                    <thead>
                        <tr>
                            <th>Id Pasok</th>
                            <th>Tanggal</th>
                            <th>Nama Dist</th>
                            <th>Judul Buku</th>
                            <th>Harga</th>
                            <th>Jumlah</th>
                            <th>Total</th>
                    </thead>
                </table>
            </div>
        </div>
    </div>

    <div class="modal" id="import">
    <div class="modal-dialog">
    <div class="modal-content">
    <form action="<?php echo e(route('detail_stock.import')); ?>" method="post" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="modal-header">
            <h5 class="modal-title">Import Excel</h5>
            <button class="close" data-dismiss="modal">&times;</button>
        </div>
        <div class="modal-body">
            <div class="form-group">
                <label>File Excel</label>
                <div class="custom-file">
                    <label class="custom-file-label">Browse</label>
                    <input type="file" class="custom-file-input" name="file">
                <span class="invalid-feedback"></span>
                </div>

            </div>
        </div>
        <div class="modal-footer">
            <button class="btn btn-primary" type="submit">Simpan</button>
            <button class="btn btn-secondary" data-dismiss="modal">Batal</button>
        </div>
    </form>
    </div>
    </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('css'); ?>
    
    <link rel="stylesheet" href="<?php echo e(asset('sufee-admin/vendors/datatables.net-bs4/css/dataTables.bootstrap4.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('sufee-admin/vendors/select2/css/select2.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('sufee-admin/vendors/select2-bootstrap4-theme/select2-bootstrap4.min.css')); ?>">

<?php $__env->stopPush(); ?>

<?php $__env->startPush('js'); ?>
    
    <script src="<?php echo e(asset('sufee-admin/vendors/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('sufee-admin/vendors/datatables.net-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('sufee-admin/vendors/bs-custom-file-input/bs-custom-file-input.min.js')); ?>"></script>
    <script src="<?php echo e(asset('sufee-admin/vendors/select2/js/select2.full.min.js')); ?>"></script>

    <script>
        const ajaxUrl = '<?php echo e(route('detail_stock.datatables')); ?>'
        const printUrl = '<?php echo e(route('detail_stock.printall')); ?>'
        const csrf = '<?php echo e(csrf_token()); ?>'
    </script>

    <script src="<?php echo e(asset('js/detail_stock.js')); ?>"></script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('_layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ibrahimalanshor/Documents/freelance/Penyesuaian/Source Code/tokobukuv4/resources/views/stock/detail_stock.blade.php ENDPATH**/ ?>