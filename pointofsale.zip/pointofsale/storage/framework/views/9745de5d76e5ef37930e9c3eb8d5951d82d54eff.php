<div class="row">
	<div class="col-sm-4">
		<div class="card">
			<div class="card-header">
				<h2 class="card-title h6 mb-0 font-weight-bold">Pembelian</h2>
			</div>
			<div class="card-body">
				<div class="form-group">
					<label>No Faktur</label>
					<input type="text" class="form-control" name="name" value="<?php echo e($latestId); ?>" disabled>
				</div>
				<div class="form-group">
					<label>Tanggal</label>
					<input type="text" class="form-control" name="name" value="<?php echo e(date('d/m/Y')); ?>" disabled>
				</div>
				<div class="form-group">
					<label>Operator</label>
					<input type="text" class="form-control" name="name" value="<?php echo e(auth()->user()->nama); ?>" disabled>
				</div>
			</div>
		</div>
	</div>

	<div class="col-sm-4">
		<form wire:submit.prevent="submit" class="buku">
			<div class="card">
				<div class="card-header">
					<h2 class="h6 card-title font-weight-bold mb-0">Input / Scan Buku</h2>
				</div>
				<div class="card-body">
					<div class="form-group">
						<label>Barcode</label>
						<div class="input-group">
							<input name="barcode" class="form-control <?php $__errorArgs = ['barcode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Barcode" wire:model="barcode"></input>
							<div class="input-group-append">
								<button type="button" class="btn btn-primary" data-toggle="modal" data-target="#stuff"><i class="fa fa-search"></i></button>
							</div>

							<?php $__errorArgs = ['barcode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
								<span class="invalid-feedback"><?php echo e($message); ?></span>
							<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
						</div>
					</div>
					<div class="form-group">
						<label>Jumlah</label>
						<div class="input-group">
							<input type="number" class="form-control <?php $__errorArgs = ['jumlah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="jumlah" placeholder="Jumlah" wire:model="jumlah">
							<div class="input-group-append" wire:ignore>
								<button class="btn btn-primary" type="submit" name="submit">Tambah</button>
							</div>

							<?php $__errorArgs = ['jumlah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
								<span class="invalid-feedback"><?php echo e($message); ?></span>
							<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
						</div>
					</div>
				</div>
			</div>
		</form>
	</div>

	<div class="col-sm-4">
		<div class="card" id="book-data">
			<div class="card-header">
				<h2 class="card-title h6 mb-0 font-weight-bold">Data Buku</h2>
			</div>
			<div class="card-body">
				<div class="form-group">
					<label>Judul Buku</label>
					<input type="text" class="form-control" name="judul" placeholder="Judul" disabled>
				</div>
				<div class="form-group">
					<label>Harga</label>
					<input type="text" class="form-control" name="price" placeholder="Harga" disabled>
				</div>
				<div class="form-group">
					<label>Stok</label>
					<input type="text" class="form-control" name="stock" placeholder="Stok Barang" disabled>
				</div>
			</div>
		</div>
	</div>
	

	<div wire:ignore>
		<?php echo $__env->make('stuff.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	</div>
</div>

<?php $__env->startPush('js'); ?>
	
	<script>

		Livewire.on('addData', function () {
			// $('.buku .form-control').val('')
			$('[name=barcode]').empty()
		})

		const $ = jQuery

		const stuffUrl = '<?php echo e(route('stuff.select')); ?>'
		
		const csrf = '<?php echo e(csrf_token()); ?>'
		const buku = $('[name=barcode]')

		const setStuff = data => {
			for (let [name, value] of Object.entries(data)) {
				if (name === 'ppn') {
					$(`[name=${name}]`).val(value + ' %')
				} else {
					$(`[name=${name}]`).val(value)
				}
			}
		}

		$('.form-stock .form-control').val('')

		// buku.on('select2:select', function (e) {
		// 	const data = e.params.data

		// 	setStuff(data)

		// 	window.livewire.find('<?php echo e($_instance->id); ?>').set('barcode', data.id)
		// })

		const table = $('#stuff table').DataTable({
		    serverSide: true,
		    processing: true,
		    ajax: {
		        url: ajaxUrl,
		        type: 'post',
		        data: {
		            _token: csrf
		        }
		    },
		    columns: [
		        { data: 'DT_RowIndex' },
		        { data: 'idBuku' },
		        { data: 'barcode' },
		        { data: 'judul' },
		        { data: 'purchase_price' },
		        { data: 'stock' },
		        {
		            data: null,
		            render: () => {
		                return `<button class="btn btn-sm btn-primary">Pilih</button>`
		            }
		        }
		    ],
		})

		$('#stuff tbody').on('click', 'button', function () {
		    const data = table.row($(this).parents('tr')).data()

		    buku.val(data.barcode)

		    setStuff(data)
		    window.livewire.find('<?php echo e($_instance->id); ?>').set('barcode', data.barcode)

		    $('#stuff').modal('hide')
		})

		window.addEventListener('reset-stuff', function () {
			table.ajax.reload()
		})

		window.addEventListener('reset-data-form', function () {
			$('#book-data').find('input').val('')
		})
	</script>

<?php $__env->stopPush(); ?><?php /**PATH /home/ibrahimalanshor/Documents/freelance/Penyesuaian/tokobuku/resources/views/livewire/stock/form.blade.php ENDPATH**/ ?>