<?php $__env->startSection('title', 'Detail Transaksi'); ?>

<?php $__env->startSection('content'); ?>
	<div class="card">
		<div class="card-body">
			<div class="row">
				<div class="col-sm-8">
					<h1 class="h3">Toko Buku Kita</h1>
					<p><?php echo e(site('alamat_toko')); ?></p>
				</div>
				<div class="col-sm-4">
					<dl class="row mx-0">
						<dt class="col-3 px-0">Tanggal</dt>
						<dd class="col-9 row px-0 mx-0 text-right">
							<?php
								date_default_timezone_set('Asia/Jakarta');
							?>
							<span class="col-2 px-0">:</span>
							<span class="col-10 px-0"><?php echo e(date('d/m/y H:i A', strtotime($transaction->tanggal))); ?></span>
						</dd>
						<dt class="col-3 px-0">No Faktur</dt>
						<dd class="col-9 row px-0 mx-0 text-right">
							<span class="col-2 px-0">:</span>
							<span class="col-10 px-0"><?php echo e($transaction->idPenjualan); ?></span>
						</dd>
						<dt class="col-3 px-0">Kasir</dt>
						<dd class="col-9 row px-0 mx-0 text-right">
							<span class="col-2 px-0">:</span>
							<span class="col-10 px-0"><?php echo e($transaction->namaUser); ?></span>
						</dd>
					</dl>
				</div>
			</div>
			<div class="table-responsive">
				<table class="table table-striped" width="100%">
					<thead>
						<tr>
							<th>No</th>
							<th>Barang</th>
							<th>Harga</th>
							<th>Jumlah</th>
							<th>Diskon</th>
							<th>Total</th>
						</tr>
					</thead>
					<tbody>
						<?php
							$subtotal = 0;
						?>
						<?php $__currentLoopData = $transaction->detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stuff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<?php
								$total = $stuff->jumlah * $stuff->hargaJual - $stuff->disc;
								$subtotal += $total;
							?>
							<tr>
								<td><?php echo e($loop->iteration); ?></td>
								<td><?php echo e($stuff->judul); ?></td>
								<td>Rp <?php echo e(number_format($stuff->hargaJual)); ?></td>
								<td><?php echo e($stuff->jumlah); ?></td>
								<td>Rp <?php echo e(number_format($stuff->disc)); ?></td>
								<td>Rp <?php echo e(number_format($total)); ?></td>
							</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
					<tfoot>
						<tr>
							<td colspan="5" align="right"><strong>Total</strong></td>
							<td>Rp <?php echo e(number_format($subtotal)); ?></td>
						</tr>
						<tr>
							<td colspan="5" align="right"><strong>PPN</strong></td>
							<td>Rp <?php echo e(number_format($transaction->ppn)); ?></td>
						</tr>
						<tr>
							<td colspan="5" align="right"><strong>Subtotal</strong></td>
							<td>Rp <?php echo e(number_format($transaction->total)); ?></td>
						</tr>
					</tfoot>
				</table>
			</div>
		</div>
		<div class="card-footer">
			<?php if($transaction->status): ?>
				<a href="<?php echo e(route('transaction.print', $transaction->idPenjualan)); ?>" class="btn btn-primary">Print</a>
			<?php endif; ?>
			<a href="<?php echo e(route('transaction.index')); ?>" class="btn btn-secondary">Kembali</a>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('_layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ibrahimalanshor/Documents/freelance/Penyesuaian/Source Code/tokobukuv4/resources/views/transaction/detail.blade.php ENDPATH**/ ?>