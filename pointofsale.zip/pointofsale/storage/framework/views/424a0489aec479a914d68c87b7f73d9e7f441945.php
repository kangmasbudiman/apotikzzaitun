<aside id="left-panel" class="left-panel">
<nav class="navbar navbar-expand-sm navbar-default">

    <div class="navbar-header">
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#main-menu" aria-controls="main-menu" aria-expanded="false" aria-label="Toggle navigation">
            <i class="fa fa-bars"></i>
        </button>
        <a class="navbar-brand" href="<?php echo e(route('home')); ?>"><?php echo e(site('nama_toko')); ?></a>
    </div>

    <div id="main-menu" class="main-menu collapse navbar-collapse">
        <ul class="nav navbar-nav">

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isAdmin')): ?>
                <li class="<?php echo e(active('/')); ?>">
                    <a href="<?php echo e(route('home')); ?>"> <i class="menu-icon fa fa-dashboard"></i>Dashboard</a>
                </li>
            <?php endif; ?>

            <li class="menu-item-has-children dropdown <?php echo e(active('stuff', 'group', 'active')); ?> <?php echo e(active('distributor', 'group', 'active')); ?> <?php echo e(active('category', 'group', 'active')); ?>">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                    <i class="menu-icon fa fa-table"></i>
                    Master Data
                </a>
                <ul class="sub-menu children dropdown-menu">
                    <li>
                        <i class="fa fa-archive"></i>
                        <a href="<?php echo e(route('stuff.index')); ?>"></i>Buku</a>
                    </li>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isAdminGudang')): ?>
                    <li>
                        <i class="menu-icon fa fa-tag"></i>
                        <a href="<?php echo e(route('category.index')); ?>">Kategori</a>
                    </li>
                    <li>
                        <i class="menu-icon fa fa-book"></i>
                        <a href="<?php echo e(route('rack.index')); ?>">Rak</a>
                    </li>
                    <li>
                        <i class="menu-icon fa fa-truck"></i>
                        <a href="<?php echo e(route('distributor.index')); ?>">Distributor</a>
                    </li>
                    <?php endif; ?>
                </ul>
            </li>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isAdminGudang')): ?>
            <li class="menu-item-has-children dropdown <?php echo e(active('stock', 'group', 'active')); ?> <?php echo e(active('detail_stock', 'group', 'active')); ?> <?php echo e(active('transaction', 'group', 'active')); ?> <?php echo e(active('detail_transaction', 'group', 'active')); ?> <?php echo e(active('finance', false, 'active')); ?>">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                    <i class="menu-icon fa fa-truck"></i>
                    Pasok
                </a>
                <ul class="sub-menu children dropdown-menu">
                
                    <li>
                        <i class="menu-icon fa fa-truck"></i>
                        <a href="<?php echo e(route('stock.index')); ?>">Pembelian</a>
                    </li>
                    
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isAdmin')): ?>
                    <li>
                        <i class="menu-icon fa fa-truck"></i>
                        <a href="<?php echo e(route('detail_stock.index')); ?>">Riwayat Pembelian</a>
                    </li>
                    <?php endif; ?>
                </ul>
            </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isAdminKasir')): ?>
            <li class="menu-item-has-children dropdown <?php echo e(active('stock', 'group', 'active')); ?> <?php echo e(active('detail_stock', 'group', 'active')); ?> <?php echo e(active('transaction', 'group', 'active')); ?> <?php echo e(active('detail_transaction', 'group', 'active')); ?> <?php echo e(active('finance', false, 'active')); ?>">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                    <i class="menu-icon fa fa-tasks"></i>
                    Transaksi
</a>
<ul class="sub-menu children dropdown-menu">
            
                    <li>
                        <i class="menu-icon fa fa-money"></i>
                        <a href="<?php echo e(route('transaction.index')); ?>">Transaksi</a>
                    </li>
                    <li>
                    
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isAdmin')): ?>
                        <i class="menu-icon fa fa-money"></i>
                        <a href="<?php echo e(route('detail_transaction.index')); ?>">Riwayat Transaksi</a>
                    </li>
                    <?php endif; ?>
  </ul>
            </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isAdminGudang')): ?>
            <li class="menu-item-has-children dropdown <?php echo e(active('report/accumulation', false, 'active')); ?>">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                    
                    <i class="menu-icon fa fa-print"></i>
                    Pengeluaran
                </a>
                <ul class="sub-menu children dropdown-menu">
                <li>
                <i class="menu-icon fa fa-print"></i>
                            <a href="<?php echo e(route('finance.index')); ?>"></i>Pengeluaran</a>
                        </li>
                        </ul>
            </li>
                    <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isAdmin')): ?>
            <li class="menu-item-has-children dropdown <?php echo e(active('report/accumulation', false, 'active')); ?>">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                    <i class="menu-icon fa fa-calculator"></i>
                    Akuntansi
                </a>
                <ul class="sub-menu children dropdown-menu">
                    <li>
                        <i class="menu-icon fa fa-calculator"></i>
                        <a href="<?php echo e(route('report.accumulation')); ?>">Akumulasi</a>
                    </li>
                </ul>
            </li>
            <?php endif; ?>

            <li class="menu-item-has-children dropdown <?php echo e(active('report/transaction', 'group', 'active')); ?> <?php echo e(active('report/expend', 'group', 'active')); ?> <?php echo e(active('report/stock', 'group', 'active')); ?> <?php echo e(active('report/sell', 'group', 'active')); ?> <?php echo e(active('report/buy', 'group', 'active')); ?>">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                    <i class="menu-icon fa fa-file"></i>
                    Laporan
                </a>
                <ul class="sub-menu children dropdown-menu">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isAdminKasir')): ?>
                    <li>
                        <i class="menu-icon fa fa-file"></i>
                        <a href="<?php echo e(route('report.transaction')); ?>">Laporan Pendapatan</a>
                    </li>
                    <li>
                        <i class="menu-icon fa fa-file"></i>
                        <a href="<?php echo e(route('report.sell')); ?>">Laporan Penjualan</a>
                    </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isAdmin')): ?>
                    <li>
                        <i class="menu-icon fa fa-file"></i>
                        <a href="<?php echo e(route('report.expend')); ?>">Laporan Pengeluaran</a>
                    </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isAdminGudang')): ?>
                    <li>
                        <i class="menu-icon fa fa-file"></i>
                        <a href="<?php echo e(route('report.buy')); ?>">Laporan Pembelian</a>
                    </li>
                    <li>
                        <i class="menu-icon fa fa-file"></i>
                        <a href="<?php echo e(route('report.stock')); ?>">Laporan Stok</a>
                    </li>
                    <?php endif; ?>
                </ul>
            </li>

            <li class="menu-item-has-children dropdown <?php echo e(active('change_password', false, 'show')); ?> <?php echo e(active('setting', false, 'show')); ?> <?php echo e(active('user', 'group', 'show')); ?>">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                    <i class="menu-icon fa fa-cog"></i>
                    Pengaturan
                </a>
                <ul class="sub-menu children dropdown-menu">
                    <li>
                        <i class="menu-icon fa fa-key"></i>
                        <a href="<?php echo e(route('change_password')); ?>">Ganti Password</a>
                    </li>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isAdmin')): ?>
                        <li>
                            <i class="menu-icon fa fa-cog"></i>
                            <a href="<?php echo e(route('setting.index')); ?>">Toko</a>
                        </li>
                        <li>
                            <i class="menu-icon fa fa-user"></i>
                            <a href="<?php echo e(route('user.index')); ?>">Pengguna</a>
                        </li>
                    <?php endif; ?>
                </ul>
            </li>
        </ul>
    </div><!-- /.navbar-collapse -->
</nav>
</aside><?php /**PATH C:\xampp\htdocs\tokobukuv4\resources\views/_partials/sidebar.blade.php ENDPATH**/ ?>