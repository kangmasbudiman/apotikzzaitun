<?php $__env->startSection('title', 'Pengaturan Aplikasi'); ?>

<?php $__env->startSection('content'); ?>
	
	<div class="row">
		<div class="col-sm-5 mx-auto">

			<?php if(session('success')): ?>
				<div class="alert alert-success alert-dismissible">
					<?php echo e(session('success')); ?>

					<button class="close" data-dismiss="alert">&times;</button>
				</div>
			<?php endif; ?>
			
			<div class="card">
			<form action="<?php echo e(route('setting.update')); ?>" method="post">
				<?php echo method_field('PUT'); ?>
				<?php echo csrf_field(); ?>
				<div class="card-header">
					<h2 class="h6 mb-0 font-weight-bold card-title">Pengaturan Aplikasi</h2>
				</div>
				<div class="card-body">
					<div class="form-group">
						<label>Nama</label>
						<input type="text" class="form-control <?php $__errorArgs = ['nama_toko'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="nama_toko" placeholder="Nama" value="<?php echo e(site('nama_toko')); ?>" autofocus>

						<?php $__errorArgs = ['nama_toko'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
							<span class="invalid-feedback"><?php echo e($message); ?></span>
						<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
					</div>
					<div class="form-group">
						<label>No Telepon</label>
						<input type="text" class="form-control <?php $__errorArgs = ['telepon_toko'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="telepon_toko" placeholder="No Telepon" value="<?php echo e(site('telepon_toko')); ?>" autofocus>

						<?php $__errorArgs = ['telepon_toko'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
							<span class="invalid-feedback"><?php echo e($message); ?></span>
						<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
					</div>
					<div class="form-group">
						<label>Alamat</label>
						<textarea rows="3" class="form-control <?php $__errorArgs = ['alamat_toko'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="alamat_toko" placeholder="Alamat"><?php echo e(site('alamat_toko')); ?></textarea>

						<?php $__errorArgs = ['alamat_toko'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
							<span class="invalid-feedback"><?php echo e($message); ?></span>
						<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
					</div>
				</div>
				<div class="card-footer">
					<button class="btn btn-primary" type="submit">Simpan</button>
				</div>
			</div>
		</div>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('_layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tokobukuv4\resources\views/setting.blade.php ENDPATH**/ ?>