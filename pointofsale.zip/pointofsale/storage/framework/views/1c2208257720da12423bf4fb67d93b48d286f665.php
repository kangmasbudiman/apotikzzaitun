<?php $__env->startSection('title', 'Edit Stok Opname'); ?>

<?php $__env->startSection('content'); ?>

  <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('opname.edit', ['id' => ''.e($id).''])->html();
} elseif ($_instance->childHasBeenRendered('cAd23GP')) {
    $componentId = $_instance->getRenderedChildComponentId('cAd23GP');
    $componentTag = $_instance->getRenderedChildComponentTagName('cAd23GP');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('cAd23GP');
} else {
    $response = \Livewire\Livewire::mount('opname.edit', ['id' => ''.e($id).'']);
    $html = $response->html();
    $_instance->logRenderedChild('cAd23GP', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('_layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ibrahimalanshor/Documents/freelance/Penyesuaian/tokobuku/resources/views/opname/edit.blade.php ENDPATH**/ ?>