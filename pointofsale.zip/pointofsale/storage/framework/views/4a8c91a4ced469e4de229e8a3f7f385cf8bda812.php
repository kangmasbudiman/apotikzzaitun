<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('nav'); ?>
	<div class="col-sm-8">
	    <div class="page-header d-flex align-items-center justify-content-end">
	        <form action="<?php echo e(route('home')); ?>">
	            <button class="btn btn-sm btn-primary <?php if($type === 'today'): ?>
	            	active
	            <?php endif; ?>" name="type" value="today">Hari Ini</button>
	            <button class="btn btn-sm btn-primary <?php if($type === 'week'): ?>
	            	active
	            <?php endif; ?>" name="type" value="week">7 Hari Terakhir</button>
	            <button class="btn btn-sm btn-primary <?php if($type === 'month'): ?>
	            	active
	            <?php endif; ?>" name="type" value="month">Bulan Ini</button>
	            <button class="btn btn-sm btn-primary <?php if($type === 'year'): ?>
	            	active
	            <?php endif; ?>" name="type" value="year">Tahun Ini</button>
	        </form>
	    </div>
	</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	
	<?php if(session('success')): ?>
		<div class="alert alert-success alert-dismissible">
			<?php echo e(session('success')); ?>

			<button class="close" data-dismiss="alert">&times;</button>
		</div>
	<?php endif; ?>

	<div class="col-sm-6 col-lg-3">
        <div class="card text-white bg-flat-color-1">
            <div class="card-body pb-0">
                <div class="float-right">
                    <i class="fa fa-archive"></i>
                </div>
                <h4 class="mb-0">
                    <span class="count"><?php echo e($totalStuff); ?></span>
                </h4>
                <p class="text-light">Total Barang</p>

            </div>

        </div>
    </div>

	<div class="col-sm-6 col-lg-3">
        <div class="card text-white bg-flat-color-3">
            <div class="card-body pb-0">
                <div class="float-right">
                    <i class="fa fa-truck"></i>
                </div>
                <h4 class="mb-0">
                    <span class="count"><?php echo e($totalDistributor); ?></span>
                </h4>
                <p class="text-light">Total Distributor</p>

            </div>

        </div>
    </div>

	<div class="col-sm-6 col-lg-3">
        <div class="card text-white bg-flat-color-4">
            <div class="card-body pb-0">
                <div class="float-right">
                    <i class="fa fa-users"></i>
                </div>
                <h4 class="mb-0">
                    <span class="count"><?php echo e($totalUser); ?></span>
                </h4>
                <p class="text-light">Total Pengguna</p>

            </div>

        </div>
    </div>

	<div class="col-sm-6 col-lg-3">
        <div class="card text-white bg-flat-color-5">
            <div class="card-body pb-0">
                <div class="float-right">
                    <i class="fa fa-money"></i>
                </div>
                <h4 class="mb-0">
                    <span class="count"><?php echo e($totalTransaction); ?></span>
                </h4>
                <p class="text-light">Total Transaksi</p>

            </div>

        </div>
    </div>

	<div class="col-sm-6 col-lg-3">
        <div class="card text-white bg-flat-color-1">
            <div class="card-body pb-0">
                <div class="float-right">
                    <i class="fa fa-calendar"></i>
                </div>
                <h4 class="mb-0">
                    <span class="count"><?php echo e($transactionToday); ?></span>
                </h4>
                <p class="text-light">Transaksi Hari Ini</p>

            </div>

        </div>
    </div>

	<div class="col-sm-6 col-lg-3">
        <div class="card text-white bg-flat-color-3">
            <div class="card-body pb-0">
                <div class="float-right">
                    <i class="fa fa-dollar"></i>
                </div>
                <h4 class="mb-0">
                    <span class="count"><?php echo e($totalIncome); ?></span>
                </h4>
                <p class="text-light">Total Pemasukan</p>

            </div>

        </div>
    </div>

	<div class="col-sm-6 col-lg-3">
        <div class="card text-white bg-flat-color-4">
            <div class="card-body pb-0">
                <div class="float-right">
                    <i class="fa fa-dollar"></i>
                </div>
                <h4 class="mb-0">
                    <span class="count"><?php echo e($totalStock); ?></span>
                </h4>
                <p class="text-light">Total Pembelian</p>

            </div>

        </div>
    </div>

	<div class="col-sm-6 col-lg-3">
        <div class="card text-white bg-flat-color-5">
            <div class="card-body pb-0">
                <div class="float-right">
                    <i class="fa fa-dollar"></i>
                </div>
                <h4 class="mb-0">
                    <span class="count"><?php echo e($totalExpend); ?></span>
                </h4>
                <p class="text-light">Total Pengeluaran</p>

            </div>

        </div>
    </div>

	<div class="col-sm-6 col-lg-3">
        <div class="card text-white bg-flat-color-5">
            <div class="card-body pb-0">
                <div class="float-right">
                    <i class="fa fa-dollar"></i>
                </div>
                <h4 class="mb-0">
                    <span class="count"><?php echo e($profit); ?></span>
                </h4>
                <p class="text-light">Laba</p>

            </div>

        </div>
    </div>

	<div class="col-sm-6 col-lg-3">
        <div class="card text-white bg-flat-color-5">
            <div class="card-body pb-0">
                <div class="float-right">
                    <i class="fa fa-archive"></i>
                </div>
                <h4 class="mb-0">
                    <span class="count"><?php echo e($totalStock); ?></span>
                </h4>
                <p class="text-light">Stok Tersedia</p>

            </div>

        </div>
    </div>

    <div class="col-lg-12">
	    <div class="card">
		    <div class="card-body">
		    	<?php
		    		$name = [
		    			'today' => 'Hari ini',
		    			'week' => '7 Hari Terakhir',
		    			'month' => 'Bulan ini',
		    			'year' => 'Tahun ini'
		    		];
		    	?>
			    <h4 class="mb-3">Grafik Penjualan dan Pembelian <?php echo e($name[$type]); ?></h4>
			    <canvas id="barChart"></canvas>
			</div>
	    </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
	<script src="<?php echo e(asset('sufee-admin/vendors/chart.js/dist/Chart.min.js')); ?>"></script>
	<script>
		const transactions = JSON.parse('<?php echo json_encode($incomeGraphic, 15, 512) ?>')
		const stocks = JSON.parse('<?php echo json_encode($stockGraphic, 15, 512) ?>')

		var ctx = document.getElementById("barChart");
		var myChart = new Chart(ctx, {
		    type: 'bar',
		    data: {
		        labels: transactions.date,
		        datasets: [{
		            label: "Pemasukan",
		            data: transactions.data,
		            borderColor: "rgba(0, 123, 255, 0.9)",
		            borderWidth: "0",
		            backgroundColor: "rgba(0, 123, 255, 0.5)"
		        }, {
		            label: "Pembelian",
		            data: stocks.data,
		            borderColor: "rgba(255,193,7,0.9)",
		            borderWidth: "0",
		            backgroundColor: "rgba(255,193,7,0.5)"
		        }]
		    },
		    options: {
		        scales: {
		            yAxes: [{
		                ticks: {
		                    beginAtZero: true
		                }
		            }]
		        }
		    }
		});
	</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('_layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ibrahimalanshor/Documents/freelance/tokobukuv2/resources/views/home.blade.php ENDPATH**/ ?>