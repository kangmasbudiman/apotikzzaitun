<table>
    <thead>
        <tr>
            <th>ID Pembelian</th>
            <th>Tanggal</th>
            <th>Distributor</th>
            <th>Judul</th>
            <th>Harga Pokok</th>
            <th>Jumlah</th>
            <th>Total</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $stocks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stock): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($stock->idPembelian); ?></td>
                <td><?php echo e($stock->stock->tanggal); ?></td>
                <td><?php echo e($stock->stock->namaDist); ?></td>
                <td><?php echo e($stock->judul); ?></td>
                <td><?php echo e($stock->hargaPokok); ?></td>
                <td><?php echo e($stock->jumlah); ?></td>
                <td><?php echo e($stock->hargaPokok * $stock->jumlah); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH /home/ibrahimalanshor/Documents/freelance/Penyesuaian/Source Code/tokobukuv4/resources/views/stock/detail_stock_export.blade.php ENDPATH**/ ?>