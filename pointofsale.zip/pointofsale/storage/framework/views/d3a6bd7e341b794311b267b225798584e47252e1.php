<?php $__env->startSection('title', 'Laporan Pembelian Harian'); ?>

<?php $__env->startSection('content'); ?>
    
            
    <div class="card">
        <div class="card-header d-flex align-items-center justify-content-between">
            <h2 class="h6 mb-0 font-weight-bold card-title">Laporan Pembelian Harian</h2>
            <a href="<?php echo e(route('report.buy.print.today')); ?>" target="_blank" class="btn btn-sm btn-danger">Print</a>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-striped" width="100%">
                    <thead align="center">
                        <tr>
                            <th>No</th>
                            <th>Jam</th>
                            <th>ID Pembelian</th>
                            <th>Nama Distributor</th>
                            <th>Total Pembelian</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $total = 0
                        ?>
                        <?php $__empty_1 = true; $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr align="center">
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e(date('H:i A', strtotime($report->tanggal))); ?></td>
                                <td><?php echo e($report->idPembelian); ?></td>
                                <td><?php echo e($report->namaDist); ?></td>
                                <td>Rp <?php echo e(number_format($report->total)); ?></td>
                            </tr>

                            <?php
                                $total += $report->total
                            ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="5" align="center">Kosong</td>
                            </tr>
                        <?php endif; ?>
                        <?php if($reports): ?>
                            <tr align="center">
                                <th colspan="4" align="center"><center>Total Seluruh Pembelian</center></th>
                                <th>Rp <?php echo e(number_format($total)); ?></th>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('_layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /usr/local/var/www/pointofsale/resources/views/report/buy-today.blade.php ENDPATH**/ ?>