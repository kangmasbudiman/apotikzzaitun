<?php $__env->startSection('title', 'Riwayat Pembelian'); ?>

<?php $__env->startSection('content'); ?>

    <div id="alert"></div>

    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible">
            <?php echo e(session('success')); ?>

            <button class="close" data-dismiss="alert">&times;</button>
        </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h2 class="h6 card-title font-weight-bold mb-0">Detail Pembelian</h2>
            <div>
                <button class="btn btn-sm btn-success" data-toggle="collapse" data-target="#filter">Filter</button>
                <button class="btn btn-sm btn-warning print">Print</button>
            </div>
        </div>
        <div class="card-body border-bottom collapse form-row pb-4" id="filter">
            <div class="col-sm-3">
                <label>Dari</label>
                <input type="date" name="dari" placeholder="Tanggal" class="form-control">
            </div>
            <div class="col-sm-3">
                <label>Sampai</label>
                <input type="date" name="sampai" placeholder="Tanggal" class="form-control">
            </div>
            <div class="col-sm-3 d-flex align-items-end">
                <button class="btn btn-primary rounded filter">Filter</button>
            </div>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered" width="100%">
                    <thead>
                        <tr>
                            <th>Id Pasok</th>
                            <th>Tanggal</th>
                            <th>Nama Dist</th>
                            <th>Judul Buku</th>
                            <th>Harga</th>
                            <th>Jumlah</th>
                            <th>Total</th>
                    </thead>
                </table>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('css'); ?>
    
    <link rel="stylesheet" href="<?php echo e(asset('sufee-admin/vendors/datatables.net-bs4/css/dataTables.bootstrap4.min.css')); ?>">

<?php $__env->stopPush(); ?>

<?php $__env->startPush('js'); ?>
    
    <script src="<?php echo e(asset('sufee-admin/vendors/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('sufee-admin/vendors/datatables.net-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>

    <script>
        const ajaxUrl = '<?php echo e(route('detail_stock.datatables')); ?>'
        const printUrl = '<?php echo e(route('detail_stock.printall')); ?>'
        const csrf = '<?php echo e(csrf_token()); ?>'
    </script>

    <script src="<?php echo e(asset('js/detail_stock.js')); ?>"></script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('_layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tokobukuv4\resources\views/stock/detail_stock.blade.php ENDPATH**/ ?>