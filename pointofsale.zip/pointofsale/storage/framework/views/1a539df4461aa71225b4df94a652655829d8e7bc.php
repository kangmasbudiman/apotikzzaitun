<?php $__env->startSection('title', 'Tambah Stok Opname'); ?>

<?php $__env->startSection('content'); ?>

  <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('opname.create', [])->html();
} elseif ($_instance->childHasBeenRendered('sg2GVgP')) {
    $componentId = $_instance->getRenderedChildComponentId('sg2GVgP');
    $componentTag = $_instance->getRenderedChildComponentTagName('sg2GVgP');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('sg2GVgP');
} else {
    $response = \Livewire\Livewire::mount('opname.create', []);
    $html = $response->html();
    $_instance->logRenderedChild('sg2GVgP', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('_layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ibrahimalanshor/Documents/freelance/Penyesuaian/tokobuku/resources/views/opname/create.blade.php ENDPATH**/ ?>