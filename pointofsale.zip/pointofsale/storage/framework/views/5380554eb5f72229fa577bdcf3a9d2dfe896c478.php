<div class="row">
	<div class="col-sm-4" wire:ignore>
		<div class="card">
			<div class="card-header">
				<h2 class="h6 font-weight-bold mb-0 card-title">Data Distributor</h2>
			</div>
			<div class="card-body">
				<div class="form-group">
					<label>Distributor</label>
					<select name="idDist" class="form-control custom-select"></select>

					<span class="invalid-feedback"></span>
				</div>
				<div class="form-group">
					<label>Telepon</label>
					<input type="text" class="form-control" name="telepon" placeholder="Telepon" disabled>

					<span class="invalid-feedback"></span>
				</div>
				<div class="form-group">
					<label>Alamat</label>
					<textarea class="form-control" name="alamat" placeholder="Alamat" rows="3" disabled></textarea>

					<span class="invalid-feedback"></span>
				</div>
			</div>
		</div>
	</div>
	<div class="col-sm-8">
	<form wire:submit.prevent="submit" class="buku">
		<div class="card">
			<div class="card-header">
				<h2 class="h6 card-title font-weight-bold mb-0">Data Buku</h2>
			</div>
			<div class="card-body">
				<div wire:ignore>
					<div class="form-group">
						<label>Buku</label>
						<select name="idBuku" class="form-control custom-select"></select>

						<span class="invalid-feedback"></span>
					</div>
					<div class="form-row">
						<div class="col">
							<div class="form-group">
								<label>No ISBN</label>
								<input type="text" class="form-control" name="noisbn" placeholder="No ISBN" disabled>

								<span class="invalid-feedback"></span>
							</div>
						</div>
						<div class="col">
							<div class="form-group">
								<label>Penulis</label>
								<input type="text" class="form-control" name="penulis" placeholder="Penulis" disabled>

								<span class="invalid-feedback"></span>
							</div>
						</div>
					</div>
					<div class="form-row">
						<div class="col">
							<div class="form-group">
								<label>Penerbit</label>
								<input type="text" class="form-control" name="penerbit" placeholder="Penerbit" disabled>

								<span class="invalid-feedback"></span>
							</div>
						</div>
						<div class="col">
							<div class="form-group">
								<label>Tahun</label>
								<input type="text" class="form-control" name="tahun" placeholder="Tahun" disabled>

								<span class="invalid-feedback"></span>
							</div>
						</div>
					</div>
					<div class="form-row">
						<div class="col-sm-6">
							<div class="form-group">
								<label>Harga Pokok</label>
								<input type="text" class="form-control" name="hargaPokok" placeholder="Harga Pokok" disabled>

								<span class="invalid-feedback"></span>
							</div>
						</div>
						<div class="col-sm-3">
							<div class="form-group">
								<label>PPN</label>
								<input type="text" class="form-control" name="ppn" placeholder="PPN" disabled>

								<span class="invalid-feedback"></span>
							</div>
						</div>
						<div class="col-sm-3">
							<div class="form-group">
								<label>Stok</label>
								<input type="text" class="form-control" name="stock" placeholder="Stok" disabled>

								<span class="invalid-feedback"></span>
							</div>
						</div>
					</div>
				</div>
				<div class="form-group">
					<label>Jumlah</label>
					<div class="input-group">
						<input type="number" class="form-control <?php $__errorArgs = ['jumlah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="jumlah" placeholder="Jumlah" wire:model="jumlah">
						<div class="input-group-append" wire:ignore>
							<button class="btn btn-primary" type="submit" name="submit" disabled>Tambah</button>
						</div>

						<?php $__errorArgs = ['jumlah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
							<span class="invalid-feedback"><?php echo e($message); ?></span>
						<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
					</div>
				</div>
			</div>
		</div>
	</form>
	</div>
</div>

<?php $__env->startPush('css'); ?>
	
	<link rel="stylesheet" href="<?php echo e(asset('sufee-admin/vendors/select2/css/select2.min.css')); ?>">

<?php $__env->stopPush(); ?>

<?php $__env->startPush('js'); ?>
	
	<script src="<?php echo e(asset('sufee-admin/vendors/select2/js/select2.min.js')); ?>"></script>

	<script>
		Livewire.on('addData', function () {
			$('.buku .form-control').val('')
			$('[name=idBuku]').empty()
		})

		const $ = jQuery

		const stuffUrl = '<?php echo e(route('stuff.select')); ?>'
		const distUrl = '<?php echo e(route('distributor.select')); ?>'
		const csrf = '<?php echo e(csrf_token()); ?>'
		const buku = $('[name=idBuku]')
		const distributor = $('[name=idDist]')


		$('.form-control').val('')
		$('[name=submit]').prop('disabled', true)

		buku.select2({
			placeholder: 'Barang',
			ajax: {
				url: stuffUrl,
				type: 'post',
				data: params => ({
					name: params.term,
					_token: csrf
				}),
				processResults: res => {
					res.map(stuff => stuff.text = `${stuff.text} - ${stuff.id}`);
					return {
						results: res
					}
				},
				cache: true
			}
		})

		distributor.select2({
			placeholder: 'Distributor',
			ajax: {
				url: distUrl,
				type: 'post',
				data: params => ({
					name: params.term,
					_token: csrf
				}),
				processResults: res => ({
					results: res
				}),
				cache: true
			}
		})

		buku.on('select2:select', function (e) {
			const data = e.params.data

			for (let [name, value] of Object.entries(data)) {
				if (name === 'ppn') {
					$(`[name=${name}]`).val(value + ' %')
				} else {
					$(`[name=${name}]`).val(value)
				}
			}

			$('[name=submit]').removeAttr('disabled')

			window.livewire.find('<?php echo e($_instance->id); ?>').set('idBuku', data.id)
		})

		distributor.on('select2:select', function (e) {
			const data = e.params.data
			
			for (let [name, value] of Object.entries(data)) {
				$(`[name=${name}]`).val(value)
			}

			Livewire.emit('setDistributor', data.id)
		})
	</script>

<?php $__env->stopPush(); ?><?php /**PATH C:\xampp\htdocs\tokobukuv2\resources\views/livewire/stock/form.blade.php ENDPATH**/ ?>