<?php $__env->startSection('title', 'Barang'); ?>

<?php $__env->startSection('content'); ?>
	
	<?php if(session('success')): ?>
		<div class="alert alert-success alert-dismissible">
			<?php echo e(session('success')); ?>

			<button class="close" data-dismiss="alert">&times;</button>
		</div>
	<?php endif; ?>

	<div id="alert"></div>
	<div class="card">
		<div class="card-header d-flex justify-content-between align-items-center">
			<h2 class="h6 font-weight-bold mb-0 card-title">Data Barang</h2>
			<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('isAdminGudang')): ?>
				<div>
					<a href="<?php echo e(route('stuff.printall')); ?>" class="btn btn-warning btn-sm">Print</a>
					<a href="<?php echo e(route('stuff.printallbarcode')); ?>" class="btn btn-success btn-sm">Print Semua Barcode</a>
					<a href="<?php echo e(route('stuff.create')); ?>" class="btn btn-primary btn-sm">Tambah Data</a>
				</div>
			<?php endif; ?>
		</div>
		<div class="card-body">
			<div class="table-responsive">
				<table class="table table-bordered" width="100%">
					<thead>
						<tr>
							<th>No</th>
							<th>Id Buku</th>
							<th>Barcode</th>
							<th>Nama Buku</th>
							<th>No ISBN</th>
							<th>Stok</th>
							<th>Harga</th>
							<th>Action</th>
						</tr>
					</thead>
				</table>
			</div>
		</div>
	</div>

	<div class="modal">
	<div class="modal-dialog modal-dialog-scrollable modal-dialog-centered">
	<div class="modal-content">
	<form action="" method="post">
		<?php echo csrf_field(); ?>
		<?php echo method_field('PUT'); ?>
		<div class="modal-header">
			<h5 class="modal-title">Edit Data</h5>
			<button class="close" data-dismiss="modal">&times;</button>
		</div>
		<div class="modal-body">
			<input type="hidden" name="id">
			<div class="form-group">
				<label>No ISBN</label>
				<input type="text" class="form-control <?php $__errorArgs = ['noisbn'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="noisbn" placeholder="No ISBN" value="<?php echo e(old('noisbn')); ?>" autofocus>

				<span class="invalid-feedback"></span>
			</div>
			<div class="form-group">
				<label>Barcode</label>
				<input type="text" class="form-control <?php $__errorArgs = ['barcode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="barcode" placeholder="Barcode" value="<?php echo e(old('barcode')); ?>">

				<span class="invalid-feedback"></span>
			</div>
			<div class="form-row">
				<div class="col">
					<div class="form-group">
						<label>Judul</label>
						<input type="text" class="form-control <?php $__errorArgs = ['judul'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="judul" placeholder="Judul" value="<?php echo e(old('judul')); ?>">

						<span class="invalid-feedback"></span>
					</div>
				</div>
				<div class="col">
					<div class="form-group">
						<label>Penulis</label>
						<input type="text" class="form-control <?php $__errorArgs = ['penulis'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="penulis" placeholder="Penulis" value="<?php echo e(old('penulis')); ?>">

						<span class="invalid-feedback"></span>
					</div>
				</div>
			</div>
			<div class="form-row">
				<div class="col">
					<div class="form-group">
						<label>Kategori</label>
						<select class="form-control custom-select" name="idKategori" style="width: 100%;"></select>

						<span class="invalid-feedback"></span>
					</div>
				</div>
				<div class="col">
					<div class="form-group">
						<label>Rak</label>
						<input type="text" class="form-control <?php $__errorArgs = ['rak'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="rak" placeholder="Rak" value="<?php echo e(old('rak')); ?>">

						<span class="invalid-feedback"></span>
					</div>
				</div>
			</div>
			<div class="form-row">
				<div class="col">
					<div class="form-group">
						<label>Penerbit</label>
						<input type="text" class="form-control <?php $__errorArgs = ['penerbit'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="penerbit" placeholder="Penerbit" value="<?php echo e(old('penerbit')); ?>">

						<span class="invalid-feedback"></span>
					</div>
				</div>
				<div class="col">
					<div class="form-group">
						<label>Tahun</label>
						<input type="numer" class="form-control <?php $__errorArgs = ['tahun'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="tahun" placeholder="Tahun" value="<?php echo e(old('tahun')); ?>">

						<span class="invalid-feedback"></span>
					</div>
				</div>
			</div>
			<div class="form-row">
				<div class="col">
					<div class="form-group">
						<label>Harga Pokok</label>
						<div class="input-group">
							<div class="input-group-prepend">
								<span class="input-group-text">Rp</span>
							</div>
							<input type="text" class="form-control price <?php $__errorArgs = ['hargaPokok'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="hargaPokok" placeholder="Harga Pokok" value="<?php echo e(old('hargaPokok')); ?>">

							<span class="invalid-feedback"></span>
						</div>
					</div>
				</div>
				<div class="col">
					<div class="form-group">
						<label>Harga Jual</label>
						<div class="input-group">
							<div class="input-group-prepend">
								<span class="input-group-text">Rp</span>
							</div>
							<input type="text" class="form-control price <?php $__errorArgs = ['hargaJual'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="hargaJual" placeholder="Harga Jual" value="<?php echo e(old('hargaJual')); ?>">

							<span class="invalid-feedback"></span>
						</div>
					</div>
				</div>
			</div>
			<div class="form-row">
				<div class="col">
					<div class="form-group">
						<label>PPN</label>
						<input type="number" class="form-control <?php $__errorArgs = ['ppn'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="ppn" placeholder="PPN" value="<?php echo e(old('ppn')); ?>">

						<span class="invalid-feedback"></span>
					</div>
				</div>
				<div class="col">
					<div class="form-group">
						<label>Disc</label>
						<input type="numer" class="form-control <?php $__errorArgs = ['disc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="disc" placeholder="Disc" value="<?php echo e(old('disc')); ?>">

						<span class="invalid-feedback"></span>
					</div>
				</div>
			</div>
		</div>
		<div class="modal-footer">
			<button class="btn btn-primary" type="submit">Simpan</button>
			<button class="btn btn-secondary" data-dismiss="modal">Batal</button>
		</div>
	</form>
	</div>
	</div>
	</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('css'); ?>
	
	<link rel="stylesheet" href="<?php echo e(asset('sufee-admin/vendors/datatables.net-bs4/css/dataTables.bootstrap4.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('sufee-admin/vendors/select2/css/select2.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('sufee-admin/vendors/select2-bootstrap4-theme/select2-bootstrap4.min.css')); ?>">

<?php $__env->stopPush(); ?>

<?php $__env->startPush('js'); ?>
	
	<script src="<?php echo e(asset('sufee-admin/vendors/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
	<script src="<?php echo e(asset('sufee-admin/vendors/datatables.net-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>
	<script src="<?php echo e(asset('sufee-admin/vendors/select2/js/select2.min.js')); ?>"></script>

	<script>
		const ajaxUrl = '<?php echo e(route('stuff.datatables')); ?>'
		const updateUrl = '<?php echo e(route('stuff.update', ':id')); ?>'
		const deleteUrl = '<?php echo e(route('stuff.destroy', ':id')); ?>'
		const categoryUrl = '<?php echo e(route('category.select')); ?>'
		const csrf = '<?php echo e(csrf_token()); ?>'
	</script>

	<script src="<?php echo e(asset('js/stuff.js')); ?>"></script>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('_layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ibrahimalanshor/Documents/freelance/tokobukuv2/resources/views/stuff/index.blade.php ENDPATH**/ ?>