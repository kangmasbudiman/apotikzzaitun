<?php $__env->startSection('title', 'Laporan Pembelian Bulanan'); ?>

<?php $__env->startSection('content'); ?>
    
            
    <div class="card">
        <div class="card-header d-flex align-items-center justify-content-between">
            <h2 class="h6 mb-0 font-weight-bold card-title">Laporan Pembelian Bulanan</h2>
            <a href="<?php echo e(route('report.buy.print.month')); ?>" class="btn btn-sm btn-danger" target="_blank">Print</a>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-striped" width="100%">
                    <thead align="center">
                        <tr>
                            <th>No</th>
                            <th>Tanggal</th>
                            <th>Distributor</th>
                            <th>Total Pembelian</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $total = 0
                        ?>

                        <?php $__empty_1 = true; $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php
                            $total += $report->total
                        ?>
                            <tr align="center">
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e(date('d M', strtotime($report->tanggal))); ?></td>
                                <td><?php echo e($report->namaDist); ?></td>
                                <td>Rp <?php echo e(number_format($report->total)); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="4" align="center">Kosong</td>
                            </tr>
                        <?php endif; ?>

                        <tr>
                            <td colspan="3" align="right"><b>Total Pembelian</b></td>
                            <td align="center">Rp <?php echo e(number_format($total)); ?></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('_layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ibrahimalanshor/Documents/freelance/Penyesuaian/tokobuku/resources/views/report/buy-month.blade.php ENDPATH**/ ?>