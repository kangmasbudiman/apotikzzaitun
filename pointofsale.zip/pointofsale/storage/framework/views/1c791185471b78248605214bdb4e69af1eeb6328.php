<?php $__env->startSection('title', 'Laporan Penjualan'); ?>

<?php $__env->startSection('content'); ?>
    
            
    <div class="card">
        <div class="card-header d-flex align-items-center justify-content-between">
            <h2 class="h6 mb-0 font-weight-bold card-title">Laporan Penjualan</h2>
            <form action="<?php echo e(route('report.sell.print')); ?>" target="_blank">
                <input type="hidden" name="dari" value="<?php echo e(request()->dari); ?>">
                <input type="hidden" name="sampai" value="<?php echo e(request()->sampai); ?>">
                <input type="hidden" name="user" value="<?php echo e(request()->user); ?>">
                <button class="btn btn-sm btn-danger">Print</button>
            </form>
        </div>
        <div class="card-body border-bottom">
           <form action="<?php echo e(route('report.sell')); ?>">
                <div class="form-row form-group">
                    <div class="col-sm-3">
                        <label>Dari Tanggal</label>
                        <input type="date" name="dari" class="form-control" value="<?php echo e(request()->dari); ?>">
                    </div>
                    <div class="col-sm-3">
                        <label>Sampai Tanggal</label>
                        <input type="date" name="sampai" class="form-control" value="<?php echo e(request()->sampai); ?>">
                    </div>
                    <div class="col-sm-3">
                        <label>Kasir</label>
                        <select class="form-control" name="user">
                            <option selected disabled>Kasir</option>
                            <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->idUser); ?>"><?php echo e($item->nama); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <button class="btn btn-primary">Tampilkan</button>
            </form>
        </div>
        <?php if($reports): ?>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered table-striped" width="100%">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Tanggal</th>
                                <th>Nama Buku</th>
                                <th>Qty</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $total = 0
                            ?>
                            <?php $__empty_1 = true; $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e(localDate($report->tanggal)); ?></td>
                                    <td><?php echo e($report->judul); ?></td>
                                    <td><?php echo e($report->total); ?></td>
                                </tr>

                                <?php
                                    $total += $report->total
                                ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="4" align="center">Kosong</td>
                                </tr>
                            <?php endif; ?>
                            <?php if($reports): ?>
                                <tr>
                                    <th colspan="3" class="text-right">Total Qty</th>
                                    <th><?php echo e($total); ?></th>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        <?php endif; ?>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('_layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ibrahimalanshor/Documents/freelance/Penyesuaian/Source Code/tokobukuv4/resources/views/report/sell.blade.php ENDPATH**/ ?>