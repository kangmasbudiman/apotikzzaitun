<table>
    <thead>
        <tr>
            <th>ID Pengeluaran</th>
            <th>ID Kategori Pengeluaran</th>
            <th>ID Pembelian</th>
            <th>ID Opname</th>
            <th>ID Pajak</th>
            <th>ID User</th>
            <th>Nama User</th>
            <th>Tanggal</th>
            <th>Pengeluaran</th>
            <th>Kategori</th>
            <th>Keterangan</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $expends; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expend): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($expend->idPengeluaran); ?></td>
                <td><?php echo e($expend->idKategoriPengeluaran); ?></td>
                <td><?php echo e($expend->idPembelian); ?></td>
                <td><?php echo e($expend->idOpname); ?></td>
                <td><?php echo e($expend->idPajak); ?></td>
                <td><?php echo e($expend->idUser); ?></td>
                <td><?php echo e($expend->namaUser); ?></td>
                <td><?php echo e($expend->tanggal); ?></td>
                <td><?php echo e($expend->pengeluaran ?? ''); ?></td>
                <td><?php echo e($expend->namaKategori); ?></td>
                <td><?php echo e($expend->keterangan); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH /usr/local/var/www/pointofsale/resources/views/expend/export.blade.php ENDPATH**/ ?>