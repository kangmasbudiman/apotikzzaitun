<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<title><?php echo $__env->yieldContent('title'); ?></title>
<meta name="description" content="Sufee Admin - HTML5 Admin Template">
<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="apple-touch-icon" href="apple-icon.png">
<link rel="shortcut icon" href="favicon.ico">

<link rel="stylesheet" href="<?php echo e(asset('sufee-admin/vendors/bootstrap/dist/css/bootstrap.min.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('sufee-admin/vendors/font-awesome/css/font-awesome.min.css')); ?>">

<link rel="stylesheet" href="<?php echo e(asset('sufee-admin/assets/css/style.css')); ?>">
<link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">

<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,700,800' rel='stylesheet' type='text/css'>

<?php echo \Livewire\Livewire::styles(); ?>


<?php echo $__env->yieldPushContent('css'); ?><?php /**PATH /usr/local/var/www/pointofsale/resources/views/_includes/head.blade.php ENDPATH**/ ?>