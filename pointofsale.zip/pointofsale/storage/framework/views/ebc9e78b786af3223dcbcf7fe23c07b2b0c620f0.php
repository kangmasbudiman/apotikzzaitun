<table>
    <thead>
        <tr>
            <th>No Faktur</th>
            <th>Tanggal</th>
            <th>Status</th>
            <th>PPN</th>
            <th>Total</th>
            <th>ID Kasir</th>
            <th>Kasir</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $success; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($transaction->idPenjualan); ?></td>
                <td><?php echo e($transaction->tanggal); ?></td>
                <td><?php echo e($transaction->status ? 'berhasil' : 'batal'); ?></td>
                <td><?php echo e($transaction->ppn); ?></td>
                <td><?php echo e($transaction->total); ?></td>
                <td><?php echo e($transaction->idUser); ?></td>
                <td><?php echo e($transaction->namaUser); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <tr></tr>
        <?php $__currentLoopData = $cancel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($transaction->idPenjualan); ?></td>
                <td><?php echo e($transaction->tanggal); ?></td>
                <td><?php echo e($transaction->status ? 'berhasil' : 'batal'); ?></td>
                <td><?php echo e($transaction->ppn); ?></td>
                <td><?php echo e($transaction->total); ?></td>
                <td><?php echo e($transaction->idUser); ?></td>
                <td><?php echo e($transaction->namaUser); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table><?php /**PATH C:\xampp\htdocs\tokobuku\resources\views/transaction/export.blade.php ENDPATH**/ ?>