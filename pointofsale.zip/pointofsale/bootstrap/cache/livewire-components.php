<?php return array (
  'barcode.item' => 'App\\Http\\Livewire\\Barcode\\Item',
  'barcode.search' => 'App\\Http\\Livewire\\Barcode\\Search',
  'opname.create' => 'App\\Http\\Livewire\\Opname\\Create',
  'opname.edit' => 'App\\Http\\Livewire\\Opname\\Edit',
  'stock.cetak' => 'App\\Http\\Livewire\\Stock\\Cetak',
  'stock.data' => 'App\\Http\\Livewire\\Stock\\Data',
  'stock.form' => 'App\\Http\\Livewire\\Stock\\Form',
  'stock.payment' => 'App\\Http\\Livewire\\Stock\\Payment',
  'transaction.cetak' => 'App\\Http\\Livewire\\Transaction\\Cetak',
  'transaction.create' => 'App\\Http\\Livewire\\Transaction\\Create',
  'transaction.data' => 'App\\Http\\Livewire\\Transaction\\Data',
  'transaction.payment' => 'App\\Http\\Livewire\\Transaction\\Payment',
);